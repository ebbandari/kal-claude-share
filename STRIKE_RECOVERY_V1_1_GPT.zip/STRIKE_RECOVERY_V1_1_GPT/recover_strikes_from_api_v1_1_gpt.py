#!/usr/bin/env python3
"""
recover_strikes_from_api_v1_1_gpt.py

Recover paper-bot market strikes that were absent from the lifecycle archive.
The Kalshi market API is the exact source; interpolation is never used.

Safety properties
-----------------
* Development rows are limited to --through (default 2026-09-06).
* The sealed 2026-09-07..2026-09-13 holdout is never queried.
* Validation uses known paper-bot markets and must achieve a high success rate.
* Both floor- and cap-strike comparators are supported.
* Live-market lookup falls back to the historical-market endpoint.
* Transient API failures are retried and are NOT treated as durable cache hits.
* Every development opportunity survives into a recovered coverage table.

Outputs
-------
recovered_strikes.csv
    One row per API target (missing tickers, plus known tickers with --also-known).

opportunity_strike_coverage_recovered.csv
    The original opportunity coverage rows plus final strike/comparator/source.

api_market_cache.jsonl
    Append-only successful and failed attempts. Only successful records are reused.

validation_sample.csv, SUMMARY.txt
"""
from __future__ import annotations

import argparse
import collections
import csv
import datetime as dt
import json
import math
import os
import random
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any

API_ROOT_DEFAULT = "https://api.elections.kalshi.com/trade-api/v2"
SEALED_FROM = dt.date(2026, 9, 7)
SEALED_TO = dt.date(2026, 9, 13)
DEFAULT_THROUGH = dt.date(2026, 9, 6)
KNOWN_COMPARATORS = {"greater_or_equal", "greater", "less_or_equal", "less"}
TRANSIENT_HTTP = {408, 425, 429, 500, 502, 503, 504}
PERMANENT_HTTP = {400, 401, 403}


def num(v: Any) -> float | None:
    if v in (None, "") or isinstance(v, bool):
        return None
    try:
        x = float(v)
    except (TypeError, ValueError, OverflowError):
        return None
    return x if math.isfinite(x) else None


def parse_date(v: Any) -> dt.date | None:
    if v in (None, ""):
        return None
    try:
        return dt.date.fromisoformat(str(v)[:10])
    except ValueError:
        return None


def parse_epoch_date(v: Any) -> dt.date | None:
    x = num(v)
    if x is None:
        return None
    try:
        if x > 1e18:
            x /= 1e9
        elif x > 1e15:
            x /= 1e6
        elif x > 1e11:
            x /= 1e3
        return dt.datetime.fromtimestamp(x, dt.timezone.utc).date()
    except (OverflowError, OSError, ValueError):
        return None


def opportunity_date(row: dict[str, str]) -> dt.date | None:
    return (parse_date(row.get("date")) or parse_date(row.get("date_utc"))
            or parse_epoch_date(row.get("t")) or parse_epoch_date(row.get("t_entry")))


def is_sealed(d: dt.date | None) -> bool:
    return d is not None and SEALED_FROM <= d <= SEALED_TO


def normalize_comparator(v: Any) -> str:
    s = str(v or "").strip().lower()
    return s if s in KNOWN_COMPARATORS else ""


def effective_strike(record: dict[str, Any]) -> tuple[float | None, str]:
    """Return the strike used by the comparator, or a fail-closed reason."""
    cmp_ = normalize_comparator(record.get("strike_type"))
    if not cmp_:
        return None, "UNKNOWN_COMPARATOR"
    field = "floor_strike" if cmp_ in {"greater", "greater_or_equal"} else "cap_strike"
    k = num(record.get(field))
    if k is None or k <= 0:
        return None, f"MISSING_{field.upper()}"
    return k, "OK"


def extract_market(market: dict[str, Any], endpoint: str, requested_ticker: str) -> dict[str, Any]:
    rec = {
        "market_ticker_api": market.get("ticker", ""),
        "floor_strike": market.get("floor_strike", ""),
        "cap_strike": market.get("cap_strike", ""),
        "strike_type": market.get("strike_type", ""),
        "expiration_value": market.get("expiration_value", ""),
        "result": market.get("result", ""),
        "close_time": market.get("close_time", ""),
        "status": market.get("status", ""),
        "endpoint": endpoint,
    }
    if rec["market_ticker_api"] and rec["market_ticker_api"] != requested_ticker:
        rec["record_status"] = "TICKER_MISMATCH"
        rec["effective_strike"] = ""
        return rec
    k, why = effective_strike(rec)
    rec["effective_strike"] = "" if k is None else repr(k)
    rec["record_status"] = why
    return rec


class KalshiAPI:
    """Public market lookup with retries and historical fallback."""

    def __init__(self, base=API_ROOT_DEFAULT, timeout=25.0, sleep=0.05,
                 retries=5, backoff=0.5, opener=None):
        self.base = base.rstrip("/")
        self.timeout = float(timeout)
        self.sleep = float(sleep)
        self.retries = int(retries)
        self.backoff = float(backoff)
        self.opener = opener or urllib.request.urlopen

    def _request(self, path: str) -> tuple[dict[str, Any] | None, str]:
        url = self.base + path
        last = "UNKNOWN"
        for attempt in range(self.retries):
            if self.sleep:
                time.sleep(self.sleep)
            req = urllib.request.Request(url, headers={
                "Accept": "application/json",
                "User-Agent": "kalshi-strike-recovery/1.1",
            })
            try:
                with self.opener(req, timeout=self.timeout) as resp:
                    raw = resp.read()
                    code = getattr(resp, "status", 200)
                if code != 200:
                    last = f"HTTP_{code}"
                else:
                    try:
                        body = json.loads(raw.decode("utf-8"))
                    except Exception:
                        return None, "UNPARSEABLE_JSON"
                    market = body.get("market") if isinstance(body, dict) else None
                    if not isinstance(market, dict):
                        return None, "NO_MARKET_OBJECT"
                    return market, "OK"
            except urllib.error.HTTPError as exc:
                code = int(exc.code)
                last = f"HTTP_{code}"
                if code == 404 or code in PERMANENT_HTTP or (400 <= code < 500 and code not in TRANSIENT_HTTP):
                    return None, last
            except Exception as exc:  # network timeout/reset/etc.
                last = f"TRANSPORT_{type(exc).__name__}"
            if attempt + 1 < self.retries:
                time.sleep(self.backoff * (2 ** attempt))
        return None, last

    def get(self, ticker: str) -> tuple[dict[str, Any] | None, str]:
        q = urllib.parse.quote(ticker, safe="")
        market, status = self._request(f"/markets/{q}")
        if market is not None:
            return extract_market(market, "LIVE", ticker), "OK"
        if status == "HTTP_404" or status == "NO_MARKET_OBJECT":
            market, hstatus = self._request(f"/historical/markets/{q}")
            if market is not None:
                return extract_market(market, "HISTORICAL", ticker), "OK"
            return None, f"LIVE_{status}|HIST_{hstatus}"
        return None, status


class Cache:
    """Append-only JSONL. Only valid successful records are reusable.

    Failed/transient attempts are retained for audit, but never make a ticker
    permanently unqueryable on the next run.
    """

    def __init__(self, path: str | Path):
        self.path = Path(path)
        self.success: dict[str, dict[str, Any]] = {}
        self.last_failure: dict[str, dict[str, Any]] = {}
        self.bad_lines = 0
        if self.path.exists():
            with self.path.open(encoding="utf-8") as fh:
                for line in fh:
                    try:
                        r = json.loads(line)
                        tk = r["ticker"]
                    except Exception:
                        self.bad_lines += 1
                        continue
                    if r.get("api_status") == "OK" and r.get("record_status") == "OK":
                        self.success[tk] = r
                    else:
                        self.last_failure[tk] = r
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.fh = self.path.open("a", encoding="utf-8")

    def get(self, ticker: str) -> dict[str, Any] | None:
        return self.success.get(ticker)

    def put(self, ticker: str, rec: dict[str, Any]) -> None:
        out = dict(rec, ticker=ticker,
                   fetched_at_utc=dt.datetime.now(dt.timezone.utc).isoformat())
        self.fh.write(json.dumps(out, sort_keys=True) + "\n")
        self.fh.flush()
        if out.get("api_status") == "OK" and out.get("record_status") == "OK":
            self.success[ticker] = out
        else:
            self.last_failure[ticker] = out

    def close(self) -> None:
        try:
            self.fh.close()
        except Exception:
            pass


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    fields: list[str] = []
    for r in rows:
        for k in r:
            if k not in fields:
                fields.append(k)
    with path.open("w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=fields, extrasaction="ignore")
        w.writeheader()
        w.writerows(rows)


def filter_coverage(rows: list[dict[str, str]], through: dt.date,
                    stats: collections.Counter) -> list[dict[str, str]]:
    out = []
    for r in rows:
        d = opportunity_date(r)
        if d is None:
            stats["invalid_opportunity_date"] += 1
            continue
        if is_sealed(d):
            stats["sealed_rows_refused"] += 1
            continue
        if d > through:
            stats["after_through_refused"] += 1
            continue
        out.append(r)
    return out


def known_from_coverage(cov: list[dict[str, str]]) -> tuple[dict[str, tuple[float, str]], list[str]]:
    vals: dict[str, set[tuple[float, str]]] = collections.defaultdict(set)
    for r in cov:
        tk = r.get("ticker", "")
        k = num(r.get("strike_asof"))
        cmp_ = normalize_comparator(r.get("comparator_asof"))
        if r.get("status") == "OK" and tk and k is not None and k > 0 and cmp_:
            vals[tk].add((k, cmp_))
    conflicts = sorted(tk for tk, v in vals.items() if len(v) > 1)
    known = {tk: next(iter(v)) for tk, v in vals.items() if len(v) == 1}
    return known, conflicts


def validate(api: KalshiAPI, known: dict[str, tuple[float, str]], n: int,
             tol: float, seed: int, log) -> tuple[dict[str, int], list[dict[str, Any]]]:
    rng = random.Random(seed)
    tickers = sorted(known)
    sample = rng.sample(tickers, min(n, len(tickers)))
    stats = collections.Counter()
    rows: list[dict[str, Any]] = []
    for tk in sample:
        life_k, life_cmp = known[tk]
        rec, status = api.get(tk)
        row = {"market_ticker": tk, "lifecycle_strike": repr(life_k),
               "lifecycle_comparator": life_cmp, "api_status": status}
        if rec is None:
            stats["unavailable"] += 1
            row["validation_status"] = "UNAVAILABLE"
            rows.append(row)
            continue
        api_k = num(rec.get("effective_strike"))
        api_cmp = normalize_comparator(rec.get("strike_type"))
        row.update(api_strike="" if api_k is None else repr(api_k),
                   api_comparator=api_cmp, endpoint=rec.get("endpoint", ""),
                   record_status=rec.get("record_status", ""))
        strike_ok = (api_k is not None and
                     abs(api_k - life_k) <= tol * max(abs(life_k), 1e-9))
        cmp_ok = bool(api_cmp) and api_cmp == life_cmp
        if strike_ok and cmp_ok and rec.get("record_status") == "OK":
            stats["agree"] += 1
            row["validation_status"] = "AGREE"
        else:
            stats["disagree"] += 1
            row["validation_status"] = "DISAGREE"
        rows.append(row)
    log(f"  validation sample        {len(sample)}")
    log(f"    agree                  {stats['agree']}")
    log(f"    DISAGREE               {stats['disagree']}")
    log(f"    unavailable            {stats['unavailable']}")
    for r in [x for x in rows if x["validation_status"] == "DISAGREE"][:10]:
        log(f"      {r['market_ticker']:28s} lifecycle={r['lifecycle_strike']} "
            f"{r['lifecycle_comparator']} api={r.get('api_strike','')} "
            f"{r.get('api_comparator','')}")
    return dict(stats, sample=len(sample)), rows


def make_final_coverage(cov: list[dict[str, str]], recovered: dict[str, dict[str, Any]]) -> list[dict[str, Any]]:
    out = []
    for r in cov:
        x: dict[str, Any] = dict(r)
        life_k = num(r.get("strike_asof"))
        life_cmp = normalize_comparator(r.get("comparator_asof"))
        rec = recovered.get(r.get("ticker", ""))
        if life_k is not None and life_k > 0 and life_cmp and r.get("status") == "OK":
            x.update(strike_final=repr(life_k), comparator_final=life_cmp,
                     strike_source_final="LIFECYCLE_ASOF", recovery_status="NOT_NEEDED")
        elif rec is not None and rec.get("api_status") == "OK" and rec.get("record_status") == "OK":
            x.update(strike_final=rec.get("effective_strike", ""),
                     comparator_final=normalize_comparator(rec.get("strike_type")),
                     strike_source_final="API_RECOVERED", recovery_status="OK")
        else:
            x.update(strike_final="", comparator_final="", strike_source_final="MISSING",
                     recovery_status=(rec or {}).get("api_status", "NOT_FETCHED"))
        x.update(expiration_value_api=(rec or {}).get("expiration_value", ""),
                 result_api=(rec or {}).get("result", ""),
                 close_time_api=(rec or {}).get("close_time", ""),
                 api_endpoint=(rec or {}).get("endpoint", ""))
        out.append(x)
    return out


def run(args) -> int:
    out = Path(os.path.expanduser(args.out))
    out.mkdir(parents=True, exist_ok=True)
    lines: list[str] = []

    def log(s=""):
        print(s, flush=True)
        lines.append(s)

    raw_cov = list(csv.DictReader(open(os.path.expanduser(args.coverage), newline="")))
    through = dt.date.fromisoformat(args.through)
    filter_stats = collections.Counter()
    cov = filter_coverage(raw_cov, through, filter_stats)
    if filter_stats["invalid_opportunity_date"]:
        log(f"REFUSING: {filter_stats['invalid_opportunity_date']} coverage rows have no valid date")
        return 2
    known, conflicts = known_from_coverage(cov)
    if conflicts:
        log(f"REFUSING: {len(conflicts)} tickers have conflicting lifecycle strikes in coverage")
        return 2

    universe = sorted({r.get("ticker", "") for r in cov if r.get("ticker")})
    missing = sorted({r.get("ticker", "") for r in cov
                      if r.get("ticker") and r.get("status") == "MISSING_STRIKE"})
    known_in_universe = sorted(set(universe) & set(known))
    unclassified = sorted(set(universe) - set(missing) - set(known_in_universe))

    targets = list(missing)
    if args.also_known:
        targets += [t for t in known_in_universe if t not in set(targets)]
    if args.limit:
        targets = targets[:args.limit]

    log("=" * 70)
    log("STRIKE RECOVERY FROM KALSHI API — REVIEWED V1.1")
    log("=" * 70)
    log(f"  raw coverage rows         {len(raw_cov):,}")
    log(f"  development rows          {len(cov):,} through {through}")
    log(f"  sealed rows refused       {filter_stats['sealed_rows_refused']:,}")
    log(f"  after-through refused     {filter_stats['after_through_refused']:,}")
    log(f"  unique opportunity tickers {len(universe):,}")
    log(f"  lifecycle-known tickers   {len(known_in_universe):,}")
    log(f"  missing tickers           {len(missing):,}")
    log(f"  other/unclassified        {len(unclassified):,}")
    log(f"  fetch targets             {len(targets):,}" + (" (--also-known)" if args.also_known else ""))
    if args.limit:
        log(f"  LIMITED RUN               first {args.limit:,} targets only")
    log(f"  estimated time            {len(targets)*(args.sleep+0.25)/60:.0f} min")
    if args.dry_run:
        log("\n--dry-run: nothing fetched")
        (out / "SUMMARY.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
        return 0

    api = KalshiAPI(base=args.api_root, timeout=args.timeout, sleep=args.sleep,
                    retries=args.retries, backoff=args.backoff)
    log("\nVALIDATING API against lifecycle-known paper-bot markets")
    vstats, vrows = validate(api, known, args.validate_n, args.tol, args.seed, log)
    write_csv(out / "validation_sample.csv", vrows)
    required = min(vstats["sample"], max(args.min_validation_count,
                   math.ceil(args.min_validation_rate * vstats["sample"])))
    if vstats.get("sample", 0) == 0 or vstats.get("agree", 0) == 0:
        log("REFUSING: no known paper-bot strike was validated")
        (out / "SUMMARY.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
        return 2
    if vstats.get("disagree", 0):
        log(f"REFUSING: {vstats.get('disagree', 0)} strike/comparator disagreements")
        (out / "SUMMARY.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
        return 2
    if vstats.get("agree", 0) < required:
        log(f"REFUSING: only {vstats.get('agree', 0)} of {vstats['sample']} validated; "
            f"required {required}")
        (out / "SUMMARY.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
        return 2
    log(f"  validation PASSED: {vstats.get('agree', 0)} agreements, 0 disagreements")

    cache = Cache(out / "api_market_cache.jsonl")
    recovered: dict[str, dict[str, Any]] = {}
    stats = collections.Counter()
    t0 = time.time()
    every = max(1, len(targets) // 100)
    for i, tk in enumerate(targets, 1):
        rec = cache.get(tk)
        if rec is not None:
            stats["from_cache"] += 1
        else:
            market_rec, status = api.get(tk)
            if market_rec is not None:
                rec = dict(market_rec, api_status="OK")
            else:
                rec = {"api_status": status, "record_status": "API_FAILURE"}
            cache.put(tk, rec)
            stats["fetched"] += 1
        recovered[tk] = rec
        stats["api_" + str(rec.get("api_status", "?")).split("|")[0]] += 1
        stats["endpoint_" + str(rec.get("endpoint", "NONE"))] += 1
        if i % every == 0 or i == len(targets):
            el = time.time() - t0
            log(f"  [{i}/{len(targets)}] {100*i/max(len(targets),1):5.1f}%  "
                f"{el/60:5.1f} min elapsed  "
                f"{(len(targets)-i)*el/max(i,1)/60:5.1f} min left")
    cache.close()

    api_rows = []
    for tk in targets:
        r = recovered.get(tk, {})
        api_rows.append({"market_ticker": tk,
                         "was_missing": int(tk in set(missing)),
                         **{k: r.get(k, "") for k in (
                             "effective_strike", "floor_strike", "cap_strike",
                             "strike_type", "expiration_value", "result", "close_time",
                             "status", "endpoint", "market_ticker_api",
                             "record_status", "api_status")}})
    write_csv(out / "recovered_strikes.csv", api_rows)

    final_cov = make_final_coverage(cov, recovered)
    write_csv(out / "opportunity_strike_coverage_recovered.csv", final_cov)

    recovered_missing = sum(1 for tk in missing
                            if (recovered.get(tk) or {}).get("api_status") == "OK"
                            and (recovered.get(tk) or {}).get("record_status") == "OK")
    rows_before = sum(1 for r in cov if r.get("status") == "OK")
    rows_after = sum(1 for r in final_cov if r.get("strike_final") not in (None, ""))
    unique_after = len(set(known_in_universe) | {
        tk for tk in missing if (recovered.get(tk) or {}).get("api_status") == "OK"
        and (recovered.get(tk) or {}).get("record_status") == "OK"})

    log("\nRESULT")
    log(f"  fetched                   {stats['fetched']:,}")
    log(f"  served from success cache {stats['from_cache']:,}")
    log(f"  bad cache lines ignored   {cache.bad_lines:,}")
    log(f"  missing tickers recovered {recovered_missing:,} of {len(missing):,}")
    log(f"  unique ticker coverage    {len(known_in_universe):,}/{len(universe):,} before; "
        f"{unique_after:,}/{len(universe):,} after")
    log(f"  opportunity-row coverage  {rows_before:,}/{len(cov):,} before; "
        f"{rows_after:,}/{len(cov):,} after")
    for k in sorted(k for k in stats if k.startswith("endpoint_")):
        log(f"    {k:30s} {stats[k]:,}")
    for k in sorted(k for k in stats if k.startswith("api_")):
        log(f"    {k:30s} {stats[k]:,}")
    log(f"\n  wrote {out}/recovered_strikes.csv")
    log(f"        {out}/opportunity_strike_coverage_recovered.csv")
    log(f"        {out}/api_market_cache.jsonl")
    log(f"        {out}/validation_sample.csv")
    (out / "SUMMARY.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")

    if len(final_cov) != len(cov):
        log("FATAL: opportunity-row reconciliation failed")
        return 2
    return 0 if recovered_missing == len(missing) or args.limit else 1


# ------------------------------- embedded tests ------------------------------
def self_test() -> int:
    fails = []

    def ck(name, cond):
        print(f"  {name:68s} {'PASS' if cond else 'FAIL'}")
        if not cond:
            fails.append(name)

    ck("nonfinite numeric values are rejected",
       num(float("nan")) is None and num(float("inf")) is None)
    ck("greater comparator uses floor strike",
       effective_strike({"strike_type": "greater_or_equal", "floor_strike": 100}) == (100.0, "OK"))
    ck("less comparator uses cap strike",
       effective_strike({"strike_type": "less", "cap_strike": 90}) == (90.0, "OK"))
    ck("missing comparator fails closed",
       effective_strike({"floor_strike": 100})[1] == "UNKNOWN_COMPARATOR")

    cov = [
        {"ticker": "A", "date": "2026-09-06", "status": "OK",
         "strike_asof": "100", "comparator_asof": "greater_or_equal"},
        {"ticker": "B", "date": "2026-09-07", "status": "MISSING_STRIKE"},
        {"ticker": "C", "date": "2026-09-14", "status": "MISSING_STRIKE"},
    ]
    st = collections.Counter()
    got = filter_coverage(cov, DEFAULT_THROUGH, st)
    ck("sealed and after-through rows are refused by opportunity date",
       [r["ticker"] for r in got] == ["A"] and st["sealed_rows_refused"] == 1
       and st["after_through_refused"] == 1)

    known, conflicts = known_from_coverage(got)
    ck("known strike universe is derived from opportunity coverage",
       known == {"A": (100.0, "greater_or_equal")} and not conflicts)

    import tempfile
    with tempfile.TemporaryDirectory() as td:
        c = Cache(Path(td) / "cache.jsonl")
        c.put("ERR", {"api_status": "TRANSPORT_TimeoutError", "record_status": "API_FAILURE"})
        c.put("OK", {"api_status": "OK", "record_status": "OK",
                     "effective_strike": "100", "strike_type": "greater_or_equal"})
        c.close()
        c2 = Cache(Path(td) / "cache.jsonl")
        ck("transient failure is not a reusable cache hit", c2.get("ERR") is None)
        ck("successful immutable record is reusable", c2.get("OK") is not None)
        c2.close()

    class FakeAPI:
        def get(self, tk):
            if tk == "A":
                return {"effective_strike": "100.0", "strike_type": "greater_or_equal",
                        "record_status": "OK", "endpoint": "LIVE"}, "OK"
            return None, "HTTP_503"

    logs = []
    vs, rows = validate(FakeAPI(), {"A": (100.0, "greater_or_equal"),
                                    "B": (200.0, "greater_or_equal")},
                        2, 1e-9, 1, logs.append)
    ck("validation reports unavailable markets rather than false agreement",
       vs.get("agree", 0) == 1 and vs.get("unavailable", 0) == 1 and vs.get("disagree", 0) == 0)

    merged = make_final_coverage(
        [{"ticker": "A", "status": "OK", "strike_asof": "100",
          "comparator_asof": "greater_or_equal"},
         {"ticker": "B", "status": "MISSING_STRIKE", "strike_asof": "",
          "comparator_asof": ""}],
        {"B": {"api_status": "OK", "record_status": "OK", "effective_strike": "200",
               "strike_type": "greater_or_equal", "expiration_value": "201"}})
    ck("merged coverage preserves every opportunity row", len(merged) == 2)
    ck("lifecycle strike remains primary when present",
       merged[0]["strike_source_final"] == "LIFECYCLE_ASOF")
    ck("missing lifecycle strike is exactly API-recovered",
       merged[1]["strike_source_final"] == "API_RECOVERED"
       and merged[1]["strike_final"] == "200")

    print("\n" + ("ALL PASS" if not fails else "FAILURES: " + ", ".join(fails)))
    return 0 if not fails else 1


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--coverage", default="~/strike_table/opportunity_strike_coverage.csv")
    ap.add_argument("--out", default="~/strike_recovery")
    ap.add_argument("--through", default=str(DEFAULT_THROUGH))
    ap.add_argument("--validate-n", type=int, default=300)
    ap.add_argument("--min-validation-rate", type=float, default=0.95)
    ap.add_argument("--min-validation-count", type=int, default=50)
    ap.add_argument("--seed", type=int, default=7)
    ap.add_argument("--tol", type=float, default=1e-9)
    ap.add_argument("--sleep", type=float, default=0.05)
    ap.add_argument("--timeout", type=float, default=25.0)
    ap.add_argument("--retries", type=int, default=5)
    ap.add_argument("--backoff", type=float, default=0.5)
    ap.add_argument("--api-root", default=API_ROOT_DEFAULT)
    ap.add_argument("--limit", type=int, default=0)
    ap.add_argument("--also-known", action="store_true")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--self-test", action="store_true")
    args = ap.parse_args()
    if args.self_test:
        return self_test()
    if not (0 < args.min_validation_rate <= 1):
        ap.error("--min-validation-rate must be in (0,1]")
    return run(args)


if __name__ == "__main__":
    raise SystemExit(main())
