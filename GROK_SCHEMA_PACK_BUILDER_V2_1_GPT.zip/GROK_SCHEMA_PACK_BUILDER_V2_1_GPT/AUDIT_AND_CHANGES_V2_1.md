# Grok schema-pack builder v2.1 — focused review patch

Claude's four observations were valid. The production builder is patched as follows:

1. **HYPE metadata included.** `metadata_sample.csv` now scans both `window/` and `exception/`, so HYPE's close/strike/settlement fields accompany its exception data.
2. **Clock policy explicit.** The compact extract is cut on receive/local time when available (the causal availability clock), falling back to source/exchange time. All original clocks remain in each row for lead-lag analysis, and `window_extraction_report.csv` records the cut clock and its role.
3. **No recursive 1-TB v9 listing.** The `**` fallback was removed. If bounded discovery misses the session, pass the exact `--v9-uri`.
4. **Early exit made clock-aware.** Receive-clock files may stop after 50 post-window rows when still monotonic. Source-clock files scan fully, so delayed/out-of-order source events cannot silently lose an in-window row.
5. **Minor cleanup.** Removed a duplicated exception-sample error.

The overall package design and command line are unchanged.

## Verification

- Python compilation: PASS
- Embedded end-to-end self-test: PASS
- Independent pytest: **9/9 PASS**
- Tests explicitly cover HYPE metadata, blank strike preservation, receive/source clock behavior, disordered source rows, bounded v9 discovery, read-only GCS behavior, and the full fake build.

The actual production GCS build still must be run on Probe2 because this sandbox has no bucket credentials.
