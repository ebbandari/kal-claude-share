#!/usr/bin/env python3
"""
cf_velocity_alignment_v1_1_gpt.py

Focused diagnostic: when a selected Kalshi side was evaluated, was the CF RTI
already moving TOWARD that side or AWAY from it, and did that relation carry
outcome or executable-PnL information?

Two explicit populations are supported:

  reachability  One-contract, executable-ask opportunities from
                paper_bot_cf_reachability_rows.csv.gz. Requires status=OK,
                economic_status=OK, and reference_gateable=1.

  half_skip     The current half-touch, cap-25 CF-skip-only candidate from
                reversal_rows.csv.gz. Includes only rows where
                half_B_CF_SKIP_ONLY_action == TAKE and uses that policy's
                actual quantity, price, realized outcome, and exact PnL.

The program is DESCRIPTIVE. It does not create a trading rule or tune a
velocity threshold. It reports price, quantity, outcome, and PnL together so a
win-rate difference cannot be mistaken for economic value.

Key sign convention:
  oriented_velocity = direction_sign(side, comparator) * raw_CF_velocity

  oriented_velocity > 0  -> CF is moving toward the purchased side
  oriented_velocity < 0  -> CF is moving away from the purchased side

This does NOT force velocity positive. It rotates NO-side and less-comparator
cases into one common economic orientation.

The reachability analyzer's `accel_a_b_bps_per_s` fields are actually
multi-scale VELOCITY CONTRASTS v_a - v_b (same units as velocity), not physical
acceleration. This script reports both the contrast and a constant-acceleration
estimate:

  a_hat(a,b) = 2 * (v_a - v_b) / (b - a)   [bps / s^2], a < b

because v_h is a backward average velocity centered approximately at t-h/2.

USAGE
  python3 cf_velocity_alignment_v1_1_gpt.py --self-test

  # Broad one-contract reachability population
  python3 cf_velocity_alignment_v1_1_gpt.py \
    --rows ~/cf_reach_v1_1/paper_bot_cf_reachability_rows.csv.gz \
    --lane reachability --out ~/cf_velocity_alignment_reachability_v1_1

  # Current profitable development candidate (recommended first)
  python3 cf_velocity_alignment_v1_1_gpt.py \
    --rows ~/cf_reversal_v2_1_20260916T031510Z/reversal_rows.csv.gz \
    --lane half_skip --out ~/cf_velocity_alignment_half_skip_v1_1
"""
from __future__ import annotations

import argparse
import collections
import csv
import datetime as dt
import gzip
import json
import math
import os
import random
import statistics as statistics
import sys
from pathlib import Path
from typing import Any, Iterable

VEL_HORIZONS = (5, 15, 30, 60, 120, 300)
CONTRAST_PAIRS = ((5, 30), (15, 60), (30, 120))
COMPARATORS = {"greater_or_equal", "greater", "less_or_equal", "less"}
SEALED_FROM = dt.date(2026, 9, 7)
SEALED_TO = dt.date(2026, 9, 13)
DEFAULT_THROUGH = dt.date(2026, 9, 6)

# Exact development-candidate drawdown interval already measured.
DEFAULT_BLEED_START = dt.datetime(2026, 7, 28, 0, 46, tzinfo=dt.timezone.utc).timestamp()
DEFAULT_BLEED_END = dt.datetime(2026, 8, 21, 3, 33, tzinfo=dt.timezone.utc).timestamp()


def num(v: Any) -> float | None:
    if v in (None, ""):
        return None
    try:
        x = float(v)
    except (TypeError, ValueError):
        return None
    return x if math.isfinite(x) else None


def flag01(v: Any) -> int | None:
    x = num(v)
    if x in (0.0, 1.0):
        return int(x)
    s = str(v).strip().lower() if v is not None else ""
    if s in {"true", "yes"}:
        return 1
    if s in {"false", "no"}:
        return 0
    return None


def parse_ts(v: Any) -> float | None:
    x = num(v)
    if x is not None:
        if x > 1e18:
            x /= 1e9
        elif x > 1e15:
            x /= 1e6
        elif x > 1e11:
            x /= 1e3
        try:
            dt.datetime.fromtimestamp(x, dt.timezone.utc)
        except (OverflowError, OSError, ValueError):
            return None
        return x
    if v in (None, ""):
        return None
    try:
        d = dt.datetime.fromisoformat(str(v).strip().replace("Z", "+00:00"))
        if d.tzinfo is None:
            d = d.replace(tzinfo=dt.timezone.utc)
        return d.timestamp()
    except Exception:
        return None


def utc_date(ts: float) -> dt.date:
    return dt.datetime.fromtimestamp(ts, dt.timezone.utc).date()


def utc_day(ts: float) -> str:
    return utc_date(ts).isoformat()


def exact_segment(ts: float, bleed_start: float, bleed_end: float) -> str:
    if ts < bleed_start:
        return "1_pre_drawdown"
    if ts <= bleed_end:
        return "2_exact_drawdown"
    return "3_post_drawdown"


def open_any(path: str | Path):
    p = str(path)
    return (gzip.open(p, "rt", newline="", encoding="utf-8", errors="replace")
            if p.endswith(".gz")
            else open(p, "r", newline="", encoding="utf-8", errors="replace"))


def pick(header: set[str], *names: str) -> str | None:
    for name in names:
        if name in header:
            return name
    return None


def direction_sign(side: str, comparator: str) -> int | None:
    """+1 means rising CF helps the side; -1 means falling CF helps it."""
    side = side.upper()
    comparator = comparator.strip()
    if side not in {"YES", "NO"} or comparator not in COMPARATORS:
        return None
    yes_wants_up = comparator in {"greater_or_equal", "greater"}
    if side == "YES":
        return 1 if yes_wants_up else -1
    return -1 if yes_wants_up else 1


def oriented_velocity(side: str, comparator: str, raw_velocity: float | None) -> float | None:
    s = direction_sign(side, comparator)
    if s is None or raw_velocity is None:
        return None
    return s * raw_velocity


def alignment_label(oriented: float | None, zero_epsilon: float = 0.0) -> str:
    if oriented is None or abs(oriented) <= zero_epsilon:
        return "UNDECIDABLE"
    return "TOWARD" if oriented > 0 else "AWAY"


def velocity_contrast(v_short: float | None, v_long: float | None) -> float | None:
    if v_short is None or v_long is None:
        return None
    return v_short - v_long


def acceleration_estimate(v_short: float | None, v_long: float | None,
                          h_short: int, h_long: int) -> float | None:
    """Constant-acceleration estimate in bps/s^2 from backward average velocities."""
    if v_short is None or v_long is None or h_long <= h_short:
        return None
    return 2.0 * (v_short - v_long) / (h_long - h_short)


def reversal_state(v_short_oriented: float | None,
                   v_long_oriented: float | None,
                   zero_epsilon: float = 0.0) -> str:
    a = alignment_label(v_short_oriented, zero_epsilon)
    b = alignment_label(v_long_oriented, zero_epsilon)
    if "UNDECIDABLE" in (a, b):
        return "UNDECIDABLE"
    if b == "TOWARD" and a == "TOWARD":
        return "CONTINUING_TOWARD"
    if b == "AWAY" and a == "AWAY":
        return "CONTINUING_AWAY"
    if b == "TOWARD" and a == "AWAY":
        return "REVERSING_AWAY"
    return "REVERSING_TOWARD"


def median(values: Iterable[float]) -> float | None:
    vals = [x for x in values if x is not None and math.isfinite(x)]
    return statistics.median(vals) if vals else None


def mean(values: Iterable[float]) -> float | None:
    vals = [x for x in values if x is not None and math.isfinite(x)]
    return statistics.fmean(vals) if vals else None


def detect_lane(header: set[str], requested: str) -> str:
    if requested != "auto":
        return requested
    if "half_B_CF_SKIP_ONLY_action" in header:
        return "half_skip"
    if "pnl_ask_exact" in header:
        return "reachability"
    raise RuntimeError("cannot infer lane: no recognized policy/economic columns")


def resolve_columns(header: set[str], lane: str) -> dict[str, str | None]:
    c: dict[str, str | None] = {
        "t": pick(header, "t_entry", "t"),
        "ticker": pick(header, "ticker", "market_ticker"),
        "burst": pick(header, "burst_id"),
        "coin": pick(header, "coin", "sib"),
        "cmp": pick(header, "comparator_final", "comparator_asof", "strike_type"),
    }
    for h in VEL_HORIZONS:
        # Do not silently substitute returns for velocities. Their signs match,
        # but their magnitudes and units do not.
        c[f"vel{h}"] = pick(header, f"vel_{h}s_bps_per_s")
    c["vol60"] = pick(header, "rv_60s_bps", "realized_vol_60s_bps")
    for a, b in CONTRAST_PAIRS:
        c[f"contrast{a}_{b}"] = pick(
            header,
            f"accel_{a}_{b}_bps_per_s",  # actual reachability v1.1 name
            f"accel_{a}_{b}",
            f"accel_{a}s_{b}s",
        )

    if lane == "half_skip":
        p = "half_B_CF_SKIP_ONLY_"
        c.update({
            "row_status": pick(header, "reversal_status"),
            "action": pick(header, p + "action"),
            "side": pick(header, p + "final_side", "original_side", "side", "opp"),
            "win": pick(header, p + "realized_win", "win"),
            "pnl_exact": pick(header, p + "exact"),
            "pnl_scal": pick(header, p + "scalable"),
            "q": pick(header, p + "q"),
            "price": pick(header, p + "price"),
            "economic_status": None,
            "reference_gateable": pick(header, "reference_gateable"),
        })
    elif lane == "reachability":
        c.update({
            "row_status": pick(header, "status"),
            "action": None,
            "side": pick(header, "side", "purchased_side", "opp", "original_side"),
            "win": pick(header, "win", "realized_win"),
            "pnl_exact": pick(header, "pnl_ask_exact"),
            "pnl_scal": pick(header, "pnl_ask_scalable"),
            "q": None,
            "price": pick(header, "reconstructed_ask", "primary_repriced_ask"),
            "economic_status": pick(header, "economic_status"),
            "reference_gateable": pick(header, "reference_gateable"),
        })
    else:
        raise RuntimeError(f"unknown lane: {lane}")

    required = ("t", "ticker", "coin", "cmp", "side", "win", "pnl_exact", "price")
    missing = [k for k in required if c.get(k) is None]
    missing_vel = [h for h in VEL_HORIZONS if c.get(f"vel{h}") is None]
    if missing:
        raise RuntimeError("required columns missing: " + ", ".join(missing))
    if missing_vel:
        raise RuntimeError("velocity columns missing for horizons: " + ", ".join(map(str, missing_vel)))
    if lane == "half_skip" and (c["action"] is None or c["q"] is None):
        raise RuntimeError("half_skip lane requires action and quantity columns")
    if lane == "reachability" and (c["economic_status"] is None or c["reference_gateable"] is None):
        raise RuntimeError("reachability lane requires economic_status and reference_gateable")
    return c


def unique_id(row: dict[str, str], c: dict[str, str | None], t: float) -> tuple[str, str, float]:
    side = (row.get(c["side"] or "") or "").upper()
    return (row.get(c["ticker"] or "", ""), side, round(t, 6))


def load_rows(path: str, lane_requested: str, through: dt.date,
              bleed_start: float, bleed_end: float,
              allow_sealed: bool = False) -> tuple[list[dict[str, Any]], list[dict[str, Any]], dict[str, Any]]:
    analysis: list[dict[str, Any]] = []
    audit: list[dict[str, Any]] = []
    counts = collections.Counter()
    seen: dict[tuple[str, str, float], int] = {}

    with open_any(path) as fh:
        rd = csv.DictReader(fh)
        header = set(rd.fieldnames or [])
        lane = detect_lane(header, lane_requested)
        c = resolve_columns(header, lane)
        for line_no, row in enumerate(rd, start=2):
            counts["rows_in"] += 1
            rec: dict[str, Any] = {"source_line": line_no, "analysis_status": ""}
            t = parse_ts(row.get(c["t"] or ""))
            if t is None:
                rec["analysis_status"] = "INVALID_TIME"
                audit.append(rec)
                counts["INVALID_TIME"] += 1
                continue
            d = utc_date(t)
            if SEALED_FROM <= d <= SEALED_TO and not allow_sealed:
                raise RuntimeError(f"sealed holdout row present at source line {line_no}; refusing")
            if d > through:
                raise RuntimeError(f"row after development cutoff {through} at source line {line_no}; refusing")

            uid = unique_id(row, c, t)
            if uid in seen:
                raise RuntimeError(f"duplicate opportunity identity at lines {seen[uid]} and {line_no}: {uid}")
            seen[uid] = line_no

            side = (row.get(c["side"] or "") or "").upper()
            win = num(row.get(c["win"] or ""))
            comparator = (row.get(c["cmp"] or "") or "").strip()
            coin = row.get(c["coin"] or "", "") or "?"
            ticker = row.get(c["ticker"] or "", "")
            burst = row.get(c["burst"] or "", "") if c.get("burst") else ""

            base = {
                "source_line": line_no,
                "t": t,
                "date": d.isoformat(),
                "segment": exact_segment(t, bleed_start, bleed_end),
                "ticker": ticker,
                "burst_id": burst,
                "coin": coin,
                "side": side,
                "comparator": comparator,
                "win": "" if win is None else int(win),
                "analysis_status": "",
            }

            if side not in {"YES", "NO"}:
                base["analysis_status"] = "UNKNOWN_SIDE"
            elif win not in (0.0, 1.0):
                base["analysis_status"] = "INVALID_WIN"
            elif comparator not in COMPARATORS:
                base["analysis_status"] = "UNKNOWN_COMPARATOR"
            elif c.get("row_status") and row.get(c["row_status"] or "") != "OK":
                base["analysis_status"] = "SOURCE_STATUS_NOT_OK"
            elif lane == "reachability" and row.get(c["economic_status"] or "") != "OK":
                base["analysis_status"] = "ECONOMIC_STATUS_NOT_OK"
            elif lane == "reachability" and flag01(row.get(c["reference_gateable"] or "")) != 1:
                base["analysis_status"] = "REFERENCE_NOT_GATEABLE"
            elif lane == "half_skip" and row.get(c["action"] or "") != "TAKE":
                base["analysis_status"] = "POLICY_SKIPPED"

            pe = num(row.get(c["pnl_exact"] or ""))
            ps = num(row.get(c["pnl_scal"] or "")) if c.get("pnl_scal") else None
            price = num(row.get(c["price"] or ""))
            q = num(row.get(c["q"] or "")) if c.get("q") else 1.0
            if not base["analysis_status"]:
                if pe is None:
                    base["analysis_status"] = "MISSING_EXACT_PNL"
                elif price is None or not (0.0 < price < 1.0):
                    base["analysis_status"] = "INVALID_PRICE"
                elif q is None or q <= 0:
                    base["analysis_status"] = "INVALID_QUANTITY"

            if base["analysis_status"]:
                audit.append(base)
                counts[base["analysis_status"]] += 1
                continue

            r: dict[str, Any] = dict(base)
            r.update({
                "analysis_status": "OK",
                "exact_pnl": pe,
                "scalable_pnl": ps,
                "price": price,
                "q": q,
                "pnl_per_contract": pe / q,
            })
            sign = direction_sign(side, comparator)
            assert sign is not None
            r["direction_sign"] = sign
            for h in VEL_HORIZONS:
                raw = num(row.get(c[f"vel{h}"] or ""))
                r[f"v{h}_raw"] = raw
                r[f"v{h}_oriented"] = None if raw is None else sign * raw
                r[f"align_{h}"] = alignment_label(r[f"v{h}_oriented"])
            r["rv60_bps"] = num(row.get(c["vol60"] or "")) if c.get("vol60") else None
            for a, b in CONTRAST_PAIRS:
                source_contrast = (num(row.get(c[f"contrast{a}_{b}"] or ""))
                                   if c.get(f"contrast{a}_{b}") else None)
                computed_contrast = velocity_contrast(r[f"v{a}_raw"], r[f"v{b}_raw"])
                r[f"velocity_contrast_{a}_{b}_raw"] = computed_contrast
                r[f"velocity_contrast_{a}_{b}_source"] = source_contrast
                r[f"velocity_contrast_{a}_{b}_source_diff"] = (
                    None if source_contrast is None or computed_contrast is None
                    else source_contrast - computed_contrast)
                r[f"velocity_contrast_{a}_{b}_oriented"] = (
                    None if computed_contrast is None else sign * computed_contrast)
                raw_acc = acceleration_estimate(r[f"v{a}_raw"], r[f"v{b}_raw"], a, b)
                r[f"acceleration_est_{a}_{b}_raw_bps_s2"] = raw_acc
                r[f"acceleration_est_{a}_{b}_oriented_bps_s2"] = (
                    None if raw_acc is None else sign * raw_acc)
                r[f"path_state_{a}_{b}"] = reversal_state(
                    r[f"v{a}_oriented"], r[f"v{b}_oriented"])
            analysis.append(r)
            audit.append(r)
            counts["OK"] += 1

    counts["rows_out"] = len(audit)
    if counts["rows_in"] != counts["rows_out"]:
        raise RuntimeError(f"row reconciliation failed: in={counts['rows_in']} out={counts['rows_out']}")
    meta = {"lane": lane, "columns": c, "counts": dict(counts)}
    return analysis, audit, meta


def summarize_cell(rows: list[dict[str, Any]]) -> dict[str, Any]:
    n = len(rows)
    wins = sum(int(r["win"]) for r in rows)
    contracts = sum(float(r["q"]) for r in rows)
    exact = sum(float(r["exact_pnl"]) for r in rows)
    scalable = sum(float(r["scalable_pnl"] or 0.0) for r in rows)
    prices = [float(r["price"]) for r in rows]
    qs = [float(r["q"]) for r in rows]
    return {
        "n": n,
        "wins": wins,
        "losses": n - wins,
        "win_rate": wins / n if n else None,
        "contracts": contracts,
        "exact_pnl": exact,
        "scalable_pnl": scalable,
        "exact_pnl_per_trade": exact / n if n else None,
        "exact_pnl_per_contract": exact / contracts if contracts else None,
        "mean_price": mean(prices),
        "median_price": median(prices),
        "mean_q": mean(qs),
        "median_q": median(qs),
        "days": len({r["date"] for r in rows}),
        "tickers": len({r["ticker"] for r in rows}),
        "bursts": len({r["burst_id"] for r in rows if r["burst_id"]}),
    }


def grouped_cells(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    dimensions = [
        ("whole", lambda r: "ALL"),
        ("segment", lambda r: r["segment"]),
        ("coin", lambda r: r["coin"]),
    ]
    for h in VEL_HORIZONS:
        valid = [r for r in rows if r[f"align_{h}"] in {"TOWARD", "AWAY"}]
        for dim_name, dim_fn in dimensions:
            buckets: dict[tuple[str, str, str], list[dict[str, Any]]] = collections.defaultdict(list)
            for r in valid:
                buckets[(str(dim_fn(r)), r["side"], r[f"align_{h}"])].append(r)
            for (dim_value, side, align), rr in sorted(buckets.items()):
                out.append({
                    "record_type": "alignment_cell",
                    "horizon_s": h,
                    "dimension": dim_name,
                    "dimension_value": dim_value,
                    "side": side,
                    "state": align,
                    **summarize_cell(rr),
                })
    for a, b in CONTRAST_PAIRS:
        key = f"path_state_{a}_{b}"
        for dim_name, dim_fn in dimensions:
            buckets2: dict[tuple[str, str, str], list[dict[str, Any]]] = collections.defaultdict(list)
            for r in rows:
                state = r[key]
                if state == "UNDECIDABLE":
                    continue
                buckets2[(str(dim_fn(r)), r["side"], state)].append(r)
            for (dim_value, side, state), rr in sorted(buckets2.items()):
                out.append({
                    "record_type": "path_state_cell",
                    "horizon_s": f"{a}_{b}",
                    "dimension": dim_name,
                    "dimension_value": dim_value,
                    "side": side,
                    "state": state,
                    **summarize_cell(rr),
                })
    return out


def headline(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    out = []
    for h in VEL_HORIZONS:
        for side in ("YES", "NO"):
            toward = [r for r in rows if r["side"] == side and r[f"align_{h}"] == "TOWARD"]
            away = [r for r in rows if r["side"] == side and r[f"align_{h}"] == "AWAY"]
            st, sa = summarize_cell(toward), summarize_cell(away)
            out.append({
                "horizon_s": h,
                "side": side,
                "n_toward": st["n"],
                "n_away": sa["n"],
                "win_rate_toward": st["win_rate"],
                "win_rate_away": sa["win_rate"],
                "win_rate_gap": (None if st["win_rate"] is None or sa["win_rate"] is None
                                 else st["win_rate"] - sa["win_rate"]),
                "exact_pnl_toward": st["exact_pnl"],
                "exact_pnl_away": sa["exact_pnl"],
                "exact_pnl_per_trade_toward": st["exact_pnl_per_trade"],
                "exact_pnl_per_trade_away": sa["exact_pnl_per_trade"],
                "pnl_per_trade_gap": (None if st["exact_pnl_per_trade"] is None
                                      or sa["exact_pnl_per_trade"] is None
                                      else st["exact_pnl_per_trade"]
                                      - sa["exact_pnl_per_trade"]),
                "pnl_per_contract_toward": st["exact_pnl_per_contract"],
                "pnl_per_contract_away": sa["exact_pnl_per_contract"],
                "mean_price_toward": st["mean_price"],
                "mean_price_away": sa["mean_price"],
                "median_price_toward": st["median_price"],
                "median_price_away": sa["median_price"],
            })
    return out


def _strata(rows: list[dict[str, Any]]) -> dict[tuple[str, str, str, str], list[int]]:
    g: dict[tuple[str, str, str, str], list[int]] = collections.defaultdict(list)
    for i, r in enumerate(rows):
        g[(r["date"], r["coin"], r["side"], r["segment"])].append(i)
    return g


def permutation_control(rows: list[dict[str, Any]], heads: list[dict[str, Any]],
                        shuffles: int, seed: int) -> list[dict[str, Any]]:
    """Stratified permutation preserving observed alignment counts within day/coin/side/regime.

    Statistic: mean exact PnL per trade in TOWARD minus AWAY. A familywise
    max-|stat| p-value covers all six horizons x two sides.
    """
    if shuffles <= 0:
        return []
    rng = random.Random(seed)
    by_h: dict[int, list[dict[str, Any]]] = {}
    strata_by_h: dict[int, dict[tuple[str, str, str, str], list[int]]] = {}
    for h in VEL_HORIZONS:
        rr = [r for r in rows if r[f"align_{h}"] in {"TOWARD", "AWAY"}]
        by_h[h] = rr
        strata_by_h[h] = _strata(rr)

    observed = {(int(x["horizon_s"]), x["side"]): x["pnl_per_trade_gap"] for x in heads}
    nulls: dict[tuple[int, str], list[float]] = collections.defaultdict(list)
    max_abs: list[float] = []

    for _ in range(shuffles):
        iter_stats: list[float] = []
        for h in VEL_HORIZONS:
            rr = by_h[h]
            labels = [r[f"align_{h}"] for r in rr]
            perm = labels[:]
            for idxs in strata_by_h[h].values():
                vals = [labels[i] for i in idxs]
                rng.shuffle(vals)
                for i, v in zip(idxs, vals):
                    perm[i] = v
            for side in ("YES", "NO"):
                tvals = [rr[i]["exact_pnl"] for i in range(len(rr))
                         if rr[i]["side"] == side and perm[i] == "TOWARD"]
                avals = [rr[i]["exact_pnl"] for i in range(len(rr))
                         if rr[i]["side"] == side and perm[i] == "AWAY"]
                if not tvals or not avals:
                    continue
                stat = statistics.fmean(tvals) - statistics.fmean(avals)
                nulls[(h, side)].append(stat)
                iter_stats.append(abs(stat))
        max_abs.append(max(iter_stats) if iter_stats else 0.0)

    out = []
    for key, obs in observed.items():
        vals = nulls.get(key, [])
        if obs is None or not vals:
            continue
        raw_p = (1 + sum(abs(x) >= abs(obs) for x in vals)) / (len(vals) + 1)
        fw_p = (1 + sum(x >= abs(obs) for x in max_abs)) / (len(max_abs) + 1)
        out.append({
            "horizon_s": key[0],
            "side": key[1],
            "observed_pnl_per_trade_gap": obs,
            "permutation_raw_two_sided_p": raw_p,
            "permutation_familywise_max_p": fw_p,
            "shuffles": shuffles,
            "strata": "date_x_coin_x_side_x_exact_segment",
        })
    return out


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    keys: list[str] = []
    for row in rows:
        for k in row:
            if k not in keys:
                keys.append(k)
    opener = gzip.open if str(path).endswith(".gz") else open
    mode = "wt" if str(path).endswith(".gz") else "w"
    with opener(path, mode, newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=keys, extrasaction="ignore")
        w.writeheader()
        w.writerows(rows)


def fmt_pct(x: float | None) -> str:
    return "n/a" if x is None else f"{100*x:.2f}%"


def fmt_num(x: float | None, digits: int = 5) -> str:
    return "n/a" if x is None else f"{x:+.{digits}f}"


def render_report(meta: dict[str, Any], rows: list[dict[str, Any]],
                  heads: list[dict[str, Any]], perms: list[dict[str, Any]]) -> str:
    counts = meta["counts"]
    lines = [
        "# CF velocity alignment v1.1",
        "",
        f"- Lane: `{meta['lane']}`",
        f"- Rows in/out: {counts.get('rows_in',0):,} / {counts.get('rows_out',0):,}",
        f"- Rows analyzed: {counts.get('OK',0):,}",
        f"- Exact PnL of analyzed population: ${sum(r['exact_pnl'] for r in rows):+,.2f}",
        f"- Contracts: {sum(r['q'] for r in rows):,.0f}",
        "",
        "Positive oriented velocity means CF was moving toward the purchased side; negative means away.",
        "The entry-price columns are reported because alignment can look useful merely by selecting cheaper contracts.",
        "",
        "## Exclusions",
        "",
        "| reason | rows |",
        "|---|---:|",
    ]
    for k, v in sorted(counts.items()):
        if k not in {"rows_in", "rows_out", "OK"}:
            lines.append(f"| {k} | {v:,} |")
    lines += [
        "",
        "## Headline",
        "",
        "| horizon | side | n toward | n away | win toward | win away | PnL/trade toward | PnL/trade away | gap | mean price toward | mean price away |",
        "|---:|:---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for x in heads:
        lines.append(
            f"| {x['horizon_s']}s | {x['side']} | {x['n_toward']:,} | {x['n_away']:,} | "
            f"{fmt_pct(x['win_rate_toward'])} | {fmt_pct(x['win_rate_away'])} | "
            f"{fmt_num(x['exact_pnl_per_trade_toward'])} | {fmt_num(x['exact_pnl_per_trade_away'])} | "
            f"{fmt_num(x['pnl_per_trade_gap'])} | {fmt_num(x['mean_price_toward'])} | "
            f"{fmt_num(x['mean_price_away'])} |"
        )
    if perms:
        lines += [
            "",
            "## Stratified permutation control",
            "",
            "Alignment labels are permuted within date × coin × side × exact drawdown segment, preserving group sizes. Familywise p-values use the maximum absolute PnL/trade gap across all 12 horizon-side tests.",
            "",
            "| horizon | side | observed gap | raw p | familywise p |",
            "|---:|:---:|---:|---:|---:|",
        ]
        for x in perms:
            lines.append(
                f"| {x['horizon_s']}s | {x['side']} | {x['observed_pnl_per_trade_gap']:+.6f} | "
                f"{x['permutation_raw_two_sided_p']:.4f} | {x['permutation_familywise_max_p']:.4f} |"
            )
    lines += [
        "",
        "## Interpretation guardrails",
        "",
        "- This is a development-period diagnostic, not a promoted rule.",
        "- PnL/trade and entry price must be read together; win rate alone is insufficient.",
        "- `velocity_contrast_*` is v_short − v_long, not physical acceleration.",
        "- `acceleration_est_*` divides the contrast by the separation of the two backward-window centers and has units bps/s².",
        "- The sealed September 7–13 holdout is refused unless explicitly allowed.",
    ]
    return "\n".join(lines) + "\n"


def run(args: argparse.Namespace) -> int:
    path = os.path.expanduser(args.rows)
    if not os.path.exists(path):
        raise FileNotFoundError(path)
    through = dt.date.fromisoformat(args.through)
    bleed_start = parse_ts(args.bleed_start)
    bleed_end = parse_ts(args.bleed_end)
    if bleed_start is None or bleed_end is None or bleed_start >= bleed_end:
        raise RuntimeError("invalid exact drawdown interval")

    rows, audit, meta = load_rows(
        path, args.lane, through, bleed_start, bleed_end, args.allow_sealed)
    if not rows:
        raise RuntimeError("no analyzed rows")

    # Verify reachability's stored contrast columns wherever present.
    contrast_mismatch = 0
    contrast_compared = 0
    for r in rows:
        for a, b in CONTRAST_PAIRS:
            d = r[f"velocity_contrast_{a}_{b}_source_diff"]
            if d is not None:
                contrast_compared += 1
                if abs(d) > 1e-10:
                    contrast_mismatch += 1
    meta["contrast_compared"] = contrast_compared
    meta["contrast_mismatch"] = contrast_mismatch
    if contrast_mismatch:
        raise RuntimeError(f"stored velocity contrasts disagree with recomputation: {contrast_mismatch}")

    heads = headline(rows)
    cells = grouped_cells(rows)
    perms = permutation_control(rows, heads, args.shuffles, args.seed)

    out = Path(os.path.expanduser(args.out))
    if out.exists() and any(out.iterdir()) and not args.force:
        raise RuntimeError(f"output directory is not empty: {out}; use --force or a new path")
    out.mkdir(parents=True, exist_ok=True)
    write_csv(out / "velocity_alignment_rows.csv.gz", audit)
    write_csv(out / "headline.csv", heads)
    write_csv(out / "group_cells.csv", cells)
    write_csv(out / "permutation_control.csv", perms)
    (out / "RUN_SUMMARY.json").write_text(json.dumps(meta, indent=2, sort_keys=True), encoding="utf-8")
    report = render_report(meta, rows, heads, perms)
    (out / "REPORT.md").write_text(report, encoding="utf-8")
    print(report)
    print(f"wrote {out}")
    return 0


def self_test() -> int:
    fails: list[str] = []

    def ck(name: str, cond: bool) -> None:
        print(f"  {name:72s} {'PASS' if cond else 'FAIL'}")
        if not cond:
            fails.append(name)

    ck("YES greater + rising -> toward",
       oriented_velocity("YES", "greater_or_equal", 2.0) == 2.0)
    ck("YES greater + falling -> away",
       oriented_velocity("YES", "greater_or_equal", -2.0) == -2.0)
    ck("NO greater + falling -> toward, not forced by abs()",
       oriented_velocity("NO", "greater_or_equal", -2.0) == 2.0)
    ck("NO greater + rising -> away",
       oriented_velocity("NO", "greater_or_equal", 2.0) == -2.0)
    ck("YES less + falling -> toward",
       oriented_velocity("YES", "less", -2.0) == 2.0)
    ck("unknown comparator fails closed",
       oriented_velocity("YES", "structured", 2.0) is None)
    ck("blank comparator fails closed",
       oriented_velocity("YES", "", 2.0) is None)
    ck("oriented velocity can be negative",
       oriented_velocity("NO", "greater_or_equal", 3.0) < 0)

    ck("velocity contrast is v_short-v_long",
       velocity_contrast(3.0, 1.0) == 2.0)
    ck("constant-acceleration estimate has correct denominator",
       abs(acceleration_estimate(3.0, 1.0, 15, 60) - (4.0 / 45.0)) < 1e-12)
    ck("constant velocity gives zero acceleration",
       acceleration_estimate(2.0, 2.0, 15, 60) == 0.0)

    ck("long toward, short away -> reversing away",
       reversal_state(-1.0, 1.0) == "REVERSING_AWAY")
    ck("long away, short toward -> reversing toward",
       reversal_state(1.0, -1.0) == "REVERSING_TOWARD")
    ck("both toward -> continuing toward",
       reversal_state(1.0, 2.0) == "CONTINUING_TOWARD")
    ck("zero is undecidable", reversal_state(0.0, 2.0) == "UNDECIDABLE")

    # Cell arithmetic including price and quantity.
    rr = [
        {"win": 1, "q": 25.0, "exact_pnl": 10.0, "scalable_pnl": 11.0,
         "price": 0.4, "date": "2026-08-01", "ticker": "T1", "burst_id": "B1"},
        {"win": 0, "q": 5.0, "exact_pnl": -2.0, "scalable_pnl": -1.9,
         "price": 0.2, "date": "2026-08-02", "ticker": "T2", "burst_id": "B2"},
    ]
    s = summarize_cell(rr)
    ck("cell counts wins and losses", s["n"] == 2 and s["wins"] == 1 and s["losses"] == 1)
    ck("cell PnL reconciles", abs(s["exact_pnl"] - 8.0) < 1e-12)
    ck("cell contracts reconcile", abs(s["contracts"] - 30.0) < 1e-12)
    ck("cell PnL/contract correct", abs(s["exact_pnl_per_contract"] - 8.0/30.0) < 1e-12)
    ck("median price reported", abs(s["median_price"] - 0.3) < 1e-12)

    print("\n" + ("ALL PASS" if not fails else "FAILURES: " + ", ".join(fails)))
    return 0 if not fails else 1


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--rows", default="~/cf_reach_v1_1/paper_bot_cf_reachability_rows.csv.gz")
    ap.add_argument("--lane", choices=("auto", "reachability", "half_skip"), default="auto")
    ap.add_argument("--out", default="~/cf_velocity_alignment_v1_1")
    ap.add_argument("--through", default=DEFAULT_THROUGH.isoformat())
    ap.add_argument("--bleed-start", default="2026-07-28T00:46:00Z")
    ap.add_argument("--bleed-end", default="2026-08-21T03:33:00Z")
    ap.add_argument("--shuffles", type=int, default=200)
    ap.add_argument("--seed", type=int, default=7)
    ap.add_argument("--allow-sealed", action="store_true")
    ap.add_argument("--force", action="store_true")
    ap.add_argument("--self-test", action="store_true")
    args = ap.parse_args()
    if args.self_test:
        return self_test()
    return run(args)


if __name__ == "__main__":
    raise SystemExit(main())
