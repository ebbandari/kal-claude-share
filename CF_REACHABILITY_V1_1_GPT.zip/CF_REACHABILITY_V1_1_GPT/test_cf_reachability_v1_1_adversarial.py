#!/usr/bin/env python3
from __future__ import annotations

import collections
import csv
import datetime as dt
import gzip
import importlib.util
import json
import math
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
SRC = HERE / "cf_reachability_v1_1_gpt.py"
spec = importlib.util.spec_from_file_location("reach", SRC)
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)

passed = failed = 0

def check(name, cond):
    global passed, failed
    ok = bool(cond)
    print(f"  {name:78s} {'PASS' if ok else 'FAIL'}")
    if ok:
        passed += 1
    else:
        failed += 1

class FakeCache:
    def __init__(self, data): self.data = data
    def series(self, coin, idx, day, hh): return self.data.get((coin, idx, day, hh), [])

class ConstantView:
    def __init__(self, price=100.0, rv=2.0):
        self.price = price; self.rv = rv
    def asof(self, coin, idx, ts): return self.price, 0.0, ts
    def feature_window(self, coin, idx, ts, h):
        return {"n": max(2, int(h*5)), "max_gap_s": 0.2, "rv_bps": self.rv,
                "first_ts": ts-h, "last_ts": ts}
    def feature_windows(self, coin, idx, ts, horizons):
        return {int(h): self.feature_window(coin, idx, ts, int(h)) for h in horizons}


def base_row(**overrides):
    t = dt.datetime(2026, 8, 3, 15, tzinfo=dt.timezone.utc).timestamp()
    r = dict(coin="BTC", side="YES", stc="300", size="1",
             reconstructed_ask="0.50", logged_cost="0.40", reprice_eligible="1",
             pnl_ask_exact="0.48", pnl_ask_scalable="0.4825",
             pnl_logged_exact="0.58", pnl_logged_scalable="0.5832",
             cb_confirm_raw_usd="1.0", pm_confirm_probability="0.02",
             _row_id=1, _t=t, _K=100.0, _cmp="greater_or_equal",
             _src="LIFECYCLE_ASOF")
    r.update(overrides)
    return r


def make_ref(n=400, values=(10.0,), coin="BTC", h=300,
             session="USsession", weekday="Mon"):
    r = m.Reference()
    for i in range(n):
        r.add(coin, h, session, weekday, f"2026-W{30+i//100:02d}", f"2026-08-{1+(i//20)%28:02d}", values[i % len(values)])
    return r

print("CF REACHABILITY v1.1 ADVERSARIAL TESTS")

# 1-4: settlement window exactness.
close = dt.datetime(2026, 8, 1, 14, tzinfo=dt.timezone.utc).timestamp()
day = "2026-08-01"
rows60 = [(close-60+i, 100.0+i/100.0) for i in range(60)]
view = m.CFView(FakeCache({("BTC","BRTI",day,13): rows60, ("BTC","BRTI",day,14): []}))
mean, n, st = view.final_minute_mean("BTC","BRTI",close)
check("exact 60 .000 observations are accepted", st == "OK" and n == 60 and mean is not None)
rows59 = rows60[:-1]
view = m.CFView(FakeCache({("BTC","BRTI",day,13): rows59, ("BTC","BRTI",day,14): []}))
mean, n, st = view.final_minute_mean("BTC","BRTI",close)
check("59 of 60 settlement observations fail closed", mean is None and n == 59)
rows_extra = rows60 + [(close-60+i+0.999, 1000.0) for i in range(60)]
view = m.CFView(FakeCache({("BTC","BRTI",day,13): rows_extra, ("BTC","BRTI",day,14): []}))
mean, n, st = view.final_minute_mean("BTC","BRTI",close)
check(".999 observations are not mistaken for the .000 settlement series",
      st == "OK" and n == 60 and mean < 200)
rows_close = rows60 + [(close, 9999.0)]
view = m.CFView(FakeCache({("BTC","BRTI",day,13): rows60, ("BTC","BRTI",day,14): [(close,9999.0)]}))
mean2, n2, st2 = view.final_minute_mean("BTC","BRTI",close)
check("close-boundary observation is excluded by [T-60,T)", st2 == "OK" and abs(mean2 - sum(v for _,v in rows60)/60) < 1e-12)

# 5-6: archive duplicate/amendment handling and gzip validation.
with tempfile.TemporaryDirectory() as td:
    root = Path(td)
    p = root/"BTC"/"BRTI"/day/"13.csv.gz"; p.parent.mkdir(parents=True)
    with gzip.open(p,"wt",newline="") as fh:
        w=csv.DictWriter(fh,fieldnames=["timestamp_utc","value_float64","amend_time_ms"]); w.writeheader()
        w.writerow({"timestamp_utc":"2026-08-01T13:00:00.000Z","value_float64":"100","amend_time_ms":"1"})
        w.writerow({"timestamp_utc":"2026-08-01T13:00:00.000Z","value_float64":"101","amend_time_ms":"2"})
    c=object.__new__(m.CFCache); c.root=root
    got=m.CFCache.series(c,"BTC","BRTI",day,13)
    check("latest amendment wins for an identical CF timestamp", len(got)==1 and got[0][1]==101.0)
    check("full valid gzip/schema validation succeeds", m.validate_cf_file(p)["rows"]==2)
    bad=root/"bad.csv.gz"; bad.write_bytes(p.read_bytes()[:-8])
    threw=False
    try: m.validate_cf_file(bad)
    except Exception: threw=True
    check("truncated gzip is rejected rather than accepted after reading its header", threw)

# Availability lag: a source print that had not arrived by decision time is refused.
decision = dt.datetime(2026,8,1,13,30,tzinfo=dt.timezone.utc).timestamp()
lag_rows=[(decision-0.30,100.0),(decision-0.10,101.0)]
view_lag=m.CFView(FakeCache({("BTC","BRTI",day,13):lag_rows}),availability_lag_s=0.25)
v,age,src=view_lag.asof("BTC","BRTI",decision)
check("availability lag excludes a source print too recent to be knowable", v==100.0 and abs(age-0.30)<1e-6)
fw=view_lag.feature_windows("BTC","BRTI",decision,(5,))[5]
check("feature windows end at the causal availability cutoff", fw["last_ts"]==decision-0.30)

# 7-10: reference construction uses the correct horizon-specific context and truth.
class RefView:
    def __init__(self, final=100.0): self.final=final
    def final_minute_mean(self, coin, idx, close): return self.final, 60, "OK"
    def asof(self, coin, idx, ts): return 90.0, 0.0, ts

close2 = dt.datetime(2026,8,3,13,40,tzinfo=dt.timezone.utc).timestamp()
events, stats = m.build_reference([{"coin":"BTC","close":close2}], RefView(), {}, lambda s:None)
obs = {x[0]:x for x in events[0][2]}
check("120s horizon is assigned to its own US-session decision time", m.session_of(obs[120][2])=="USsession")
check("870s horizon is assigned to its own European-session decision time", m.session_of(obs[870][2])=="EuropeanAM")
truth={("BTC",int(round(close2))):110.0}
events, stats = m.build_reference([{"coin":"BTC","close":close2}], RefView(final=80.0), truth, lambda s:None)
move120=next(x[1] for x in events[0][2] if x[0]==120)
check("API expiration truth overrides reconstructed final average when available",
      abs(move120 - 1e4*math.log(110/90)) < 1e-9 and stats["api_truth_used"]==1)
check("reference grid provides seven-week prehistory independently of strike capture",
      len(m.reference_closes(dt.date(2026,5,27),dt.date(2026,5,27)))==96*6)

# 11-17: gating and economics.
stats=collections.Counter(); out=m.evaluate(base_row(),ConstantView(),make_ref(150),stats)
check("100-299 reference observations are descriptive, never gateable",
      out["status"]=="DESCRIPTIVE_REFERENCE" and out["reference_gateable"]==0)
check("descriptive cells cannot emit near-impossible trading decisions",
      out.get("near_impossible_exact","")=="")
out=m.evaluate(base_row(reconstructed_ask=""),ConstantView(),make_ref(400),collections.Counter())
check("missing displayed ask never falls back to logged price",
      out["economic_status"]=="MISSING_EXECUTABLE_PRICE" and "break_even_p_exact" not in out)
out=m.evaluate(base_row(reprice_eligible="0"),ConstantView(),make_ref(400),collections.Counter())
check("reprice-ineligible row cannot enter the economic gate", out["economic_status"]=="REPRICE_INELIGIBLE")
out=m.evaluate(base_row(size="0"),ConstantView(),make_ref(400),collections.Counter())
check("zero size is rejected rather than silently converted to one", out["economic_status"]=="INVALID_SIZE")
out=m.evaluate(base_row(side="BOGUS"),ConstantView(),make_ref(400),collections.Counter())
check("unknown purchased side fails closed", out["status"]=="UNKNOWN_SIDE")
out=m.evaluate(base_row(),ConstantView(),make_ref(400,values=(-100.0,)),collections.Counter())
check("gateable cell may flag an economically impossible upper-tail trade",
      out["reference_gateable"]==1 and out.get("near_impossible_exact")==1)

# 18-21: comparator orientation.
r_mix=make_ref(400,values=(-10.0,10.0))
for cmpx,side,want_upper,name in [
    ("greater_or_equal","YES",1,"greater YES uses upper tail"),
    ("greater_or_equal","NO",0,"greater NO uses lower tail"),
    ("less_or_equal","YES",0,"less YES uses lower tail"),
    ("less_or_equal","NO",1,"less NO uses upper tail")]:
    out=m.evaluate(base_row(_cmp=cmpx,side=side),ConstantView(),r_mix,collections.Counter())
    check(name, out.get("needs_upper_tail")==want_upper)

# 22-25: quantiles / uncertainty / new requested margin output.
out=m.evaluate(base_row(),ConstantView(),r_mix,collections.Counter())
check("required-move percentile bounds are emitted", all(k in out for k in ("required_move_cdf_bin_lo","required_move_cdf_bin_hi","required_move_cdf_dkw_lo","required_move_cdf_dkw_hi")))
check("projected final-average quantiles are emitted", all(k in out for k in ("pred_final_avg_p10","pred_final_avg_p50","pred_final_avg_p90")))
check("side-oriented strike clearance is emitted", "side_clearance_vs_K_q90_bps" in out and "side_projected_clearance_native_q90" in out)
check("quantile uncertainty shrinks as reference n grows", m.dkw_epsilon(1000)<m.dkw_epsilon(100))

# 26-29: feature completeness and normalization.
check("5/15/30/60/120/300s velocity features exist", all(f"vel_{h}s_bps_per_s" in out for h in m.VEL_HORIZONS))
check("realized-volatility features exist", all(f"rv_{h}s_bps" in out for h in m.VEL_HORIZONS))
check("distance is normalized by recent volatility", out.get("distance_vol_normalized","")!="")
check("Coinbase raw-dollar confirmation is explicitly normalized against K",
      abs(float(out["cb_confirm_bps_vs_strike"])-100.0)<1e-9 and out["cb_confirm_normalization_status"]=="OK_STRIKE_PROXY")
out_h=m.evaluate(base_row(coin="HYPE",_K=50.0),ConstantView(price=50),make_ref(400,coin="HYPE"),collections.Counter())
check("HYPE Coinbase absence is structural, not generic missingness",
      out_h.get("cb_confirm_normalization_status")=="NO_COINBASE_MARKET")

# 30-34: holdout, rows-in/out and conflicts.
with tempfile.TemporaryDirectory() as td:
    td=Path(td); base=td/"base.csv"; cov=td/"cov.csv"
    with cov.open("w",newline="") as fh:
        w=csv.DictWriter(fh,fieldnames=["ticker","strike_final","comparator_final","strike_source_final"]);w.writeheader()
        w.writerow({"ticker":"T","strike_final":"100","comparator_final":"greater_or_equal","strike_source_final":"API_RECOVERED"})
    with base.open("w",newline="") as fh:
        w=csv.DictWriter(fh,fieldnames=["t_entry","ticker","coin","side","stc"]);w.writeheader()
        w.writerow({"t_entry":"bad","ticker":"T","coin":"BTC","side":"YES","stc":"300"})
    rows=m.load_opportunities(str(base),str(cov),dt.date(2026,9,6),lambda s:None)
    check("malformed decision time survives for explicit row-level status", len(rows)==1 and rows[0]["_t"] is None)
    out_bad=m.evaluate(rows[0],ConstantView(),m.Reference(),collections.Counter())
    check("malformed decision time is labelled, not silently dropped", out_bad["status"]=="INVALID_DECISION_TIME")
    with base.open("w",newline="") as fh:
        w=csv.DictWriter(fh,fieldnames=["t_entry","ticker","coin","side","stc"]);w.writeheader()
        w.writerow({"t_entry":dt.datetime(2026,9,9,tzinfo=dt.timezone.utc).timestamp(),"ticker":"T","coin":"BTC","side":"YES","stc":"300"})
    refused=False
    try: m.load_opportunities(str(base),str(cov),dt.date(2026,9,6),lambda s:None)
    except RuntimeError: refused=True
    check("sealed holdout row aborts the development load", refused)
    with cov.open("a",newline="") as fh:
        w=csv.DictWriter(fh,fieldnames=["ticker","strike_final","comparator_final","strike_source_final"])
        w.writerow({"ticker":"T","strike_final":"101","comparator_final":"greater_or_equal","strike_source_final":"API_RECOVERED"})
    mp=m.load_strike_map(str(cov))
    check("conflicting strike rows fail closed", mp["T"][2]=="STRIKE_CONFLICT")

# 35-38: index switch, horizon and cache request safety.
check("HYPE pre-switch uses U_HYPEUSD_RTI", m.index_for("HYPE",dt.datetime(2026,6,10,tzinfo=dt.timezone.utc).timestamp())=="U_HYPEUSD_RTI")
check("HYPE switch day is excluded rather than guessed", m.index_for("HYPE",dt.datetime(2026,6,11,tzinfo=dt.timezone.utc).timestamp()) is None)
check("ceil horizon never understates actual STC", m.ceil_horizon(121)==135 and m.ceil_horizon(869)==870)
log=[]
jobs=m.cache_jobs([{"coin":"BTC","close":dt.datetime(2026,8,1,0,tzinfo=dt.timezone.utc).timestamp()}],[],log.append)
check("cache jobs cross UTC midnight correctly", any(j[2]=="2026-07-31" and j[3]==23 for j in jobs))

# 39-40: expiration truth namespace.
with tempfile.TemporaryDirectory() as td:
    p=Path(td)/"cache.jsonl"
    rec={"ticker":"KXBTC15M-X","api_status":"OK","expiration_value":"100.5","close_time":"2026-08-01T14:00:00Z"}
    p.write_text(json.dumps(rec)+"\n")
    truth=m.load_expiration_truth(str(p),dt.date(2026,9,6),lambda s:None)
    key=("BTC",int(dt.datetime(2026,8,1,14,tzinfo=dt.timezone.utc).timestamp()))
    check("API expiration value loads into label-only close-time namespace", truth.get(key)==100.5)
    p.write_text(json.dumps(rec)+"\n"+json.dumps(dict(rec,expiration_value="101"))+"\n")
    threw=False
    try: m.load_expiration_truth(str(p),dt.date(2026,9,6),lambda s:None)
    except RuntimeError: threw=True
    check("conflicting expiration truths fail closed", threw)

# 41-43: static implementation contracts.
src=SRC.read_text()
check("cache-only stage is implemented, not merely parsed", 'if a.stage == "cache"' in src)
check("no subprocess/gsutil implementation path exists", "import subprocess" not in src and "gsutil" not in src)
check("all output rows retain a source row id for reconciliation", 'out["source_row_id"]' in src)

print(f"\nRESULT: {passed} passed, {failed} failed")
raise SystemExit(1 if failed else 0)
