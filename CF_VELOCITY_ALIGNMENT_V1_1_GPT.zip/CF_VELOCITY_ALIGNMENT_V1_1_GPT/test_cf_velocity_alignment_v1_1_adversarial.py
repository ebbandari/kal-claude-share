#!/usr/bin/env python3
from __future__ import annotations

import csv
import datetime as dt
import gzip
import importlib.util
import json
import math
import subprocess
import sys
import tempfile
from pathlib import Path

SCRIPT = Path(__file__).with_name("cf_velocity_alignment_v1_1_gpt.py")
spec = importlib.util.spec_from_file_location("m", SCRIPT)
m = importlib.util.module_from_spec(spec)
assert spec.loader is not None
spec.loader.exec_module(m)

PASS = 0
FAIL = 0


def check(name, cond):
    global PASS, FAIL
    if cond:
        PASS += 1
        print(f"  {name:78s} PASS")
    else:
        FAIL += 1
        print(f"  {name:78s} FAIL")


def T(s):
    return dt.datetime.fromisoformat(s.replace("Z", "+00:00")).timestamp()


def base_vels(sign=1.0):
    d = {}
    for h in m.VEL_HORIZONS:
        d[f"vel_{h}s_bps_per_s"] = str(sign * (1 + h / 1000))
    for a, b in m.CONTRAST_PAIRS:
        d[f"accel_{a}_{b}_bps_per_s"] = str(
            float(d[f"vel_{a}s_bps_per_s"]) - float(d[f"vel_{b}s_bps_per_s"]))
    d["rv_60s_bps"] = "2.5"
    return d


def write_gz(path, rows):
    keys = []
    for r in rows:
        for k in r:
            if k not in keys:
                keys.append(k)
    with gzip.open(path, "wt", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader(); w.writerows(rows)


def reach_row(i=0, **kw):
    r = {
        "t_entry": str(T("2026-08-01T12:00:00Z") + i),
        "ticker": f"KXBTC15M-X{i}",
        "burst_id": f"B{i//2}",
        "coin": "BTC",
        "comparator_final": "greater_or_equal",
        "status": "OK",
        "economic_status": "OK",
        "reference_gateable": "1",
        "side": "YES",
        "win": "1" if i % 2 == 0 else "0",
        "pnl_ask_exact": "0.4" if i % 2 == 0 else "-0.6",
        "pnl_ask_scalable": "0.41" if i % 2 == 0 else "-0.59",
        "reconstructed_ask": "0.58",
    }
    r.update(base_vels(1.0 if i % 3 else -1.0))
    r.update(kw)
    return r


def half_row(i=0, **kw):
    r = reach_row(i)
    r.update({
        "reversal_status": "OK",
        "original_side": r["side"],
        "half_B_CF_SKIP_ONLY_action": "TAKE",
        "half_B_CF_SKIP_ONLY_final_side": r["side"],
        "half_B_CF_SKIP_ONLY_realized_win": r["win"],
        "half_B_CF_SKIP_ONLY_exact": "10.0" if r["win"] == "1" else "-5.0",
        "half_B_CF_SKIP_ONLY_scalable": "10.1" if r["win"] == "1" else "-4.9",
        "half_B_CF_SKIP_ONLY_q": "25",
        "half_B_CF_SKIP_ONLY_price": "0.40",
    })
    r.update(kw)
    return r


# Primitive logic
check("raw rising YES is toward", m.alignment_label(m.oriented_velocity("YES", "greater", 1)) == "TOWARD")
check("raw rising NO is away", m.alignment_label(m.oriented_velocity("NO", "greater", 1)) == "AWAY")
check("raw falling NO is toward", m.alignment_label(m.oriented_velocity("NO", "greater", -1)) == "TOWARD")
check("orientation does not use absolute value", m.oriented_velocity("NO", "greater", 1) == -1)
check("blank comparator fails closed", m.direction_sign("YES", "") is None)
check("garbage comparator fails closed", m.direction_sign("YES", "greaterish") is None)
check("less comparator flips YES orientation", m.oriented_velocity("YES", "less", -1) == 1)

# Acceleration / contrast
check("contrast keeps velocity units", m.velocity_contrast(2, 1) == 1)
check("acceleration estimate divides by center separation",
      m.acceleration_estimate(2, 1, 15, 60) == 2/45)
check("future C(t+h) is not needed", "t+h" not in m.acceleration_estimate.__doc__.lower())
check("reversing away classified", m.reversal_state(-1, 1) == "REVERSING_AWAY")
check("reversing toward classified", m.reversal_state(1, -1) == "REVERSING_TOWARD")

with tempfile.TemporaryDirectory() as td:
    td = Path(td)

    # Reachability lane: only economic+gateable rows enter; missing PnL is not zero.
    rows = [reach_row(i) for i in range(20)]
    rows += [reach_row(100, ticker="BAD_ECON", economic_status="NO"),
             reach_row(101, ticker="BAD_GATE", reference_gateable="0"),
             reach_row(102, ticker="BAD_PNL", pnl_ask_exact=""),
             reach_row(103, ticker="BAD_CMP", comparator_final=""),
             reach_row(104, ticker="BAD_STATUS", status="STALE_CF")]
    rp = td / "reach.csv.gz"
    write_gz(rp, rows)
    got, audit, meta = m.load_rows(str(rp), "reachability", dt.date(2026, 9, 6),
                                   m.DEFAULT_BLEED_START, m.DEFAULT_BLEED_END)
    check("reachability rows in equals audit rows out", len(audit) == len(rows))
    check("only economic gateable valid rows analyzed", len(got) == 20)
    check("economic-ineligible row counted", meta["counts"].get("ECONOMIC_STATUS_NOT_OK") == 1)
    check("ungateable row counted", meta["counts"].get("REFERENCE_NOT_GATEABLE") == 1)
    check("missing PnL excluded rather than converted to zero", meta["counts"].get("MISSING_EXACT_PNL") == 1)
    check("blank comparator excluded", meta["counts"].get("UNKNOWN_COMPARATOR") == 1)
    check("source status excluded", meta["counts"].get("SOURCE_STATUS_NOT_OK") == 1)
    check("reachability quantity is exactly one", all(r["q"] == 1 for r in got))
    check("stored contrast column resolves and reconciles",
          all(abs(r["velocity_contrast_15_60_source_diff"] or 0) < 1e-12 for r in got))

    # Half-skip lane: policy skips excluded; actual q/price/PnL used.
    hrows = [half_row(i) for i in range(12)]
    hrows.append(half_row(50, ticker="SKIP", half_B_CF_SKIP_ONLY_action="SKIP",
                           half_B_CF_SKIP_ONLY_q="0", half_B_CF_SKIP_ONLY_exact="0"))
    hp = td / "half.csv.gz"
    write_gz(hp, hrows)
    hgot, haudit, hmeta = m.load_rows(str(hp), "half_skip", dt.date(2026, 9, 6),
                                      m.DEFAULT_BLEED_START, m.DEFAULT_BLEED_END)
    check("half lane preserves rows in audit", len(haudit) == len(hrows))
    check("half lane analyzes TAKE rows only", len(hgot) == 12)
    check("policy skip explicitly counted", hmeta["counts"].get("POLICY_SKIPPED") == 1)
    check("half lane uses actual quantity", all(r["q"] == 25 for r in hgot))
    check("half lane uses policy price", all(r["price"] == 0.40 for r in hgot))
    check("half lane uses policy exact PnL", {r["exact_pnl"] for r in hgot} == {10.0, -5.0})

    # Sealed and post-cutoff rows are refused, not silently ignored.
    sealed = [reach_row(0, t_entry=str(T("2026-09-09T12:00:00Z")))]
    sp = td / "sealed.csv.gz"; write_gz(sp, sealed)
    try:
        m.load_rows(str(sp), "reachability", dt.date(2026, 9, 6),
                    m.DEFAULT_BLEED_START, m.DEFAULT_BLEED_END)
        ok = False
    except RuntimeError as e:
        ok = "sealed" in str(e)
    check("sealed holdout is refused", ok)

    after = [reach_row(0, t_entry=str(T("2026-09-14T12:00:00Z")))]
    ap = td / "after.csv.gz"; write_gz(ap, after)
    try:
        m.load_rows(str(ap), "reachability", dt.date(2026, 9, 6),
                    m.DEFAULT_BLEED_START, m.DEFAULT_BLEED_END)
        ok = False
    except RuntimeError as e:
        ok = "after development cutoff" in str(e)
    check("post-development rows are refused", ok)

    # Duplicate identity refusal.
    dup = [reach_row(1), reach_row(1)]
    dp = td / "dup.csv.gz"; write_gz(dp, dup)
    try:
        m.load_rows(str(dp), "reachability", dt.date(2026, 9, 6),
                    m.DEFAULT_BLEED_START, m.DEFAULT_BLEED_END)
        ok = False
    except RuntimeError as e:
        ok = "duplicate opportunity" in str(e)
    check("duplicate opportunity identity is refused", ok)

    # End-to-end outputs and overwrite guard.
    out = td / "out"
    cmd = [sys.executable, str(SCRIPT), "--rows", str(hp), "--lane", "half_skip",
           "--out", str(out), "--shuffles", "10"]
    p = subprocess.run(cmd, capture_output=True, text=True)
    check("synthetic end-to-end exits zero", p.returncode == 0)
    for fn in ("REPORT.md", "headline.csv", "group_cells.csv",
               "permutation_control.csv", "velocity_alignment_rows.csv.gz",
               "RUN_SUMMARY.json"):
        check(f"end-to-end writes {fn}", (out / fn).exists())
    summary = json.loads((out / "RUN_SUMMARY.json").read_text())
    check("end-to-end records lane", summary["lane"] == "half_skip")
    check("end-to-end rows reconcile", summary["counts"]["rows_in"] == summary["counts"]["rows_out"])
    p2 = subprocess.run(cmd, capture_output=True, text=True)
    check("nonempty output directory is refused", p2.returncode != 0 and "not empty" in (p2.stderr + p2.stdout))

print(f"\n{PASS} passed, {FAIL} failed")
raise SystemExit(1 if FAIL else 0)
