# CF Velocity Alignment v1 — audit and v1.1 changes

## Ruling

Do not use the submitted v1 unchanged for economic conclusions.

Its core question is useful: whether CF was moving toward or away from the side
selected by the contagion paper bot. Its embedded tests pass. But several
production-path defects change the population, the economics, or the inference.

## Answer-changing defects in v1

1. **Wrong economic population.** `status == OK` admits rows that are not
   `economic_status == OK` or `reference_gateable == 1`.
2. **Missing PnL becomes zero.** `r["pe"] or 0.0` silently converts absent
   executable economics into a zero-dollar observation while retaining the row
   in counts and win rates.
3. **It does not analyze the current half-touch CF-skip-only candidate.** It
   defaults to the one-contract reachability table. v1.1 supports both lanes
   explicitly.
4. **Blank comparator defaults to `greater_or_equal`.** v1.1 fails closed.
5. **The actual acceleration columns are missed.** Reachability v1.1 writes
   `accel_5_30_bps_per_s`, etc.; v1 searched only `accel_5_30` and
   `accel_5s_30s`.
6. **Those fields are not physical acceleration anyway.** They are
   `v_short - v_long`, a multi-scale velocity contrast with velocity units.
   v1.1 reports the contrast honestly and also derives a constant-acceleration
   estimate `2*(v_short-v_long)/(h_long-h_short)` in bps/s².
7. **No holdout/cutoff refusal.** v1 would include September 7–13 or later rows
   if pointed at such a file.
8. **No duplicate-opportunity guard.** Duplicate rows can inflate counts.
9. **Shuffle control is not a permutation.** It generates independent 50/50
   labels, does not preserve the observed aligned share, pools YES and NO null
   draws, and does not correct the 12 horizon-side comparisons.
10. **Total dollars alone are confounded by group size.** v1.1 reports total
    dollars, PnL/trade, PnL/contract, win rate, quantity, and entry price.
11. **Regimes use whole dates rather than the measured peak/trough timestamps.**
    v1.1 defaults to the exact 2026-07-28 00:46 through 2026-08-21 03:33 UTC
    drawdown interval.
12. **No machine-readable output or row reconciliation.** v1.1 writes the
    analyzed/audit rows, headline, grouped cells, permutation results, report,
    and run summary with rows-in = rows-out.

## v1.1 lanes

- `reachability`: one-contract, executable-ask rows; requires `status=OK`,
  `economic_status=OK`, and `reference_gateable=1`.
- `half_skip`: current half-touch, cap-25 CF-skip-only candidate; requires
  `half_B_CF_SKIP_ONLY_action=TAKE` and uses that policy's quantity, price,
  outcome, and exact PnL.

Run both. The first asks whether path direction carries broad information. The
second asks whether it helps the actual positive development candidate.

## Verification

- Original script compiles and its embedded tests pass.
- v1.1 compiles and its embedded tests pass.
- Independent adversarial suite: 40 passed, 0 failed.
- Synthetic end-to-end runs for both input lanes pass.
