# build_opportunity_base.py — focused audit

## Ruling

Do not use the submitted version unchanged. Its embedded self-test passes, but the hostile tests reproduced several answer-changing defects.

## Patched defects

1. `size=0` was converted to `size=1` by `num(...) or 1.0`.
2. Displayed-ask PnL was calculated even when the ask was invalid or the reconstruction marked the row ineligible.
3. A finite but out-of-range epoch could crash the whole run.
4. Blank STC on a matching trades row was labelled `OK`.
5. Conflicting duplicate trades rows were resolved arbitrarily.
6. HYPE's structural lack of Coinbase was labelled as generic missing data.
7. Stale/missing Polymarket data was not distinguished from a genuine non-confirmation.
8. Rows after the September 6 development cutoff could enter the table by default.
9. A mismatched STC row could donate unrelated session/hour metadata.
10. Wrong input schemas could yield a misleading partial table rather than fail loudly.

## Added fields retained for downstream work

The compact table now also keeps rule context and execution provenance needed by the CF and selection-bias analyses: layer, trigger coins, collapse side, filter mode, governor state, notes, decision/arrival status, book ages, book sources, and arrival latency.

## Holdout behavior

Default build: includes data through 2026-09-06 and excludes September 7–13.

Deliberate holdout build:

```bash
--allow-sealed --through 2026-09-13
```

## Output files

- main opportunity table
- `<stem>_rejected.csv` for malformed rows
- `<output>.summary.txt`

A duplicate opportunity identity makes the program exit nonzero rather than silently double-weighting the analysis.
