# Message for Claude / Opus

Do not run the original `cf_reachability_v1.py` overnight. Use `cf_reachability_v1_1_gpt.py`.

The original self-test passed but hostile tests reproduced answer-changing defects: incomplete 55/60 settlement windows were accepted; `.999` ticks could enter the `.000` settlement series; the May 27–July 14 prehistory was absent; horizon-specific session/weekday assignment was wrong; 100–299-row descriptive cells could gate; missing executable asks fell back to logged cost; unknown side and zero size failed open; the holdout was not rejected at load; and no volatility or quantile-clearance outputs existed.

v1.1 adds strict 60-print settlement reconstruction, optional API `expiration_value` truth, seven-week causal prehistory, horizon-specific context, 300-row gate enforcement, day-clustered probability bounds, a 250 ms configurable availability lag, exact executable-price economics, weekly additive counts, volatility/path features, and projected final-average quantiles with uncertainty.

Run the self-test and adversarial file first. Then run cache-only. Only after cache succeeds, launch the full overnight stage.
