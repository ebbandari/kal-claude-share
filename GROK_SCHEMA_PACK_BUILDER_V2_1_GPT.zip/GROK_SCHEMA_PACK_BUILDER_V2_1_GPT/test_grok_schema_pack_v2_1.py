from __future__ import annotations

import csv
import gzip
import importlib.util
import json
import tempfile
import sys
from pathlib import Path

import pytest

HERE = Path(__file__).resolve().parent
SCRIPT = HERE / "build_grok_schema_pack_v2_1_gpt.py"
spec = importlib.util.spec_from_file_location("grok_builder", SCRIPT)
mod = importlib.util.module_from_spec(spec)
assert spec and spec.loader
sys.modules[spec.name] = mod
spec.loader.exec_module(mod)


def test_receive_clock_preferred_csv():
    d, _ = mod.describe_csv_lines(iter([
        "recv_ts_utc,exchange_ts,value\n",
        "2026-09-06T13:45:10Z,2026-09-06T13:45:09Z,1\n",
    ]))
    assert d["timestamp_field"] == "recv_ts_utc"


def test_receive_clock_preferred_json():
    obj = {
        "local_receive_ts_utc": "2026-09-06T13:45:10Z",
        "source_ts_utc": "2026-09-06T13:45:09Z",
    }
    t, key = mod.find_json_time(obj)
    assert key == "local_receive_ts_utc"
    assert mod.timestamp_clock_role(key) == "receive/local"


def test_disordered_tail_does_not_drop_late_csv_row(tmp_path: Path):
    dest = tmp_path / "x.csv"
    lines = ["exchange_ts,value\n", "2026-09-06T13:45:00Z,1\n"]
    lines += [f"2026-09-06T14:10:{i % 60:02d}Z,2\n" for i in range(100)]
    lines += ["2026-09-06T13:46:00Z,3\n"]
    st = mod.extract_csv_lines(
        iter(lines), "test", dest,
        mod.parse_time("2026-09-06T13:44:00Z"),
        mod.parse_time("2026-09-06T14:02:00Z"),
    )
    rows = list(csv.DictReader(dest.open()))
    assert st.rows_written == 2
    assert any(r["value"] == "3" for r in rows)
    assert st.monotonic_violations >= 1


def test_disordered_tail_does_not_drop_late_json_row(tmp_path: Path):
    dest = tmp_path / "x.jsonl"
    rows = [json.dumps({"source_ts_utc": "2026-09-06T13:45:00Z", "v": 1}) + "\n"]
    rows += [json.dumps({"source_ts_utc": f"2026-09-06T14:10:{i % 60:02d}Z", "v": 2}) + "\n"
             for i in range(100)]
    rows += [json.dumps({"source_ts_utc": "2026-09-06T13:46:00Z", "v": 3}) + "\n"]
    st = mod.extract_jsonl_lines(
        iter(rows), "test", dest,
        mod.parse_time("2026-09-06T13:44:00Z"),
        mod.parse_time("2026-09-06T14:02:00Z"),
    )
    vals = [json.loads(x)["v"] for x in dest.read_text().splitlines()]
    assert vals == [1, 3]
    assert st.monotonic_violations >= 1


def _gz_csv(header: list[str], rows: list[list[str]]) -> bytes:
    import io
    sio = io.StringIO()
    w = csv.writer(sio, lineterminator="\n")
    w.writerow(header)
    w.writerows(rows)
    return gzip.compress(sio.getvalue().encode(), mtime=0)


def test_metadata_includes_exception_root_and_blank_strike(tmp_path: Path):
    w = tmp_path / "window" / "BTC"
    e = tmp_path / "exception" / "HYPE"
    w.mkdir(parents=True)
    e.mkdir(parents=True)
    header = ["recv_ts_utc", "market_ticker", "close_time", "floor_strike", "seconds_to_close"]
    (w / "kalshi_snapshots.csv.gz").write_bytes(_gz_csv(header, [[
        "2026-09-06T13:45:00Z", "KXBTC", "2026-09-06T14:00:00Z", "100", "900"
    ]]))
    (e / "kalshi_snapshots.csv.gz").write_bytes(_gz_csv(header, [[
        "2026-09-06T13:45:00Z", "KXHYPE", "2026-09-06T14:00:00Z", "", "900"
    ]]))
    out = tmp_path / "metadata.csv"
    n = mod.build_metadata_sample([tmp_path / "window", tmp_path / "exception"], out)
    rows = list(csv.DictReader(out.open()))
    assert n == 2
    assert {r["coin"] for r in rows} == {"BTC", "HYPE"}
    assert next(r for r in rows if r["coin"] == "HYPE")["floor_strike"] == ""


def test_v9_discovery_does_not_use_recursive_bucket_wildcard():
    class Recorder:
        def __init__(self):
            self.patterns = []
        def list(self, pattern):
            self.patterns.append(pattern)
            return []
    store = Recorder()
    assert mod.discover_v9_zip(store, "gs://bucket", "2026-09-06", "USsession") is None
    assert store.patterns
    assert all("/**/" not in p for p in store.patterns)


def test_readme_documents_clock_policy():
    report = mod.BuildReport()
    args = type("A", (), {"date": "2026-09-06", "market_open": "13:45"})()
    text = mod._readme(
        args,
        mod.parse_time("2026-09-06T13:44:00Z"),
        mod.parse_time("2026-09-06T14:02:00Z"),
        ["BTC", "SOL"], "HYPE", report,
    )
    assert "use receive/local" in text
    assert "exception coin" in text.lower()
    assert "--v9-uri" in text


def test_no_gcs_mutation_commands_in_source():
    src = SCRIPT.read_text()
    assert "gsutil", "sanity"
    # Read-only commands are allowed. There must be no rm/mv/rsync and no cp to a gs:// destination.
    for banned in ('"rm"', '"mv"', '"rsync"'):
        assert banned not in src
    assert "GCS access through gsutil. The builder never writes to GCS" in src


def test_embedded_self_test_passes():
    assert mod.self_test() == 0
