#!/usr/bin/env python3
from __future__ import annotations

import csv
import datetime as dt
import importlib.util
import tempfile
from pathlib import Path

MODULE_PATH = Path(__file__).with_name('build_opportunity_base_v1_1_gpt.py')
spec = importlib.util.spec_from_file_location('oppbase', MODULE_PATH)
m = importlib.util.module_from_spec(spec)
assert spec.loader is not None
spec.loader.exec_module(m)


def write_csv(path: Path, rows: list[dict]) -> None:
    keys: list[str] = []
    for row in rows:
        for key in row:
            if key not in keys:
                keys.append(key)
    with path.open('w', newline='', encoding='utf-8') as fh:
        w = csv.DictWriter(fh, fieldnames=keys)
        w.writeheader()
        w.writerows(rows)


def ts(s: str) -> float:
    return dt.datetime.fromisoformat(s).timestamp()


def base_row(t: float | str = '2026-08-01T14:00:00+00:00', **kw) -> dict:
    t = ts(t) if isinstance(t, str) else t
    row = dict(
        t_entry=repr(t), ticker='KXBTC15M-A', sib='BTC', opp='YES',
        cost='0.40', size='1', win='1', burst_id='b1', layer='shadow',
        trig_coins='ETH,SOL', side_collapsing='NO', filter_mode='shadow',
        governor_state='normal', would_skip='0', note='x',
        primary_repriced_ask='0.45', primary_marketable_at_logged_limit='0',
        primary_reprice_eligible='1', primary_reprice_direction='PAY_UP',
        arrival_capacity_at_touch='10', conservative_execution_evidence='1',
        arrival_status='OK', decision_status='OK', arrival_book_age_s='0.4',
        decision_book_age_s='0.2', arrival_book_source='kcp_ticker_l1',
        decision_book_source='kcp_ticker_l1', arrival_latency_ms='500',
        cb_confirm='0.02', pm_confirm='0.03', feed_stale='0',
    )
    row.update(kw)
    return row


def trade_row(t: float | str = '2026-08-01T14:00:00+00:00', **kw) -> dict:
    t = ts(t) if isinstance(t, str) else t
    row = dict(t=repr(t), ticker='KXBTC15M-A', opp='YES', stc='300',
               session='USsession', dow='Saturday', hour='14')
    row.update(kw)
    return row


def run(rows: list[dict], trades: list[dict], *, allow_sealed=False, through=None):
    td = tempfile.TemporaryDirectory()
    root = Path(td.name)
    rp, tr, out = root/'reprice.csv', root/'trades.csv', root/'base.csv'
    write_csv(rp, rows)
    write_csv(tr, trades)
    a = type('A', (), dict(reprice=str(rp), trades=str(tr), out=str(out),
                           allow_sealed=allow_sealed, through=through))()
    err = None
    try:
        rc = m.build(a)
    except Exception as exc:  # test reports, rather than hiding, crashes
        rc, err = None, exc
    got = list(csv.DictReader(out.open())) if out.exists() and out.stat().st_size else []
    rejp = out.with_name(out.stem + '_rejected' + out.suffix)
    rejected = list(csv.DictReader(rejp.open())) if rejp.exists() and rejp.stat().st_size else []
    summary = Path(str(out)+'.summary.txt').read_text() if Path(str(out)+'.summary.txt').exists() else ''
    return td, rc, got, rejected, summary, err


FAILS: list[str] = []
def check(name: str, cond: bool, detail='') -> None:
    print(f'{name:72s} {"PASS" if cond else "FAIL"}')
    if not cond:
        FAILS.append(name)
        if detail:
            print('   ', detail)


# 1: size zero must not silently become one.
td, rc, got, rejected, _, err = run([base_row(size='0')], [trade_row()])
check('zero size is rejected, not defaulted to one', not got and len(rejected)==1 and
      rejected[0]['base_rejection_reason']=='INVALID_SIZE_NONPOSITIVE', got or rejected or err)
td.cleanup()

# 2: missing size fails closed; the source reprice table is expected to carry it.
td, rc, got, rejected, _, err = run([base_row(size='')], [trade_row()])
check('missing size is rejected rather than silently assumed', not got and len(rejected)==1 and
      rejected[0]['base_rejection_reason']=='INVALID_SIZE_MISSING', got or rejected or err)
td.cleanup()

# 3: boundary/sentinel asks cannot fabricate PnL.
td, rc, got, _, _, err = run([base_row(primary_repriced_ask='0', primary_reprice_eligible='0')], [trade_row()])
check('ask=0 is retained as invalid evidence but produces no PnL', len(got)==1 and
      got[0]['reconstructed_ask_status']=='OUTSIDE_OPEN_INTERVAL' and
      got[0]['pnl_ask_scalable']=='' and got[0]['pnl_ask_exact']=='', got or err)
td.cleanup()

# 4: a valid-looking ask with insufficient evidence must not contribute ask PnL.
td, rc, got, _, _, err = run([base_row(primary_reprice_eligible='0')], [trade_row()])
check('ineligible reconstructed ask produces no displayed-price PnL', len(got)==1 and
      got[0]['reconstructed_ask_status']=='VALID_BUT_INELIGIBLE' and
      got[0]['pnl_ask_scalable']=='', got or err)
td.cleanup()

# 5: eligible price PnL and whole-order fee are correct at size 10.
td, rc, got, _, _, err = run([base_row(size='10', primary_repriced_ask='0.45')], [trade_row()])
want_fee = m.exact_order_fee(0.45, 10)
want_pnl = (1 - 0.45)*10 - want_fee
check('eligible ask uses one whole-order fee, not fee multiplied twice', len(got)==1 and
      abs(float(got[0]['pnl_ask_exact'])-want_pnl)<1e-12, got or err)
td.cleanup()

# 6-8: missingness reasons remain distinct.
td, rc, got, _, _, err = run([base_row(sib='HYPE', cb_confirm='', pm_confirm='')], [trade_row()])
check('HYPE blank Coinbase field is structural NO_COINBASE_MARKET', len(got)==1 and
      got[0]['cb_confirm_status']=='NO_COINBASE_MARKET', got or err)
check('non-stale blank PM field is MISSING, not no-confirm', len(got)==1 and
      got[0]['pm_confirm_status']=='MISSING', got or err)
td.cleanup()

td, rc, got, _, _, err = run([base_row(pm_confirm='', feed_stale='1')], [trade_row()])
check('stale blank PM field is separated as MISSING_FEED_STALE', len(got)==1 and
      got[0]['pm_confirm_status']=='MISSING_FEED_STALE', got or err)
td.cleanup()

# 9: out-of-range finite epochs cannot crash the run.
td, rc, got, rejected, _, err = run([base_row(t=1e20)], [trade_row()])
check('out-of-range timestamp is rejected and counted rather than crashing', err is None and
      not got and len(rejected)==1 and
      rejected[0]['base_rejection_reason']=='INVALID_DECISION_TIME_RANGE', repr(err))
td.cleanup()

# 10-12: STC missingness and duplicate semantics.
td, rc, got, _, _, err = run([base_row()], [trade_row(stc='')])
check('matching trade row with blank STC is explicit MISSING_STC', len(got)==1 and
      got[0]['stc_status']=='MISSING_STC' and got[0]['stc']=='', got or err)
td.cleanup()

td, rc, got, _, _, err = run([base_row()], [trade_row(), trade_row()])
check('identical duplicate STC rows collapse safely and visibly', len(got)==1 and
      got[0]['stc_status']=='OK_DUPLICATE_IDENTICAL' and got[0]['stc']=='300.0', got or err)
td.cleanup()

td, rc, got, _, _, err = run([base_row()], [trade_row(stc='300'), trade_row(stc='500')])
check('conflicting duplicate STC rows fail closed', len(got)==1 and
      got[0]['stc_status']=='CONFLICTING_TRADES_ROWS' and got[0]['stc']=='', got or err)
td.cleanup()

# 13: exact tolerance boundary and just-outside behavior.
t0=ts('2026-08-01T14:00:00+00:00')
td, rc, got, _, _, err = run([base_row(t=t0)], [trade_row(t=t0+0.001)])
check('STC join accepts exactly the declared 1 ms tolerance', len(got)==1 and
      got[0]['stc_status']=='OK', got or err)
td.cleanup()

td, rc, got, _, _, err = run([base_row(t=t0)], [trade_row(t=t0+0.0011)])
check('STC join refuses a row beyond the declared tolerance', len(got)==1 and
      got[0]['stc_status']=='TIME_MISMATCH' and got[0]['stc']=='', got or err)
td.cleanup()

# A mismatched row must not donate its session/hour metadata to the opportunity.
td, rc, got, _, _, err = run(
    [base_row(t=t0, decision_dow_utc='Saturday', decision_hour_utc='14')],
    [trade_row(t=t0+10, session='WRONG', dow='WRONG', hour='99')])
check('TIME_MISMATCH does not borrow context from an unrelated trades row', len(got)==1 and
      got[0]['session']=='' and got[0]['dow']=='Saturday' and got[0]['hour']=='14', got or err)
td.cleanup()

# 14-16: development / holdout guards.
td, rc, got, _, summary, err = run(
    [base_row(t='2026-09-09T14:00:00+00:00')],
    [trade_row(t='2026-09-09T14:00:00+00:00')])
check('sealed holdout is excluded by default', not got and 'sealed holdout' in summary, got or err)
td.cleanup()

td, rc, got, _, _, err = run(
    [base_row(t='2026-09-09T14:00:00+00:00')],
    [trade_row(t='2026-09-09T14:00:00+00:00')], allow_sealed=True)
check('--allow-sealed deliberately includes Sept 7-13', len(got)==1, got or err)
td.cleanup()

td, rc, got, _, summary, err = run(
    [base_row(t='2026-09-14T14:00:00+00:00')],
    [trade_row(t='2026-09-14T14:00:00+00:00')])
check('post-development rows do not silently contaminate the default table', not got and
      'after through' in summary, got or err)
td.cleanup()

# 17: context required by later grouping survives.
td, rc, got, _, _, err = run([base_row()], [trade_row()])
check('trigger/layer/book provenance fields are carried through', len(got)==1 and
      got[0]['trig_coins']=='ETH,SOL' and got[0]['side_collapsing']=='NO' and
      got[0]['arrival_book_source']=='kcp_ticker_l1' and got[0]['layer']=='shadow', got or err)
td.cleanup()

# 18: duplicate opportunity identities make the run non-successful rather than silently double-weighting.
r1=base_row(); r2=base_row()
td, rc, got, _, summary, err = run([r1,r2], [trade_row()])
check('duplicate opportunity IDs are visible and force nonzero return', rc==1 and
      'duplicate opportunity IDs  1' in summary, (rc, summary[-300:]))
td.cleanup()

# 19: malformed source schemas fail loudly rather than yielding a mostly blank table.
with tempfile.TemporaryDirectory() as td0:
    root=Path(td0); rp=root/'r.csv'; tr=root/'t.csv'; out=root/'o.csv'
    write_csv(rp, [dict(t_entry=repr(ts('2026-08-01T14:00:00+00:00')), ticker='X')])
    write_csv(tr, [trade_row()])
    a=type('A',(),dict(reprice=str(rp),trades=str(tr),out=str(out),allow_sealed=False,through=None))()
    try:
        m.build(a); raised=False
    except ValueError:
        raised=True
    check('missing required reprice columns fail loudly', raised)

with tempfile.TemporaryDirectory() as td0:
    root=Path(td0); rp=root/'r.csv'; tr=root/'t.csv'; out=root/'o.csv'
    write_csv(rp, [base_row()])
    write_csv(tr, [dict(t=repr(ts('2026-08-01T14:00:00+00:00')), ticker='X')])
    a=type('A',(),dict(reprice=str(rp),trades=str(tr),out=str(out),allow_sealed=False,through=None))()
    try:
        m.build(a); raised=False
    except ValueError:
        raised=True
    check('missing required trade columns fail loudly', raised)

# 20: side normalization and non-finite asks.
td, rc, got, _, _, err = run([base_row(opp='yes')], [trade_row(opp='YES')])
check('side matching is case-normalized for the STC join', len(got)==1 and got[0]['stc_status']=='OK', got or err)
td.cleanup()

td, rc, got, _, _, err = run([base_row(primary_repriced_ask='nan', primary_reprice_eligible='1')], [trade_row()])
check('NaN reconstructed ask cannot enter displayed-price PnL', len(got)==1 and
      got[0]['reconstructed_ask_status']=='MISSING' and got[0]['pnl_ask_scalable']=='', got or err)
td.cleanup()

# 21: fee formula matches the whole-order cent ceiling over a broad grid.
ok=True
for cents in range(1,100):
    p_=cents/100
    for q in (1,2,5,10,25,100):
        expected=__import__('math').ceil(0.07*q*p_*(1-p_)*100-1e-9)/100
        if m.exact_order_fee(p_,q)!=expected:
            ok=False
check('whole-order fee formula matches the cent ceiling on 594 cases', ok)

print('\n' + ('ALL PASS' if not FAILS else 'FAILURES: ' + ', '.join(FAILS)))
raise SystemExit(1 if FAILS else 0)
