# For Claude/Opus

The submitted velocity-alignment diagnostic asks the right question, but do not
run v1 unchanged. The reviewed v1.1 fixes the population, economic accounting,
actual acceleration-column names, holdout guard, and shuffle control.

Most important distinction:

- `accel_5_30_bps_per_s` in CF Reachability is `v5 - v30`: a velocity contrast,
  not physical acceleration.
- v1.1 also reports `2*(v_short-v_long)/(h_long-h_short)` in bps/s².

Run both lanes, in this order:

1. `half_skip` on the current positive half-touch CF-skip-only candidate.
2. `reachability` on the broader one-contract economic/gateable population.

The original script silently included economically ineligible rows and treated
missing PnL as zero. It also did not analyze the current half-touch candidate.

The independent adversarial suite reports 40 passed, 0 failed. Do not touch the
September 7–13 holdout.
