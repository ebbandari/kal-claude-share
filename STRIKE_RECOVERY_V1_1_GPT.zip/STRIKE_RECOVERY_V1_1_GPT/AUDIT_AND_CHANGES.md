# Strike recovery audit — v1.1 GPT

## Verdict

Do not run the submitted `recover_strikes_from_api.py` unchanged.
Its built-in self-test passes, but adversarial review found production defects.

## Material defects in the submitted version

1. **No historical endpoint fallback.** `GET /markets/{ticker}` stops returning
   markets older than Kalshi's moving historical cutoff. The reviewed version
   falls back to `GET /historical/markets/{ticker}` on a live-endpoint 404.

2. **Transient failures were cached forever.** A timeout, 429, 500, or network
   reset became a durable cache hit, so reruns never retried the ticker. The
   reviewed cache reuses successful immutable records only; failures remain in
   the audit log but are retried.

3. **API transport/status handling was ambiguous.** `curl -s` did not inspect
   HTTP status and had no bounded retry/backoff. The reviewed client handles
   408/425/429/5xx and transport failures with bounded retries.

4. **The validation gate could pass with one success and 299 unavailable
   markets.** The reviewed version requires at least 95% validation availability
   by default and refuses any strike or comparator mismatch.

5. **Missing comparator was accepted as agreement.** The reviewed version
   requires the API comparator to be present and exactly match lifecycle.

6. **Only `floor_strike` was supported.** The reviewed version uses
   `floor_strike` for greater comparators and `cap_strike` for less comparators.

7. **NaN/Infinity could be marked recovered.** Non-finite and non-positive
   effective strikes now fail closed.

8. **The holdout guard used the date encoded in the Eastern-time ticker.** A
   Sept 7 UTC opportunity can carry a Sept 6 ticker date. The reviewed version
   gates on each opportunity's UTC date and also enforces `--through 2026-09-06`.

9. **Coverage accounting mixed unrelated 15-minute series with the paper-bot
   universe.** The reviewed summary computes before/after coverage only from
   unique tickers and rows in the supplied opportunity coverage table.

10. **No merged opportunity output.** The reviewed version writes
    `opportunity_strike_coverage_recovered.csv`, preserving every development
    opportunity and explicitly identifying `LIFECYCLE_ASOF`, `API_RECOVERED`,
    or `MISSING`.

## Tests

- Embedded self-test: **ALL PASS**
- Independent adversarial suite: **29 passed, 0 failed**
- Python compilation: **PASS**

The independent suite covers live and historical endpoints, 429 and transport
retry, 403 fail-closed behavior, dual 404, cache restart semantics, floor/cap
comparators, non-finite values, ticker mismatch, UTC holdout protection,
conflicting lifecycle strikes, deterministic validation sampling, validation
availability/mismatch gates, row reconciliation, and an end-to-end synthetic
recovery.
