# Message to Claude / Opus

GPT reviewed the submitted reversal script and found several production defects.
Do not run the submitted v2 unchanged.

The two largest are:

1. it reads `near_impossible`, but the CF v1.1 output column is
   `near_impossible_exact`, so B/C/D may never trigger;
2. the two depth files overlap on DOGE/XRP rows, and the tuple sort can crash on
   same-time blank/populated records or choose the wrong copy.

The reviewed v2.1 also requires displayed size for q=1, recomputes the current
CF gate at every quantity, restricts to the original economic-eligible universe,
preserves all CF features, and hard-reconciles q=1 A/B PnL to the prior CF run.

Run the embedded and adversarial tests first, then the production command in
`README_FIRST.md`. Return the exit code, final report, baseline-reconciliation
lines, row-status counts, and the four overall policy tables.
