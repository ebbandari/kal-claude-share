#!/usr/bin/env python3
"""
cf_reachability_v1_1_gpt.py

For every paper-bot opportunity, estimate the causal empirical probability that
Kalshi's final-minute CF average satisfies the market comparator against the
strike, then compare that probability with the displayed executable price.

Key invariants
--------------
* Development ends 2026-09-06. Any later/holdout opportunity aborts the run.
* The reference distribution expands causally: only quarter-hour windows whose
  close is strictly before the decision may enter.
* One reference observation per coin/quarter-hour/horizon, never overlapping
  5 Hz rows treated as independent samples.
* Settlement reconstruction requires exactly 60 unique .000 observations in
  [close-60s, close); incomplete or duplicate-second grids fail closed.
* All opportunity rows survive with an explicit status.
* Cells with 100-299 observations are descriptive only and can never trigger a
  trading gate. A gate requires >=300 reference observations.
* Missing executable asks never fall back to the paper bot's logged price.
* The sealed 2026-09-07..2026-09-13 holdout is not read.

The output includes probability intervals, empirical move quantiles, projected
final-average quantiles and uncertainty bands, so a user can see not just the
chance of clearing K but by how much comparable markets cleared or missed it.
"""
from __future__ import annotations

import argparse
import bisect
import collections
import csv
import datetime as dt
import gzip
import hashlib
import json
import math
import os
import sys
import tempfile
import threading
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from statistics import NormalDist

BUCKET = "kalshi-data-vault-kalshi-collector-personal"
CF_PREFIX = "CF_RTI_V3_1"
REFERENCE_FROM_DEFAULT = dt.date(2026, 5, 27)
DEVELOPMENT_THROUGH_DEFAULT = dt.date(2026, 9, 6)
SEALED_FROM = dt.date(2026, 9, 7)
SEALED_TO = dt.date(2026, 9, 13)
HYPE_SWITCH_DATE = dt.date(2026, 6, 11)  # exact switch instant was not established

INDEX = {
    "BTC": ("KXBTC15M", "BRTI"),
    "ETH": ("KXETH15M", "ETHUSD_RTI"),
    "SOL": ("KXSOL15M", "SOLUSD_RTI"),
    "XRP": ("KXXRP15M", "XRPUSD_RTI"),
    "DOGE": ("KXDOGE15M", "DOGEUSD_RTI"),
    "HYPE": ("KXHYPE15M", "HYPEUSD_RTI"),
}
COINS = tuple(INDEX)
COMPARATORS = {"greater_or_equal", "greater", "less_or_equal", "less"}
SIDES = {"YES", "NO"}

# Paper-bot opportunity range.
HORIZONS = tuple(range(120, 871, 15))
VEL_HORIZONS = (5, 15, 30, 60, 120, 300)
MAX_CF_AGE_S = 5.0
N_GATE = 300
N_DESCRIBE = 100
ALPHA = 0.05
WHOLE_SECOND_TOL_S = 0.010
CF_AVAILABILITY_LAG_S_DEFAULT = 0.250  # conservative source->decision availability allowance


# ---------------------------------------------------------------------------
# Utility functions
# ---------------------------------------------------------------------------
def num(v):
    if v in (None, ""):
        return None
    try:
        x = float(v)
    except (TypeError, ValueError):
        return None
    return x if math.isfinite(x) else None


def parse_ts(v):
    if v in (None, ""):
        return None
    try:
        x = float(v)
        if x > 1e18:
            x /= 1e9
        elif x > 1e15:
            x /= 1e6
        elif x > 1e11:
            x /= 1e3
        return x if math.isfinite(x) else None
    except (TypeError, ValueError):
        pass
    try:
        d = dt.datetime.fromisoformat(str(v).strip().replace("Z", "+00:00"))
        if d.tzinfo is None:
            d = d.replace(tzinfo=dt.timezone.utc)
        return d.timestamp()
    except Exception:
        return None


def utc(ts):
    return dt.datetime.fromtimestamp(ts, dt.timezone.utc)


def is_sealed_date(d):
    return d is not None and SEALED_FROM <= d <= SEALED_TO


def session_of(ts):
    d = utc(ts)
    h = d.hour + d.minute / 60.0
    if h < 7:
        return "OvernightAsia"
    if h < 13.5:
        return "EuropeanAM"
    if h < 20:
        return "USsession"
    return "AfterHours"


def weekday_of(ts):
    return utc(ts).strftime("%a")


def iso_week_of(ts):
    d = utc(ts).isocalendar()
    return f"{d.year}-W{d.week:02d}"


def index_for(coin, ts):
    """Return the CF index valid for the timestamp, or None on HYPE switch day.

    The exact maintenance-window switch instant on 2026-06-11 was not frozen.
    Rather than silently pool two indices, v1.1 excludes HYPE reference windows
    on that single date. Paper-bot opportunities begin well after the switch.
    """
    if coin != "HYPE":
        return INDEX[coin][1]
    d = utc(ts).date()
    if d < HYPE_SWITCH_DATE:
        return "U_HYPEUSD_RTI"
    if d > HYPE_SWITCH_DATE:
        return "HYPEUSD_RTI"
    return None


def ceil_horizon(stc):
    """Conservative horizon: never give a trade less time than it really had."""
    h = int(math.ceil(float(stc) / 15.0) * 15)
    return min(max(h, HORIZONS[0]), HORIZONS[-1])


def exact_order_fee(price, contracts):
    if not (math.isfinite(price) and 0.0 < price < 1.0):
        raise ValueError("price must be in (0,1)")
    if not (math.isfinite(contracts) and contracts > 0):
        raise ValueError("contracts must be positive")
    return math.ceil(0.07 * contracts * price * (1.0 - price) * 100.0 - 1e-9) / 100.0


def scalable_order_fee(price, contracts):
    return 0.07 * contracts * price * (1.0 - price)


def wilson_interval(k, n, alpha=ALPHA):
    """Wilson score interval, used honestly (not labelled Jeffreys)."""
    if n <= 0:
        return 0.0, 1.0
    z = NormalDist().inv_cdf(1.0 - alpha / 2.0)
    p = k / n
    den = 1.0 + z * z / n
    ctr = (p + z * z / (2.0 * n)) / den
    rad = z * math.sqrt(p * (1.0 - p) / n + z * z / (4.0 * n * n)) / den
    return max(0.0, ctr - rad), min(1.0, ctr + rad)


def dkw_epsilon(n, alpha=ALPHA):
    if n <= 0:
        return 1.0
    return math.sqrt(math.log(2.0 / alpha) / (2.0 * n))


# ---------------------------------------------------------------------------
# Shared additive histogram grid
# ---------------------------------------------------------------------------
def build_edges():
    e = []
    for lo, hi, step in (
        (-2000, -500, 25),
        (-500, -100, 5),
        (-100, -25, 1),
        (-25, 25, 0.25),
        (25, 100, 1),
        (100, 500, 5),
        (500, 2000, 25),
    ):
        x = float(lo)
        while x < hi - 1e-12:
            e.append(round(x, 6))
            x += step
    e.append(2000.0)
    return tuple(sorted(set(e)))


EDGES = build_edges()
NBINS = len(EDGES) + 1


def bin_of(v):
    if v is None or not math.isfinite(v):
        return None
    return bisect.bisect_right(EDGES, v)


def bin_bounds(b):
    if b <= 0:
        return -math.inf, EDGES[0]
    if b >= len(EDGES):
        return EDGES[-1], math.inf
    return EDGES[b - 1], EDGES[b]


def representative_of_bin(b):
    lo, hi = bin_bounds(b)
    if math.isinf(lo):
        return EDGES[0]
    if math.isinf(hi):
        return EDGES[-1]
    return 0.5 * (lo + hi)


def hist_quantile(counts, p):
    """Approximate quantile from fixed counts, using bin midpoints."""
    n = sum(counts)
    if n <= 0:
        return None
    p = min(max(float(p), 0.0), 1.0)
    target = p * (n - 1)
    acc = 0
    for b, c in enumerate(counts):
        if c <= 0:
            continue
        if acc + c - 1 >= target:
            return representative_of_bin(b)
        acc += c
    return representative_of_bin(len(counts) - 1)


def hist_quantile_interval(counts, p, alpha=ALPHA):
    """Nonparametric DKW uncertainty band for a quantile."""
    n = sum(counts)
    if n <= 0:
        return None, None
    eps = dkw_epsilon(n, alpha)
    return hist_quantile(counts, max(0.0, p - eps)), hist_quantile(counts, min(1.0, p + eps))


def hist_cdf_bin_bounds(counts, q):
    """Bounds on F(q) caused by not knowing positions inside q's bin."""
    n = sum(counts)
    b = bin_of(q)
    if n <= 0 or b is None:
        return 0, 0, n
    strict_below = sum(counts[:b])
    through_bin = strict_below + counts[b]
    return strict_below, through_bin, n


# ---------------------------------------------------------------------------
# GCS cache
# ---------------------------------------------------------------------------
def _sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def validate_cf_file(path):
    """Fully read gzip/CSV so truncation after the header cannot pass."""
    n = 0
    first = last = None
    with gzip.open(path, "rt", newline="") as fh:
        rd = csv.DictReader(fh)
        fields = set(rd.fieldnames or [])
        if "timestamp_utc" not in fields or not ({"value_float64", "value"} & fields):
            raise ValueError(f"bad schema: {sorted(fields)}")
        for r in rd:
            t = parse_ts(r.get("timestamp_utc") or r.get("timestamp_ms"))
            v = num(r.get("value_float64") or r.get("value"))
            if t is None or v is None or v <= 0:
                continue
            n += 1
            if first is None:
                first = t
            last = t
    if n <= 0:
        raise ValueError("no valid CF rows")
    return {"rows": n, "first_ts": first, "last_ts": last}


class CFCache:
    """Read-only GCS cache using one reused google-cloud-storage client."""

    def __init__(self, root, workers=8, client=None):
        if client is None:
            from google.cloud import storage
            client = storage.Client()
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.client = client
        self.bucket = self.client.bucket(BUCKET)
        self.workers = max(1, int(workers))
        self.manifest_path = self.root / "manifest.jsonl"
        self.manifest = {}
        if self.manifest_path.exists():
            with self.manifest_path.open(encoding="utf-8") as fh:
                for line in fh:
                    try:
                        r = json.loads(line)
                        self.manifest[r["key"]] = r
                    except Exception:
                        continue
        self.lock = threading.Lock()
        self.mf = self.manifest_path.open("a", encoding="utf-8")

    def close(self):
        try:
            self.mf.close()
        except Exception:
            pass

    def local(self, coin, idx, day, hh):
        return self.root / coin / idx / day / f"{int(hh):02d}.csv.gz"

    def fetch(self, coin, idx, day, hh):
        key = f"{coin}/{idx}/{day}/{int(hh):02d}"
        dest = self.local(coin, idx, day, hh)
        rec = self.manifest.get(key)
        if rec and rec.get("ok") and dest.exists() and dest.stat().st_size == rec.get("size"):
            return "CACHED"

        blob = self.bucket.blob(f"{CF_PREFIX}/{coin}/{idx}/{day}/{int(hh):02d}/values.csv.gz")
        tmp = dest.with_name(dest.name + f".part.{os.getpid()}.{threading.get_ident()}")
        st = "ERROR:UNKNOWN"
        meta = {}
        try:
            if not blob.exists():
                dest.unlink(missing_ok=True)
                st = "ABSENT"
            else:
                dest.parent.mkdir(parents=True, exist_ok=True)
                tmp.unlink(missing_ok=True)
                blob.download_to_filename(str(tmp))
                meta = validate_cf_file(tmp)
                digest = _sha256(tmp)
                os.replace(tmp, dest)
                st = "FETCHED"
                meta["sha256"] = digest
                try:
                    blob.reload()
                except Exception:
                    pass
        except Exception as exc:
            tmp.unlink(missing_ok=True)
            if isinstance(exc, ValueError):
                dest.unlink(missing_ok=True)
                st = "BAD_SCHEMA"
            else:
                st = "ERROR:" + type(exc).__name__
        with self.lock:
            r = {
                "key": key,
                "ok": st in {"FETCHED", "CACHED"},
                "status": st,
                "size": dest.stat().st_size if dest.exists() else 0,
                "generation": getattr(blob, "generation", None),
                **meta,
            }
            self.manifest[key] = r
            self.mf.write(json.dumps(r, sort_keys=True) + "\n")
            self.mf.flush()
        return st

    def fetch_many(self, jobs, log):
        jobs = list(jobs)
        stats = collections.Counter()
        every = max(1, len(jobs) // 100)
        with ThreadPoolExecutor(max_workers=self.workers) as ex:
            for i, st in enumerate(ex.map(lambda j: self.fetch(*j), jobs), 1):
                stats[st.split(":")[0]] += 1
                if i % every == 0 or i == len(jobs):
                    log(f"  [{i}/{len(jobs)}] {100*i/max(len(jobs),1):5.1f}%  "
                        + "  ".join(f"{k}={v}" for k, v in stats.most_common()))
        return stats

    def series(self, coin, idx, day, hh):
        """Sorted, deduplicated (timestamp,value) rows for one hour.

        If the archive contains amendments for an identical timestamp, the row
        with the greatest amend timestamp wins; otherwise the last row wins.
        """
        p = self.local(coin, idx, day, hh)
        if not p.exists():
            return []
        by_ts = {}
        try:
            with gzip.open(p, "rt", newline="") as fh:
                for seq, r in enumerate(csv.DictReader(fh)):
                    t = parse_ts(r.get("timestamp_utc") or r.get("timestamp_ms"))
                    v = num(r.get("value_float64") or r.get("value"))
                    if t is None or v is None or v <= 0:
                        continue
                    amend = num(r.get("amend_time_ms") or r.get("amendTime") or r.get("amend_time"))
                    rank = (amend if amend is not None else -math.inf, seq)
                    prev = by_ts.get(t)
                    if prev is None or rank >= prev[0]:
                        by_ts[t] = (rank, v)
        except Exception as exc:
            raise RuntimeError(f"cached CF file unreadable: {p}: {type(exc).__name__}: {exc}") from exc
        return [(t, by_ts[t][1]) for t in sorted(by_ts)]


class CFView:
    def __init__(self, cache, availability_lag_s=CF_AVAILABILITY_LAG_S_DEFAULT):
        self.cache = cache
        self.loaded = {}
        self.availability_lag_s = max(0.0, float(availability_lag_s))

    def _hour(self, coin, idx, ts):
        d = utc(ts)
        key = (coin, idx, d.date().isoformat(), d.hour)
        if key not in self.loaded:
            if len(self.loaded) > 500:
                self.loaded.clear()
            rows = self.cache.series(coin, idx, key[2], key[3])
            self.loaded[key] = (rows, [x[0] for x in rows])
        return self.loaded[key]

    def asof(self, coin, idx, ts):
        # `ts` is a decision clock. REST history carries source timestamps, not
        # receive timestamps, so only source rows at least availability_lag_s old
        # are treated as causally knowable.
        query_ts = ts - self.availability_lag_s
        best = None
        for back in (0, 3600):
            rows, times = self._hour(coin, idx, query_ts - back)
            if not rows:
                continue
            i = bisect.bisect_right(times, query_ts) - 1
            if i >= 0:
                cand = rows[i]
                if best is None or cand[0] > best[0]:
                    best = cand
            if best is not None:
                break
        if best is None:
            return None, None, None
        return best[1], ts - best[0], best[0]

    def window(self, coin, idx, start, end, include_end=True):
        if end < start:
            return []
        h0 = int(math.floor(start / 3600.0) * 3600)
        h1 = int(math.floor(end / 3600.0) * 3600)
        out = []
        h = h0
        while h <= h1:
            rows, times = self._hour(coin, idx, h)
            if rows:
                i = bisect.bisect_left(times, start)
                j = (bisect.bisect_right(times, end) if include_end
                     else bisect.bisect_left(times, end))
                out.extend(rows[i:j])
            h += 3600
        out.sort()
        return out

    def final_minute_mean(self, coin, idx, close_ts):
        """Exactly 60 unique .000 observations in [T-60,T), or fail closed."""
        pts = self.window(coin, idx, close_ts - 60.0, close_ts, include_end=False)
        chosen = {}
        start_sec = int(round(close_ts)) - 60
        end_sec = int(round(close_ts))
        for t, v in pts:
            sec = int(math.floor(t))
            frac = t - sec
            if not (start_sec <= sec < end_sec):
                continue
            if frac < -1e-12 or frac > WHOLE_SECOND_TOL_S:
                continue  # .999 is not a .000 observation
            # If two near-boundary rows exist, use the one closest to .000.
            prev = chosen.get(sec)
            if prev is None or frac < prev[0]:
                chosen[sec] = (frac, v)
        if len(chosen) != 60 or any(s not in chosen for s in range(start_sec, end_sec)):
            return None, len(chosen), "INCOMPLETE_FINAL_MINUTE"
        vals = [chosen[s][1] for s in range(start_sec, end_sec)]
        return sum(vals) / 60.0, 60, "OK"

    @staticmethod
    def _feature_stats(pts):
        if len(pts) < 2:
            return {"n": len(pts), "max_gap_s": None, "rv_bps": None,
                    "first_ts": pts[0][0] if pts else None,
                    "last_ts": pts[-1][0] if pts else None}
        ts = [x[0] for x in pts]
        vals = [x[1] for x in pts]
        gaps = [b - a for a, b in zip(ts, ts[1:])]
        logs = [math.log(v) for v in vals if v > 0]
        rv = None
        if len(logs) >= 2:
            rv = 1e4 * math.sqrt(sum((b - a) ** 2 for a, b in zip(logs, logs[1:])))
        return {"n": len(pts), "max_gap_s": max(gaps) if gaps else None,
                "rv_bps": rv, "first_ts": ts[0], "last_ts": ts[-1]}

    def feature_windows(self, coin, idx, decision_ts, horizons):
        """Read the longest window once, then slice every shorter horizon."""
        horizons = tuple(sorted(set(int(h) for h in horizons)))
        end_ts = decision_ts - self.availability_lag_s
        pts = self.window(coin, idx, end_ts - max(horizons), end_ts,
                          include_end=True)
        times = [x[0] for x in pts]
        out = {}
        for h in horizons:
            i = bisect.bisect_left(times, end_ts - h)
            out[h] = self._feature_stats(pts[i:])
        return out

    def feature_window(self, coin, idx, decision_ts, horizon_s):
        return self.feature_windows(coin, idx, decision_ts, (horizon_s,))[int(horizon_s)]


# ---------------------------------------------------------------------------
# Reference distribution
# ---------------------------------------------------------------------------
class Reference:
    """Additive counts; week cells are stored once for later recombination."""

    def __init__(self):
        self.cells = collections.defaultdict(lambda: [0] * NBINS)
        self.week_cells = collections.defaultdict(collections.Counter)
        # Aggregate-key -> day -> sorted bin indices. Daily lists are tiny
        # (<=96 quarter-hours), so clustered tail queries are O(days*log 96)
        # rather than scanning every histogram bin for every opportunity.
        self.cluster_bins = collections.defaultdict(lambda: collections.defaultdict(list))

    def add(self, coin, horizon, session, weekday, week, day, bps):
        b = bin_of(bps)
        if b is None:
            return
        self.week_cells[(coin, horizon, session, weekday, week)][b] += 1
        for key in (
            (coin, horizon, session, weekday),
            (coin, horizon, session, None),
            (coin, horizon, None, None),
        ):
            self.cells[key][b] += 1
            bisect.insort(self.cluster_bins[key][day], b)

    def lookup(self, coin, horizon, session, weekday):
        levels = (
            ((coin, horizon, session, weekday), "coin_horizon_session_weekday"),
            ((coin, horizon, session, None), "coin_horizon_session"),
            ((coin, horizon, None, None), "coin_horizon"),
        )
        for key, level in levels:
            c = self.cells.get(key)
            n = sum(c) if c else 0
            if n >= N_GATE:
                return c, level, n, True
        for key, level in levels:
            c = self.cells.get(key)
            n = sum(c) if c else 0
            if n >= N_DESCRIBE:
                return c, level + "|DESCRIPTIVE", n, False
        c = self.cells.get((coin, horizon, None, None))
        return c, "INSUFFICIENT_REFERENCE", sum(c) if c else 0, False

    def cluster_tail_interval(self, coin, horizon, session, weekday, level,
                              q, upper, alpha=ALPHA):
        """Day-clustered interval for the selected backoff level.

        Uses a sandwich-style variance for the aggregate proportion. The final
        gate combines this with the Wilson bound, taking the more conservative
        upper/lower value, so an all-zero set of clusters cannot yield a false
        zero-width interval.
        """
        base_level = level.split("|", 1)[0]
        if base_level == "coin_horizon_session_weekday":
            key = (coin, horizon, session, weekday)
        elif base_level == "coin_horizon_session":
            key = (coin, horizon, session, None)
        else:
            key = (coin, horizon, None, None)
        by_day = self.cluster_bins.get(key, {})
        b = bin_of(q)
        clusters_min, clusters_max = [], []
        if b is not None:
            for bins in by_day.values():
                n = len(bins)
                if not n:
                    continue
                left = bisect.bisect_left(bins, b)
                right = bisect.bisect_right(bins, b)
                if upper:
                    kmin, kmax = n - right, n - left
                else:
                    kmin, kmax = left, right
                clusters_min.append((kmin, n))
                clusters_max.append((kmax, n))

        def interval(clusters):
            N = sum(n for _, n in clusters)
            G = len(clusters)
            if N <= 0:
                return 0.0, 1.0
            k = sum(x for x, _ in clusters)
            p = k / N
            if G < 2:
                return wilson_interval(k, N, alpha)
            scores = [x - p * n for x, n in clusters]
            var = (G / (G - 1.0)) * sum(x * x for x in scores) / (N * N)
            z = NormalDist().inv_cdf(1.0 - alpha / 2.0)
            rad = z * math.sqrt(max(var, 0.0))
            return max(0.0, p - rad), min(1.0, p + rad)

        lo_min, _ = interval(clusters_min)
        _, hi_max = interval(clusters_max)
        return lo_min, hi_max, len(by_day)

    def tail_bounds(self, counts, q, upper):
        """Guaranteed and possible successes given q-bin ambiguity."""
        b = bin_of(q)
        n = sum(counts) if counts else 0
        if b is None or n <= 0:
            return 0, 0, n
        if upper:
            guaranteed = sum(counts[b + 1:])
            possible = sum(counts[b:])
        else:
            guaranteed = sum(counts[:b])
            possible = sum(counts[:b + 1])
        return guaranteed, possible, n


def reference_closes(date_from, date_to):
    """Every UTC quarter-hour close in the reference period, for every coin."""
    start = dt.datetime.combine(date_from, dt.time.min, tzinfo=dt.timezone.utc)
    end = dt.datetime.combine(date_to + dt.timedelta(days=1), dt.time.min,
                              tzinfo=dt.timezone.utc)
    t = start
    out = []
    while t < end:
        if t.minute in (0, 15, 30, 45):
            d = t.date()
            if not is_sealed_date(d):
                for coin in COINS:
                    if coin == "HYPE" and d == HYPE_SWITCH_DATE:
                        continue
                    out.append({"coin": coin, "close": t.timestamp()})
        t += dt.timedelta(minutes=15)
    out.sort(key=lambda x: x["close"])
    return out


def hours_between(start_ts, end_ts):
    h = int(math.floor(start_ts / 3600.0) * 3600)
    end_h = int(math.floor(end_ts / 3600.0) * 3600)
    while h <= end_h:
        yield h
        h += 3600


def cache_jobs(markets, opps, log):
    need = set()
    for m in markets:
        idx = index_for(m["coin"], m["close"])
        if idx is None:
            continue
        for h in hours_between(m["close"] - 900.0, m["close"]):
            d = utc(h)
            need.add((m["coin"], idx, d.date().isoformat(), d.hour))
    for r in opps:
        t = r.get("_t")
        coin = r.get("coin") or r.get("sib")
        if t is None or coin not in INDEX:
            continue
        idx = index_for(coin, t)
        if idx is None:
            continue
        for h in hours_between(t - max(VEL_HORIZONS) - 10.0, t):
            d = utc(h)
            need.add((coin, idx, d.date().isoformat(), d.hour))
    # No holdout object can be requested.
    bad = [j for j in need if is_sealed_date(dt.date.fromisoformat(j[2]))]
    if bad:
        raise RuntimeError(f"sealed CF objects requested: {bad[:3]}")
    log(f"  CF hour objects required {len(need):,}")
    return sorted(need)


def load_expiration_truth(path, development_through, log):
    """Load post-settlement expiration values into a label-only namespace.

    The cache is optional and is never passed to opportunity feature building.
    Keys are (coin, rounded close timestamp). Conflicts fail closed.
    """
    p = Path(os.path.expanduser(path)) if path else None
    if p is None or not p.exists():
        log("  API expiration truth       unavailable (optional)")
        return {}
    raw = collections.defaultdict(set)
    with p.open(encoding="utf-8") as fh:
        for line in fh:
            try:
                r = json.loads(line)
            except Exception:
                continue
            if r.get("api_status") != "OK":
                continue
            ticker = r.get("ticker") or r.get("market_ticker_api") or ""
            series = ticker.split("-")[0]
            coin = next((c for c, (s, _) in INDEX.items() if s == series), None)
            close = parse_ts(r.get("close_time"))
            value = num(r.get("expiration_value"))
            if coin is None or close is None or value is None or value <= 0:
                continue
            if utc(close).date() > development_through or is_sealed_date(utc(close).date()):
                continue
            raw[(coin, int(round(close)))].add(value)
    conflicts = {k: v for k, v in raw.items() if len(v) > 1}
    if conflicts:
        raise RuntimeError(f"conflicting API expiration values: {list(conflicts.items())[:3]}")
    out = {k: next(iter(v)) for k, v in raw.items()}
    log(f"  API expiration truth       {len(out):,} market-closes")
    return out


def build_reference(markets, view, truth, log):
    events = []
    stats = collections.Counter()
    every = max(1, len(markets) // 100)
    for i, m in enumerate(markets, 1):
        coin, close = m["coin"], m["close"]
        idx = index_for(coin, close)
        if idx is None:
            stats["ambiguous_index_day"] += 1
            continue
        reconstructed, n, mean_status = view.final_minute_mean(coin, idx, close)
        api_value = truth.get((coin, int(round(close))))
        if api_value is not None:
            A = api_value
            stats["api_truth_used"] += 1
            if reconstructed is not None:
                stats["api_truth_with_reconstruction"] += 1
                stats.setdefault("reconstruction_abs_error_bps", []).append(
                    abs(1e4 * math.log(reconstructed / api_value)))
        else:
            A = reconstructed
            if A is not None:
                stats["strict_reconstruction_used"] += 1
        if A is None:
            stats[mean_status] += 1
            if i % every == 0:
                log(f"  [{i}/{len(markets)}] {100*i/len(markets):5.1f}%  "
                    f"usable={stats['usable']} incomplete={stats['INCOMPLETE_FINAL_MINUTE']}")
            continue
        obs = []
        for h in HORIZONS:
            decision_ts = close - h
            c, age, cts = view.asof(coin, idx, decision_ts)
            if c is None or c <= 0 or age is None or age > MAX_CF_AGE_S:
                continue
            # Store the decision timestamp once; derive session/weekday/week
            # when the event enters the causal frontier. This avoids millions
            # of repeated Python strings in the overnight run.
            obs.append((h, 1e4 * math.log(A / c), decision_ts))
        if obs:
            events.append((close, coin, obs))
            stats["usable"] += 1
        if i % every == 0 or i == len(markets):
            log(f"  [{i}/{len(markets)}] {100*i/len(markets):5.1f}%  "
                f"usable={stats['usable']} incomplete={stats['INCOMPLETE_FINAL_MINUTE']}")
    events.sort(key=lambda x: x[0])
    errors = stats.pop("reconstruction_abs_error_bps", [])
    if errors:
        errors = sorted(errors)
        stats["reconstruction_check_n"] = len(errors)
        stats["reconstruction_error_median_bps"] = errors[len(errors)//2]
        stats["reconstruction_error_p90_bps"] = errors[min(len(errors)-1, int(0.9*len(errors)))]
    log(f"  reference windows usable {len(events):,}")
    log(f"  reference observations   {sum(len(e[2]) for e in events):,}")
    if errors:
        log(f"  API-vs-reconstruction    n={len(errors):,}  median={stats['reconstruction_error_median_bps']:.6f} bps  p90={stats['reconstruction_error_p90_bps']:.6f} bps")
    return events, stats


# ---------------------------------------------------------------------------
# Inputs
# ---------------------------------------------------------------------------
def load_strike_map(path):
    by_ticker = collections.defaultdict(set)
    with open(os.path.expanduser(path), newline="", encoding="utf-8") as fh:
        for r in csv.DictReader(fh):
            tk = r.get("ticker") or r.get("market_ticker") or ""
            if not tk:
                continue
            k = num(r.get("strike_final"))
            cmpx = (r.get("comparator_final") or "").strip()
            src = (r.get("strike_source_final") or "MISSING").strip()
            by_ticker[tk].add((k, cmpx, src))
    out = {}
    for tk, vals in by_ticker.items():
        concrete = {(k, c, s) for k, c, s in vals if k is not None or c}
        if len({(k, c) for k, c, _ in concrete}) > 1:
            out[tk] = (None, "", "STRIKE_CONFLICT")
        elif concrete:
            out[tk] = sorted(concrete, key=lambda x: (x[0] is None, str(x)))[0]
        else:
            out[tk] = (None, "", "MISSING")
    return out


def load_opportunities(base, coverage, development_through, log):
    strikes = load_strike_map(coverage)
    rows = []
    source_n = 0
    holdout = []
    after = []
    with open(os.path.expanduser(base), newline="", encoding="utf-8") as fh:
        for row_id, r in enumerate(csv.DictReader(fh), 1):
            source_n += 1
            t = parse_ts(r.get("t_entry"))
            if t is not None:
                d = utc(t).date()
                if is_sealed_date(d):
                    holdout.append((row_id, r.get("ticker"), d.isoformat()))
                if d > development_through:
                    after.append((row_id, r.get("ticker"), d.isoformat()))
            k, cmpx, src = strikes.get(r.get("ticker", ""), (None, "", "MISSING"))
            rows.append(dict(r, _row_id=row_id, _t=t, _K=k, _cmp=cmpx, _src=src))
    if holdout or after:
        raise RuntimeError(
            f"development input contains forbidden rows: holdout={holdout[:3]} after_cutoff={after[:3]}")
    log(f"  opportunities loaded     {len(rows):,}")
    log(f"  rows in source           {source_n:,}")
    log(f"  with a strike            {sum(1 for r in rows if r['_K'] is not None):,}")
    return rows


# ---------------------------------------------------------------------------
# Opportunity evaluation
# ---------------------------------------------------------------------------
def _field_is_one(v):
    return str(v).strip().lower() in {"1", "1.0", "true", "yes"}


def evaluate(r, view, ref, stats):
    out = {k: v for k, v in r.items() if not k.startswith("_")}
    out["source_row_id"] = r.get("_row_id")
    out["strike_source_final"] = r.get("_src", "")
    out["status"] = "OK"
    out["economic_status"] = "NOT_EVALUATED"
    out["reference_gateable"] = 0

    if r.get("_t") is None:
        out["status"] = "INVALID_DECISION_TIME"
        stats[out["status"]] += 1
        return out
    if r.get("_src") == "STRIKE_CONFLICT":
        out["status"] = "STRIKE_CONFLICT"
        stats[out["status"]] += 1
        return out
    if r.get("_K") is None or not (r["_K"] > 0):
        out["status"] = "MISSING_STRIKE"
        stats[out["status"]] += 1
        return out
    if r.get("_cmp") not in COMPARATORS:
        out["status"] = "UNKNOWN_COMPARATOR"
        stats[out["status"]] += 1
        return out

    coin = (r.get("coin") or r.get("sib") or "").upper()
    side = (r.get("side") or r.get("opp") or "").upper()
    if coin not in INDEX:
        out["status"] = "UNKNOWN_COIN"
        stats[out["status"]] += 1
        return out
    if side not in SIDES:
        out["status"] = "UNKNOWN_SIDE"
        stats[out["status"]] += 1
        return out

    stc = num(r.get("stc"))
    if stc is None or stc <= 0:
        out["status"] = "MISSING_STC"
        stats[out["status"]] += 1
        return out
    if stc < HORIZONS[0] or stc > HORIZONS[-1]:
        out["status"] = "OUTSIDE_V1_STC_RANGE"
        stats[out["status"]] += 1
        return out

    idx = index_for(coin, r["_t"])
    if idx is None:
        out["status"] = "AMBIGUOUS_CF_INDEX"
        stats[out["status"]] += 1
        return out
    c, age, cts = view.asof(coin, idx, r["_t"])
    if c is None or c <= 0 or age is None:
        out["status"] = "MISSING_CF"
        stats[out["status"]] += 1
        return out
    if age > MAX_CF_AGE_S:
        out["status"] = "STALE_CF"
        out["cf_age_s"] = round(age, 6)
        stats[out["status"]] += 1
        return out

    K = r["_K"]
    q = 1e4 * math.log(K / c)
    out.update({
        "cf_index": idx,
        "cf_at_decision": repr(c),
        "cf_timestamp": repr(cts),
        "cf_age_s": round(age, 6),
        "strike_final": repr(K),
        "comparator_final": r["_cmp"],
        "distance_native_K_minus_CF": repr(K - c),
        "required_final_average_move_bps": repr(q),
        "seconds_until_final_minute": repr(max(stc - 60.0, 0.0)),
    })

    # Comparator + purchased side determine which tail is favorable.
    upper = r["_cmp"].startswith("greater")
    if side == "NO":
        upper = not upper
    side_sign = 1.0 if upper else -1.0
    out["needs_upper_tail"] = int(upper)
    out["required_side_favorable_move_bps"] = repr(side_sign * q)

    rv60 = None
    feature_windows = view.feature_windows(coin, idx, r["_t"], VEL_HORIZONS)
    for h in VEL_HORIZONS:
        p, pa, pts = view.asof(coin, idx, r["_t"] - h)
        if p is not None and p > 0 and pa is not None and pa <= MAX_CF_AGE_S:
            elapsed = cts - pts
            if elapsed > 0:
                rh = 1e4 * math.log(c / p)
                out[f"ret_{h}s_bps"] = repr(rh)
                out[f"vel_{h}s_bps_per_s"] = repr(rh / elapsed)
                out[f"ret_{h}s_actual_elapsed_s"] = repr(elapsed)
        fw = feature_windows[h]
        out[f"cf_n_{h}s"] = fw["n"]
        out[f"cf_max_gap_{h}s"] = "" if fw["max_gap_s"] is None else repr(fw["max_gap_s"])
        out[f"rv_{h}s_bps"] = "" if fw["rv_bps"] is None else repr(fw["rv_bps"])
        if h == 60:
            rv60 = fw["rv_bps"]
    for a, b in ((5, 30), (15, 60), (30, 120)):
        va, vb = num(out.get(f"vel_{a}s_bps_per_s")), num(out.get(f"vel_{b}s_bps_per_s"))
        out[f"accel_{a}_{b}_bps_per_s"] = "" if va is None or vb is None else repr(va - vb)
    if rv60 is not None and rv60 > 0:
        scale = rv60 * math.sqrt(stc / 60.0)
        out["distance_vol_normalized"] = repr((side_sign * q) / scale if scale > 0 else math.nan)
    else:
        out["distance_vol_normalized"] = ""

    # Scale-normalized legacy Coinbase diagnostic, explicitly named as proxy.
    cb = num(r.get("cb_confirm_raw_usd"))
    if coin == "HYPE":
        out["cb_confirm_bps_vs_strike"] = ""
        out["cb_confirm_normalization_status"] = "NO_COINBASE_MARKET"
    elif cb is None:
        out["cb_confirm_bps_vs_strike"] = ""
        out["cb_confirm_normalization_status"] = "MISSING_CB_CONFIRM"
    else:
        out["cb_confirm_bps_vs_strike"] = repr(1e4 * cb / K)
        out["cb_confirm_normalization_status"] = "OK_STRIKE_PROXY"

    h = ceil_horizon(stc)
    out["reference_horizon_s"] = h
    out["reference_horizon_minus_stc_s"] = repr(h - stc)
    counts, level, n, gateable = ref.lookup(
        coin, h, session_of(r["_t"]), weekday_of(r["_t"]))
    out["reference_cell"] = level
    out["reference_n"] = n
    out["reference_gateable"] = int(gateable)
    if counts is not None:
        out["reference_underflow_n"] = counts[0]
        out["reference_overflow_n"] = counts[-1]
    out["quantile_uncertainty_method"] = "DKW_NOMINAL_IID_PLUS_DAY_CLUSTERED_PROBABILITY_GATE"
    if counts is None or n < N_DESCRIBE:
        out["status"] = "INSUFFICIENT_REFERENCE"
        stats[out["status"]] += 1
        return out
    if not gateable:
        out["status"] = "DESCRIPTIVE_REFERENCE"

    k_min, k_max, n = ref.tail_bounds(counts, q, upper)
    p_min, p_max = k_min / n, k_max / n
    p_mid = 0.5 * (p_min + p_max)
    lo_wilson, _ = wilson_interval(k_min, n)
    _, hi_wilson = wilson_interval(k_max, n)
    lo_cluster, hi_cluster, reference_days = ref.cluster_tail_interval(
        coin, h, session_of(r["_t"]), weekday_of(r["_t"]), level, q, upper)
    # Gate with the wider, more conservative interval.
    lo_min = min(lo_wilson, lo_cluster)
    hi_max = max(hi_wilson, hi_cluster)
    out.update({
        "p_win_hat": repr(p_mid),
        "p_win_bin_lower": repr(p_min),
        "p_win_bin_upper": repr(p_max),
        "p_win_ci_lo_conservative": repr(lo_min),
        "p_win_ci_hi_conservative": repr(hi_max),
        "p_win_wilson_lo": repr(lo_wilson),
        "p_win_wilson_hi": repr(hi_wilson),
        "p_win_day_cluster_lo": repr(lo_cluster),
        "p_win_day_cluster_hi": repr(hi_cluster),
        "reference_days": reference_days,
        "p_opposite_hat": repr(1.0 - p_mid),
        "p_opposite_ci_lo_conservative": repr(1.0 - hi_max),
        "p_opposite_ci_hi_conservative": repr(1.0 - lo_min),
    })

    # Required-move percentile and DKW uncertainty.
    cdf_lo_n, cdf_hi_n, _ = hist_cdf_bin_bounds(counts, q)
    eps = dkw_epsilon(n)
    out["required_move_cdf_bin_lo"] = repr(cdf_lo_n / n)
    out["required_move_cdf_bin_hi"] = repr(cdf_hi_n / n)
    out["required_move_cdf_dkw_lo"] = repr(max(0.0, cdf_lo_n / n - eps))
    out["required_move_cdf_dkw_hi"] = repr(min(1.0, cdf_hi_n / n + eps))
    out["reference_dkw_epsilon"] = repr(eps)

    # Raw move quantiles + projected final-average quantiles.
    for pct in (5, 10, 25, 50, 75, 90, 95):
        pctl = pct / 100.0
        mv = hist_quantile(counts, pctl)
        qlo, qhi = hist_quantile_interval(counts, pctl)
        tag = f"p{pct:02d}"
        if mv is not None:
            out[f"reference_move_{tag}_bps"] = repr(mv)
            out[f"pred_final_avg_{tag}"] = repr(c * math.exp(mv / 1e4))
        if qlo is not None:
            out[f"reference_move_{tag}_dkw_lo_bps"] = repr(qlo)
            out[f"pred_final_avg_{tag}_dkw_lo"] = repr(c * math.exp(qlo / 1e4))
        if qhi is not None:
            out[f"reference_move_{tag}_dkw_hi_bps"] = repr(qhi)
            out[f"pred_final_avg_{tag}_dkw_hi"] = repr(c * math.exp(qhi / 1e4))

    # Side-oriented clearances: q90 means 90th-percentile favorable outcome.
    side_probs = (0.50, 0.90, 0.95)
    for favorable_p in side_probs:
        raw_p = favorable_p if upper else 1.0 - favorable_p
        mv = hist_quantile(counts, raw_p)
        qlo, qhi = hist_quantile_interval(counts, raw_p)
        tag = f"q{int(favorable_p*100):02d}"
        if mv is not None:
            projected = c * math.exp(mv / 1e4)
            out[f"side_favorable_move_{tag}_bps"] = repr(side_sign * mv)
            out[f"side_clearance_vs_K_{tag}_bps"] = repr(side_sign * (mv - q))
            out[f"side_projected_final_avg_{tag}"] = repr(projected)
            out[f"side_projected_clearance_native_{tag}"] = repr(side_sign * (projected - K))
        # Keep the two raw DKW bounds; ordering reverses for lower-tail orientation.
        if qlo is not None and qhi is not None:
            vals = sorted((side_sign * qlo, side_sign * qhi))
            out[f"side_favorable_move_{tag}_dkw_lo_bps"] = repr(vals[0])
            out[f"side_favorable_move_{tag}_dkw_hi_bps"] = repr(vals[1])

    # Economic gate: displayed executable ask only; never fall back to logged price.
    ask = num(r.get("reconstructed_ask"))
    size = num(r.get("size"))
    eligible = _field_is_one(r.get("reprice_eligible"))
    if not eligible:
        out["economic_status"] = "REPRICE_INELIGIBLE"
    elif ask is None or not (0.0 < ask < 1.0):
        out["economic_status"] = "MISSING_EXECUTABLE_PRICE"
    elif size is None or size <= 0:
        out["economic_status"] = "INVALID_SIZE"
    else:
        be_exact = ask + exact_order_fee(ask, size) / size
        be_scalable = ask + scalable_order_fee(ask, size) / size
        out["economic_status"] = "OK" if gateable else "DESCRIPTIVE_ONLY"
        out["break_even_p_exact"] = repr(be_exact)
        out["break_even_p_scalable"] = repr(be_scalable)
        out["edge_p_hat_exact"] = repr(p_mid - be_exact)
        out["edge_p_hat_scalable"] = repr(p_mid - be_scalable)
        if gateable:
            out["near_impossible_exact"] = int(hi_max < be_exact)
            out["near_impossible_scalable"] = int(hi_max < be_scalable)
            out["positive_edge_exact_conservative"] = int(lo_min > be_exact)
            out["positive_edge_scalable_conservative"] = int(lo_min > be_scalable)
        else:
            out["near_impossible_exact"] = ""
            out["near_impossible_scalable"] = ""
            out["positive_edge_exact_conservative"] = ""
            out["positive_edge_scalable_conservative"] = ""

    stats[out["status"]] += 1
    return out


# ---------------------------------------------------------------------------
# Output
# ---------------------------------------------------------------------------
def write_rows(path, rows):
    keys = []
    seen = set()
    for r in rows:
        for k in r:
            if k not in seen:
                seen.add(k)
                keys.append(k)
    with gzip.open(path, "wt", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=keys, extrasaction="ignore")
        w.writeheader()
        w.writerows(rows)


def write_reference_counts(path, ref):
    fields = ["coin", "horizon_s", "session", "weekday", "iso_week",
              "bin_index", "bin_lo_bps", "bin_hi_bps", "count"]
    with gzip.open(path, "wt", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=fields)
        w.writeheader()
        for key in sorted(ref.week_cells):
            coin, h, sess, wd, week = key
            for b, count in sorted(ref.week_cells[key].items()):
                lo, hi = bin_bounds(b)
                w.writerow({"coin": coin, "horizon_s": h, "session": sess,
                            "weekday": wd, "iso_week": week, "bin_index": b,
                            "bin_lo_bps": lo, "bin_hi_bps": hi, "count": count})


def summarise(rows, stats, n_in, log, out, config):
    log()
    log(f"  rows in {n_in:,}   rows out {len(rows):,}   "
        f"{'RECONCILES' if n_in == len(rows) else 'MISMATCH'}")
    for k, v in stats.most_common():
        log(f"    {k:30s} {v:7,}  {100*v/max(len(rows),1):5.1f}%")

    gateable = [r for r in rows if _field_is_one(r.get("reference_gateable"))]
    econ = [r for r in gateable if r.get("economic_status") == "OK"]
    near = [r for r in econ if _field_is_one(r.get("near_impossible_exact"))]
    log()
    log(f"  gateable reference rows       {len(gateable):,}")
    log(f"  economic-eligible rows        {len(econ):,}")
    log(f"  near-impossible exact-fee     {len(near):,}")

    pnl_report = {}
    for label, col in (
        ("ask_scalable", "pnl_ask_scalable"),
        ("ask_exact", "pnl_ask_exact"),
        ("logged_scalable", "pnl_logged_scalable"),
        ("logged_exact", "pnl_logged_exact"),
    ):
        rem_vals = [num(r.get(col)) for r in near]
        keep_vals = [num(r.get(col)) for r in econ if not _field_is_one(r.get("near_impossible_exact"))]
        rem = sum(v for v in rem_vals if v is not None)
        keep = sum(v for v in keep_vals if v is not None)
        pnl_report[label] = {
            "removed_pnl": rem,
            "kept_pnl": keep,
            "removed_n_with_pnl": sum(v is not None for v in rem_vals),
            "kept_n_with_pnl": sum(v is not None for v in keep_vals),
        }
        log(f"    {label:18s} removed {rem:+10.3f}  kept {keep:+10.3f}  all {rem+keep:+10.3f}")

    by_coin = {}
    for coin in COINS:
        rr = [r for r in econ if (r.get("coin") or r.get("sib")) == coin]
        by_coin[coin] = {
            "n": len(rr),
            "near_impossible": sum(_field_is_one(r.get("near_impossible_exact")) for r in rr),
            "pnl_ask_exact": sum(num(r.get("pnl_ask_exact")) or 0.0 for r in rr),
        }
    log("  coin        n   near-imp   PnL ask exact")
    for c, x in by_coin.items():
        log(f"  {c:6s} {x['n']:7d} {x['near_impossible']:10d} {x['pnl_ask_exact']:+14.3f}")

    summary = {
        "rows_in": n_in,
        "rows_out": len(rows),
        "status": dict(stats),
        "gateable_rows": len(gateable),
        "economic_eligible_rows": len(econ),
        "near_impossible_exact_rows": len(near),
        "pnl": pnl_report,
        "by_coin": by_coin,
        "config": config,
    }
    (out / "cf_reachability_summary.json").write_text(
        json.dumps(summary, indent=2, sort_keys=True), encoding="utf-8")


# ---------------------------------------------------------------------------
# Run
# ---------------------------------------------------------------------------
def run(a, log, cache_client=None):
    out = Path(os.path.expanduser(a.out))
    out.mkdir(parents=True, exist_ok=True)
    reference_from = dt.date.fromisoformat(a.reference_from)
    development_through = dt.date.fromisoformat(a.development_through)
    if development_through >= SEALED_FROM:
        raise RuntimeError("development-through must precede the sealed holdout")

    log("=" * 72)
    log("CF REACHABILITY v1.1 GPT REVIEWED")
    log("=" * 72)
    log("  target: final-minute CF average against market-specific K/comparator")
    log("  reference: expanding causal quarter-hour windows, one sample per horizon")
    log(f"  reference prehistory: {reference_from} through {development_through}")
    log(f"  sealed holdout: {SEALED_FROM}..{SEALED_TO} refused")
    log()

    opps = load_opportunities(a.base, a.coverage, development_through, log)
    markets = reference_closes(reference_from, development_through)
    log(f"  reference close windows   {len(markets):,}")

    cache = CFCache(out / "cf_cache", workers=a.workers, client=cache_client)
    try:
        jobs = cache_jobs(markets, opps, log)
        log("\n[1/4] CF cache")
        fetch_stats = collections.Counter()
        if not a.no_fetch:
            fetch_stats = cache.fetch_many(jobs, log)
            if fetch_stats.get("ERROR", 0) or fetch_stats.get("BAD_SCHEMA", 0):
                raise RuntimeError(f"CF cache failures: {dict(fetch_stats)}")
        if a.stage == "cache":
            log(f"  cache-only complete: {dict(fetch_stats)}")
            return 0

        view = CFView(cache, availability_lag_s=a.cf_availability_lag_ms / 1000.0)
        truth = load_expiration_truth(a.api_cache, development_through, log)
        log("\n[2/4] reference observations")
        events, reference_stats = build_reference(markets, view, truth, log)

        log("\n[3/4] causal sweep")
        valid = sorted((r for r in opps if r.get("_t") is not None), key=lambda x: x["_t"])
        invalid = [r for r in opps if r.get("_t") is None]
        ref = Reference()
        rows = []
        stats = collections.Counter()
        ei = 0
        every = max(1, len(valid) // 100)
        for i, r in enumerate(valid, 1):
            t = r["_t"]
            while ei < len(events) and events[ei][0] < t:
                close, coin, obs = events[ei]
                for h, bps, decision_ts in obs:
                    ref.add(coin, h, session_of(decision_ts), weekday_of(decision_ts),
                            iso_week_of(decision_ts), utc(decision_ts).date().isoformat(), bps)
                ei += 1
            rows.append(evaluate(r, view, ref, stats))
            if i % every == 0 or i == len(valid):
                log(f"  [{i}/{len(valid)}] {100*i/max(len(valid),1):5.1f}%  "
                    f"gateable={sum(_field_is_one(x.get('reference_gateable')) for x in rows):,}  "
                    + "  ".join(f"{k}={v}" for k, v in stats.most_common(3)))
        for r in invalid:
            rows.append(evaluate(r, view, ref, stats))
        rows.sort(key=lambda r: int(r.get("source_row_id") or 0))

        log("\n[4/4] outputs")
        write_rows(out / "paper_bot_cf_reachability_rows.csv.gz", rows)
        write_reference_counts(out / "cf_reference_counts.csv.gz", ref)
        config = {
            "reference_from": str(reference_from),
            "development_through": str(development_through),
            "n_gate": N_GATE,
            "n_describe": N_DESCRIBE,
            "max_cf_age_s": MAX_CF_AGE_S,
            "cf_availability_lag_ms": a.cf_availability_lag_ms,
            "horizons": list(HORIZONS),
            "velocity_horizons": list(VEL_HORIZONS),
            "final_minute_rule": "exactly 60 unique .000 rows in [T-60,T)",
            "reference_stats": dict(reference_stats),
            "fetch_stats": dict(fetch_stats),
        }
        summarise(rows, stats, len(opps), log, out, config)
        return 0 if len(rows) == len(opps) else 1
    finally:
        cache.close()


# ---------------------------------------------------------------------------
# Embedded tests
# ---------------------------------------------------------------------------
def self_test():
    failures = []

    def ck(name, cond):
        print(f"  {name:70s} {'PASS' if cond else 'FAIL'}")
        if not cond:
            failures.append(name)

    ck("bin grid sorted and unique", list(EDGES) == sorted(set(EDGES)))
    ck("grid spans +-2000 bps", EDGES[0] == -2000 and EDGES[-1] == 2000)
    ck("quarter-bp resolution near zero", 0.25 in EDGES and -0.25 in EDGES)
    ck("bin mapping monotone", bin_of(-5) < bin_of(0) < bin_of(5))
    ck("HYPE old index", index_for("HYPE", dt.datetime(2026, 6, 10, tzinfo=dt.timezone.utc).timestamp()) == "U_HYPEUSD_RTI")
    ck("HYPE switch day refused", index_for("HYPE", dt.datetime(2026, 6, 11, tzinfo=dt.timezone.utc).timestamp()) is None)
    ck("HYPE new index", index_for("HYPE", dt.datetime(2026, 6, 12, tzinfo=dt.timezone.utc).timestamp()) == "HYPEUSD_RTI")
    ck("ceil horizon never understates time", ceil_horizon(121) == 135 and ceil_horizon(870) == 870)

    r = Reference()
    for _ in range(150):
        r.add("BTC", 300, "USsession", "Mon", "2026-W31", "2026-07-27", 10.0)
    _, lvl, n, gate = r.lookup("BTC", 300, "USsession", "Mon")
    ck("100-299 reference is descriptive only", n == 150 and "DESCRIPTIVE" in lvl and not gate)
    for _ in range(150):
        r.add("BTC", 300, "USsession", "Mon", "2026-W32", "2026-08-03", 10.0)
    _, lvl, n, gate = r.lookup("BTC", 300, "USsession", "Mon")
    ck("300 reference is gateable", n == 300 and gate)
    ck("week counts retain separate weeks", sum(r.week_cells[("BTC", 300, "USsession", "Mon", "2026-W31")].values()) == 150)

    lo, hi = wilson_interval(0, 500)
    ck("Wilson at zero has nonzero upper", lo <= 1e-12 and hi > 0)
    ck("DKW shrinks with n", dkw_epsilon(1000) < dkw_epsilon(100))
    ck("whole-order fee ceilings once", abs(exact_order_fee(0.5, 10) - 0.18) < 1e-12)
    ck("sealed date recognized", is_sealed_date(dt.date(2026, 9, 9)))
    ck("session boundary 13:30", session_of(dt.datetime(2026, 8, 3, 13, 29, tzinfo=dt.timezone.utc).timestamp()) == "EuropeanAM" and session_of(dt.datetime(2026, 8, 3, 13, 30, tzinfo=dt.timezone.utc).timestamp()) == "USsession")
    ck("default CF availability lag is positive", CF_AVAILABILITY_LAG_S_DEFAULT > 0)

    import ast
    tree = ast.parse(Path(__file__).read_text())
    imports = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            imports.update(x.name.split(".")[0] for x in node.names)
        elif isinstance(node, ast.ImportFrom) and node.module:
            imports.add(node.module.split(".")[0])
    ck("subprocess never imported", "subprocess" not in imports)

    print("\n" + ("ALL PASS" if not failures else "FAILURES: " + ", ".join(failures)))
    return 0 if not failures else 1


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--base", default="~/paper_bot_opportunity_base.csv")
    ap.add_argument("--coverage", default="~/strike_recovery_v1_1/opportunity_strike_coverage_recovered.csv")
    ap.add_argument("--out", default="~/cf_reach_v1_1")
    ap.add_argument("--api-cache", default="~/strike_recovery_v1_1/api_market_cache.jsonl",
                    help="optional post-settlement expiration truth; labels/validation only")
    ap.add_argument("--reference-from", default=str(REFERENCE_FROM_DEFAULT))
    ap.add_argument("--development-through", default=str(DEVELOPMENT_THROUGH_DEFAULT))
    ap.add_argument("--workers", type=int, default=8)
    ap.add_argument("--cf-availability-lag-ms", type=float, default=250.0,
                    help="source timestamp must precede decision by this lag (default 250ms)")
    ap.add_argument("--no-fetch", action="store_true")
    ap.add_argument("--stage", choices=("all", "cache"), default="all")
    ap.add_argument("--self-test", action="store_true")
    a = ap.parse_args()
    if a.self_test:
        return self_test()
    lines = []

    def log(s=""):
        print(s, flush=True)
        lines.append(s)

    try:
        return run(a, log)
    finally:
        p = Path(os.path.expanduser(a.out))
        p.mkdir(parents=True, exist_ok=True)
        (p / "CF_REACHABILITY_REPORT.md").write_text("\n".join(lines) + "\n", encoding="utf-8")


if __name__ == "__main__":
    raise SystemExit(main())
