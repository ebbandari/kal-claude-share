# Run order on Probe2

These are a sequence.

```bash
python3 ~/cf_velocity_alignment_v1_1_gpt.py --self-test
python3 ~/test_cf_velocity_alignment_v1_1_adversarial.py
```

Primary: current half-touch CF-skip-only candidate.

```bash
python3 ~/cf_velocity_alignment_v1_1_gpt.py \
  --rows ~/cf_reversal_v2_1_20260916T031510Z/reversal_rows.csv.gz \
  --lane half_skip \
  --out ~/cf_velocity_alignment_half_skip_v1_1 \
  --shuffles 500
```

Secondary: broad one-contract reachability population.

```bash
python3 ~/cf_velocity_alignment_v1_1_gpt.py \
  --rows ~/cf_reach_v1_1/paper_bot_cf_reachability_rows.csv.gz \
  --lane reachability \
  --out ~/cf_velocity_alignment_reachability_v1_1 \
  --shuffles 500
```

Do not pass `--allow-sealed`.

Each run writes:

```text
REPORT.md
headline.csv
group_cells.csv
permutation_control.csv
velocity_alignment_rows.csv.gz
RUN_SUMMARY.json
```
