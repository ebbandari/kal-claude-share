Use GPT's reviewed v1.1, not the submitted strike recovery script.

Run first:

```bash
python3 ~/recover_strikes_from_api_v1_1_gpt.py --self-test
python3 ~/test_recover_strikes_from_api_v1_1_adversarial.py
```

Then a bounded 20-ticker live probe:

```bash
python3 ~/recover_strikes_from_api_v1_1_gpt.py \
  --coverage ~/strike_table/opportunity_strike_coverage.csv \
  --out ~/strike_recovery_v1_1_probe \
  --limit 20
```

Inspect `SUMMARY.txt`, `validation_sample.csv`, and
`recovered_strikes.csv`. If clean, run the full recovery without `--limit`:

```bash
python3 ~/recover_strikes_from_api_v1_1_gpt.py \
  --coverage ~/strike_table/opportunity_strike_coverage.csv \
  --out ~/strike_recovery_v1_1
```

The default development cutoff is 2026-09-06. Do not add a sealed-window
override. Failed API calls are not reusable cache hits, so a rerun retries only
unresolved tickers while retaining successful immutable records.
