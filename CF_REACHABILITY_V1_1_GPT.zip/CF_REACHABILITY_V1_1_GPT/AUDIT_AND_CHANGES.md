# CF reachability v1 — independent audit and v1.1 replacement

## Ruling

Do not run the submitted `cf_reachability_v1.py` unchanged. Its high-level target is correct, but the production implementation had answer-changing defects.

## Reproduced defects in the submitted version

1. **Incomplete settlement windows were accepted.** `final_minute_mean()` accepted as few as 55 observations and also admitted timestamps near `.999` as though they were the `.000` settlement series.
2. **The promised seven-week prehistory was not used.** Reference markets came only from the July 15–September 6 strike table, so early opportunities lacked the clean May 27–July 14 history described in the design.
3. **Session/weekday conditioning used the wrong clock.** One session and weekday were assigned to all 51 horizons, rather than using each horizon's own historical decision time.
4. **Descriptive cells could trade.** Cells with 100–299 observations were labelled descriptive but still produced `near_impossible=1` and could remove trades. The declared gate floor was 300.
5. **Missing executable prices silently fell back to logged prices.** This could make a non-executable opportunity look economically tradeable.
6. **Unknown sides failed open as YES; zero size became one contract.**
7. **The sealed holdout was not refused at opportunity-row load time.**
8. **`--stage cache` was parsed but ignored.**
9. **No realized-volatility or volatility-normalized-distance features were emitted despite the specification.**
10. **Recovered API expiration values were not used for labels/validation.**
11. **REST source timestamps were treated as instantly available.** A configurable 250 ms source-to-decision availability allowance is now applied.
12. **Naive probability intervals ignored day clustering.** The gate now combines Wilson and day-clustered bounds conservatively.
13. **No quantile/clearance output existed.** The user could not see how far the projected final average cleared or missed K, or how uncertain that estimate was.

## v1.1 behavior

- Uses a causal quarter-hour reference grid from **2026-05-27** through **2026-09-06**, giving the first opportunity the intended seven-week prehistory.
- Keeps the sealed **2026-09-07 through 2026-09-13** holdout inaccessible; any forbidden opportunity aborts the development run.
- Uses one observation per coin / quarter-hour / horizon.
- Requires exactly 60 unique `.000` observations in `[T-60,T)` for reconstructed settlement averages.
- Uses API `expiration_value` from the strike-recovery cache when available, in a label-only namespace; reports reconstruction error against it.
- Handles the HYPE index transition without silently pooling both indices; the unresolved switch day is excluded from HYPE reference windows.
- Conditions on coin × horizon × session × weekday, with causal backoff to coin × horizon × session and then coin × horizon.
- Stores sparse integer counts by ISO week for later recombination.
- Requires 300 observations for a trading gate. 100–299 is descriptive only.
- Applies a configurable CF availability lag (default 250 ms) before any source-timestamped print is considered knowable.
- Emits returns, velocities, accelerations, realized volatility, gap/count diagnostics and volatility-normalized distance.
- Uses displayed reconstructed ask only; never falls back to logged cost.
- Emits both exact-order-fee and scalable-fee break-even probabilities.
- Emits conservative binned probability bounds, Wilson bounds, day-clustered bounds, DKW quantile bands, projected final-average quantiles, and side-aligned clearance versus K.
- Writes all input opportunities with explicit statuses.
- Uses a reused in-process `google.cloud.storage.Client`; no `subprocess` or `gsutil` path.

## Primary outputs

- `paper_bot_cf_reachability_rows.csv.gz`
- `cf_reference_counts.csv.gz`
- `cf_reachability_summary.json`
- `CF_REACHABILITY_REPORT.md`
- resumable local `cf_cache/`

## Test status

- Original embedded tests: passed, but did not cover the defects above.
- Patched embedded tests: all pass.
- Independent adversarial tests: **46 passed, 0 failed**.
- Synthetic end-to-end run: passed; rows reconciled and outputs were created.
