# Strike table builder v1.1 — reviewed patch

Run offline tests:

```bash
python3 build_strike_table_v1_1_gpt.py --self-test
python3 test_build_strike_table_v1_1_adversarial.py
```

Then probe production:

```bash
python3 build_strike_table_v1_1_gpt.py --probe \
  --from 2026-07-15 --to 2026-09-06
```

Production pass:

```bash
python3 build_strike_table_v1_1_gpt.py \
  --from 2026-07-15 --to 2026-09-06 \
  --out ~/strike_table \
  --settled ~/logs/paper_bot_logs_v2/settled_2026-07-15.csv
```

The code remains read-only against GCS. Development opportunities are restricted to 2026-07-15 through 2026-09-06; the September 7–13 holdout remains excluded unless deliberately overridden.
