# Run order on Probe2

## 1. Tests

```bash
python3 ~/cf_reachability_v1_1_gpt.py --self-test
python3 ~/test_cf_reachability_v1_1_adversarial.py
```

Both must end in `ALL PASS` / `0 failed`.

## 2. Cache-only stage

```bash
nohup python3 -u ~/cf_reachability_v1_1_gpt.py \
  --stage cache \
  --base ~/paper_bot_opportunity_base.csv \
  --coverage ~/strike_recovery_v1_1/opportunity_strike_coverage_recovered.csv \
  --api-cache ~/strike_recovery_v1_1/api_market_cache.jsonl \
  --out ~/cf_reach_v1_1 \
  --workers 8 \
  > ~/cf_reach_cache.log 2>&1 &
```

Monitor:

```bash
tail -20 ~/cf_reach_cache.log
```

The cache stage aborts on download/schema errors. `ABSENT` hours are counted and later appear as explicit missing reference windows.

## 3. Full overnight analysis

After cache-only succeeds:

```bash
nohup python3 -u ~/cf_reachability_v1_1_gpt.py \
  --stage all \
  --no-fetch \
  --base ~/paper_bot_opportunity_base.csv \
  --coverage ~/strike_recovery_v1_1/opportunity_strike_coverage_recovered.csv \
  --api-cache ~/strike_recovery_v1_1/api_market_cache.jsonl \
  --out ~/cf_reach_v1_1 \
  --cf-availability-lag-ms 250 \
  > ~/cf_reach_v1_1.log 2>&1 &
```

Monitor:

```bash
tail -30 ~/cf_reach_v1_1.log
```

Do not point the development run at September 7–13. The code refuses those opportunity rows.
