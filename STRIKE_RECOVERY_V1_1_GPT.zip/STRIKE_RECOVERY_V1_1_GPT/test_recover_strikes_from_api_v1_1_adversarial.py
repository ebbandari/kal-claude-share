#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import importlib.util
import io
import json
import tempfile
import urllib.error
from pathlib import Path

SRC = Path(__file__).with_name('recover_strikes_from_api_v1_1_gpt.py')
spec = importlib.util.spec_from_file_location('rec', SRC)
rec = importlib.util.module_from_spec(spec)
spec.loader.exec_module(rec)

FAILS = []
PASSES = []

def check(name, cond):
    (PASSES if cond else FAILS).append(name)
    print(f"{name:76s} {'PASS' if cond else 'FAIL'}")

class Resp:
    def __init__(self, obj, status=200):
        self.status = status
        self.raw = json.dumps(obj).encode()
    def read(self): return self.raw
    def __enter__(self): return self
    def __exit__(self, *a): return False

class ScriptedOpener:
    def __init__(self, actions):
        self.actions = list(actions)
        self.urls = []
    def __call__(self, req, timeout=0):
        self.urls.append(req.full_url)
        a = self.actions.pop(0)
        if isinstance(a, Exception): raise a
        return a

def http_error(url, code):
    return urllib.error.HTTPError(url, code, str(code), None, io.BytesIO(b'{}'))

# 1-4 numeric / comparator behavior
check('NaN, infinity and booleans are rejected as numeric strikes',
      rec.num(float('nan')) is None and rec.num(float('inf')) is None and rec.num(True) is None)
check('greater/greater_or_equal use floor_strike',
      rec.effective_strike({'strike_type':'greater','floor_strike':'12.3'}) == (12.3,'OK'))
check('less/less_or_equal use cap_strike',
      rec.effective_strike({'strike_type':'less_or_equal','cap_strike':'9.8'}) == (9.8,'OK'))
check('unknown comparator and missing required strike fail closed',
      rec.effective_strike({'strike_type':'weird','floor_strike':1})[0] is None and
      rec.effective_strike({'strike_type':'less','floor_strike':1})[0] is None)

# 5 ticker mismatch
r = rec.extract_market({'ticker':'OTHER','floor_strike':1,'strike_type':'greater'}, 'LIVE', 'WANTED')
check('API response for a different ticker is refused', r['record_status']=='TICKER_MISMATCH')

# 6 live success
op = ScriptedOpener([Resp({'market': {'ticker':'T','floor_strike':100,'strike_type':'greater_or_equal'}})])
a = rec.KalshiAPI(sleep=0,retries=1,opener=op)
r,s = a.get('T')
check('live endpoint success returns exact strike', s=='OK' and r['effective_strike']=='100.0' and r['endpoint']=='LIVE')

# 7 historical fallback
op = ScriptedOpener([
    http_error('x',404),
    Resp({'market': {'ticker':'OLD','floor_strike':55,'strike_type':'greater_or_equal'}})
])
a = rec.KalshiAPI(sleep=0,retries=1,opener=op)
r,s = a.get('OLD')
check('live 404 falls back to historical market endpoint',
      s=='OK' and r['endpoint']=='HISTORICAL' and '/historical/markets/' in op.urls[-1])

# 8 transient retry
op = ScriptedOpener([
    http_error('x',429),
    Resp({'market': {'ticker':'T','floor_strike':100,'strike_type':'greater_or_equal'}})
])
a = rec.KalshiAPI(sleep=0,retries=2,backoff=0,opener=op)
r,s = a.get('T')
check('HTTP 429 is retried and can recover', s=='OK' and len(op.urls)==2)

# 9 permanent error no historical fallback
op = ScriptedOpener([http_error('x',403)])
a = rec.KalshiAPI(sleep=0,retries=3,backoff=0,opener=op)
r,s = a.get('T')
check('HTTP 403 fails immediately and does not probe historical endpoint', r is None and s=='HTTP_403' and len(op.urls)==1)

# 10 malformed json
op = ScriptedOpener([Resp({},200)])
a = rec.KalshiAPI(sleep=0,retries=1,opener=op)
r,s = a.get('T')
check('missing market object cannot be mistaken for a successful market', r is None and 'HIST_' in s)

# 11 cache semantics
with tempfile.TemporaryDirectory() as td:
    p=Path(td)/'c.jsonl'
    c=rec.Cache(p)
    c.put('E', {'api_status':'HTTP_503','record_status':'API_FAILURE'})
    c.put('S', {'api_status':'OK','record_status':'OK','effective_strike':'1','strike_type':'greater'})
    c.close()
    c=rec.Cache(p)
    check('failed/transient fetch is not a reusable cache hit', c.get('E') is None)
    check('successful immutable fetch is a reusable cache hit', c.get('S') is not None)
    c.close()

# 13-15 opportunity-date / holdout / conflict behavior
rows=[
 {'ticker':'DEV','date':'2026-09-06','status':'OK','strike_asof':'1','comparator_asof':'greater'},
 {'ticker':'SEALED_LOCAL_PRIOR','date':'2026-09-07','status':'MISSING_STRIKE'},
 {'ticker':'FUTURE','date':'2026-09-14','status':'MISSING_STRIKE'},
]
st=rec.collections.Counter(); kept=rec.filter_coverage(rows, rec.DEFAULT_THROUGH, st)
check('holdout is guarded by opportunity UTC date, not ticker-local date',
      [x['ticker'] for x in kept]==['DEV'] and st['sealed_rows_refused']==1)
check('post-development opportunities are refused', st['after_through_refused']==1)
known, conflicts = rec.known_from_coverage([
 {'ticker':'T','status':'OK','strike_asof':'1','comparator_asof':'greater'},
 {'ticker':'T','status':'OK','strike_asof':'2','comparator_asof':'greater'},
])
check('conflicting lifecycle strikes are detected rather than chosen', conflicts==['T'] and 'T' not in known)

# 16 missing/unknown status not treated as known
known, conflicts = rec.known_from_coverage([
 {'ticker':'T','status':'STRIKE_CONFLICT','strike_asof':'1','comparator_asof':'greater'}])
check('non-OK lifecycle rows cannot enter the validation-known set', known=={})

# 17 validation missing comparator is disagreement
class VAPI:
    def get(self, tk):
        return {'effective_strike':'100','strike_type':'','record_status':'OK','endpoint':'LIVE'}, 'OK'
vs, vrows = rec.validate(VAPI(), {'T':(100.0,'greater_or_equal')}, 1, 1e-9, 1, lambda *_:None)
check('API strike with missing comparator fails validation', vs.get('disagree',0)==1)

# 18 deterministic sample
class AllAPI:
    def __init__(self): self.calls=[]
    def get(self, tk):
        self.calls.append(tk)
        return {'effective_strike':'1','strike_type':'greater','record_status':'OK','endpoint':'LIVE'},'OK'
known={f'T{i:03d}':(1.0,'greater') for i in range(100)}
a1=AllAPI(); rec.validate(a1,known,10,1e-9,7,lambda *_:None)
a2=AllAPI(); rec.validate(a2,known,10,1e-9,7,lambda *_:None)
check('validation sampling is deterministic under a fixed seed', a1.calls==a2.calls)

# 19-23 end-to-end synthetic run
with tempfile.TemporaryDirectory() as td:
    td=Path(td)
    cov=td/'coverage.csv'
    covrows=[
      {'t':'1785680000','date':'2026-08-02','ticker':'KNOWN','coin':'BTC','side':'YES','status':'OK',
       'strike_asof':'100','comparator_asof':'greater_or_equal'},
      {'t':'1785680100','date':'2026-08-02','ticker':'MISS','coin':'SOL','side':'NO','status':'MISSING_STRIKE',
       'strike_asof':'','comparator_asof':''},
      {'t':'1785680200','date':'2026-08-02','ticker':'MISS','coin':'SOL','side':'YES','status':'MISSING_STRIKE',
       'strike_asof':'','comparator_asof':''},
    ]
    with cov.open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(covrows[0])); w.writeheader(); w.writerows(covrows)
    class FakeAPI:
        def __init__(self, **kwargs): pass
        def get(self, tk):
            if tk=='KNOWN':
                return {'effective_strike':'100.0','floor_strike':'100','cap_strike':'',
                        'strike_type':'greater_or_equal','expiration_value':'101','result':'yes',
                        'close_time':'2026-08-02T14:00:00Z','status':'finalized','endpoint':'LIVE',
                        'market_ticker_api':'KNOWN','record_status':'OK'},'OK'
            if tk=='MISS':
                return {'effective_strike':'50.0','floor_strike':'50','cap_strike':'',
                        'strike_type':'greater_or_equal','expiration_value':'49','result':'no',
                        'close_time':'2026-08-02T14:15:00Z','status':'finalized','endpoint':'HISTORICAL',
                        'market_ticker_api':'MISS','record_status':'OK'},'OK'
            return None,'HTTP_404'
    old=rec.KalshiAPI; rec.KalshiAPI=FakeAPI
    try:
        args=argparse.Namespace(coverage=str(cov),out=str(td/'out'),through='2026-09-06',
            validate_n=1,min_validation_rate=1.0,min_validation_count=1,seed=7,tol=1e-9,
            sleep=0,timeout=1,retries=1,backoff=0,api_root='x',limit=0,also_known=False,dry_run=False)
        rc=rec.run(args)
    finally:
        rec.KalshiAPI=old
    final=list(csv.DictReader(open(td/'out'/'opportunity_strike_coverage_recovered.csv')))
    check('end-to-end recovery exits successfully', rc==0)
    check('every opportunity row survives the recovery join', len(final)==3)
    check('one recovered ticker fills all of its opportunity rows',
          sum(r['strike_source_final']=='API_RECOVERED' for r in final)==2)
    check('lifecycle-known row remains lifecycle sourced', final[0]['strike_source_final']=='LIFECYCLE_ASOF')
    check('API expiration and result fields are preserved',
          final[1]['expiration_value_api']=='49' and final[1]['result_api']=='no')


# additional cache/API safety checks
with tempfile.TemporaryDirectory() as td:
    pth=Path(td)/'c2.jsonl'
    c=rec.Cache(pth)
    c.put('T', {'api_status':'OK','record_status':'OK','effective_strike':'1','strike_type':'greater'})
    c.put('T', {'api_status':'HTTP_503','record_status':'API_FAILURE'})
    c.close()
    c=rec.Cache(pth)
    check('later transient cache record cannot erase an earlier success', c.get('T') is not None)
    c.close()

op = ScriptedOpener([
    TimeoutError('network'),
    Resp({'market': {'ticker':'N','floor_strike':1,'strike_type':'greater'}})
])
a = rec.KalshiAPI(sleep=0,retries=2,backoff=0,opener=op)
r,s = a.get('N')
check('transport timeout is retried and can recover', s=='OK' and len(op.urls)==2)

op = ScriptedOpener([http_error('x',404), http_error('y',404)])
a = rec.KalshiAPI(sleep=0,retries=1,backoff=0,opener=op)
r,s = a.get('ABSENT')
check('dual live/historical 404 is explicit and not a false success',
      r is None and s=='LIVE_HTTP_404|HIST_HTTP_404')

check('zero or negative effective strike is rejected',
      rec.effective_strike({'strike_type':'greater','floor_strike':0})[0] is None and
      rec.effective_strike({'strike_type':'less','cap_strike':-1})[0] is None)


# Validation gate must refuse low API availability or any mismatch.
with tempfile.TemporaryDirectory() as td:
    td=Path(td); cov=td/'cov.csv'
    rr=[
      {'date':'2026-08-01','ticker':'K1','status':'OK','strike_asof':'1','comparator_asof':'greater'},
      {'date':'2026-08-01','ticker':'K2','status':'OK','strike_asof':'2','comparator_asof':'greater'},
      {'date':'2026-08-01','ticker':'M','status':'MISSING_STRIKE','strike_asof':'','comparator_asof':''},
    ]
    with cov.open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rr[0])); w.writeheader(); w.writerows(rr)
    class LowAvail:
        def __init__(self, **kw): pass
        def get(self,tk):
            if tk=='K1': return {'effective_strike':'1','strike_type':'greater','record_status':'OK','endpoint':'LIVE'},'OK'
            return None,'HTTP_503'
    old=rec.KalshiAPI; rec.KalshiAPI=LowAvail
    try:
        args=argparse.Namespace(coverage=str(cov),out=str(td/'o'),through='2026-09-06',validate_n=2,
            min_validation_rate=1.0,min_validation_count=1,seed=7,tol=1e-9,sleep=0,timeout=1,retries=1,
            backoff=0,api_root='x',limit=0,also_known=False,dry_run=False)
        rc=rec.run(args)
    finally: rec.KalshiAPI=old
    check('run refuses when validation availability is below the declared gate', rc==2)

with tempfile.TemporaryDirectory() as td:
    td=Path(td); cov=td/'cov.csv'
    rr=[{'date':'2026-08-01','ticker':'K','status':'OK','strike_asof':'1','comparator_asof':'greater'},
        {'date':'2026-08-01','ticker':'M','status':'MISSING_STRIKE','strike_asof':'','comparator_asof':''}]
    with cov.open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rr[0])); w.writeheader(); w.writerows(rr)
    class Mismatch:
        def __init__(self, **kw): pass
        def get(self,tk): return {'effective_strike':'9','strike_type':'greater','record_status':'OK','endpoint':'LIVE'},'OK'
    old=rec.KalshiAPI; rec.KalshiAPI=Mismatch
    try:
        args=argparse.Namespace(coverage=str(cov),out=str(td/'o'),through='2026-09-06',validate_n=1,
            min_validation_rate=1.0,min_validation_count=1,seed=7,tol=1e-9,sleep=0,timeout=1,retries=1,
            backoff=0,api_root='x',limit=0,also_known=False,dry_run=False)
        rc=rec.run(args)
    finally: rec.KalshiAPI=old
    check('run refuses on any validation strike mismatch', rc==2)

print(f"\n{len(PASSES)} passed; {len(FAILS)} failed")
if FAILS:
    print('FAILURES:', *FAILS, sep='\n  ')
    raise SystemExit(1)
