#!/usr/bin/env python3
"""
build_grok_schema_pack_v2_1_gpt.py

Build a compact, auditable research package for an outside model that cannot
read the project's GCS bucket directly.

The package contains:
  * a six-coin inventory and stream-availability manifest;
  * headers, inferred dtypes, and contiguous real samples for every distinct
    stream type found in the selected KCP session;
  * an actual bounded, synchronized time window for selected coins—not entire
    multi-hour session files;
  * CF REST and both CF WebSocket channels over the same window;
  * a small HYPE exception sample and pre/post index-transition examples;
  * optional v9 samples/window data when a matching session ZIP is discoverable;
  * unmodified metadata, including blank strikes;
  * a README asking the receiving model exactly what additional data it needs.

The source archive is never modified.
"""
from __future__ import annotations

import argparse
import contextlib
import csv
import datetime as dt
import fnmatch
import gzip
import hashlib
import io
import json
import math
import os
import re
import shutil
import statistics
import subprocess
import sys
import tempfile
import zipfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable, Iterator, Sequence

DEFAULT_BUCKET = "gs://kalshi-data-vault-kalshi-collector-personal"
ALL_COINS = ("BTC", "ETH", "SOL", "XRP", "DOGE", "HYPE")
WS_DATA_BEGINS = dt.date(2026, 9, 5)
SAMPLE_ROWS = 20
SCHEMA_PREVIEW_ROWS = 8

CSV_TIMESTAMP_KEYS = (
    # Prefer availability/receive clocks for extracting the compact window.
    # Source/exchange clocks remain in every row and are used later for venue
    # alignment; receive-time boundaries keep the extract causally observable.
    "recv_ts_utc", "local_receive_ts_utc", "kalshi_received_at_utc",
    "ts_utc", "local_receive_ts_ms",
    # Fall back to source/exchange/event clocks when no receive clock exists.
    "source_ts_utc", "exchange_ts", "source_ts", "created_time",
    "event_ts_utc", "timestamp_utc", "source_ts_ms", "created_ts",
    "event_time", "ts_ms", "timestamp_ms",
    "t", "timestamp", "time",
)
JSON_TIMESTAMP_KEYS = CSV_TIMESTAMP_KEYS

SOURCE_CLOCK_FIELDS = {
    "source_ts_utc", "exchange_ts", "source_ts", "created_time",
    "event_ts_utc", "timestamp_utc", "source_ts_ms", "created_ts",
    "event_time", "ts_ms", "timestamp_ms",
}
RECEIVE_CLOCK_FIELDS = {
    "kalshi_received_at_utc", "recv_ts_utc", "local_receive_ts_utc",
    "ts_utc", "local_receive_ts_ms",
}

SESSION_RANGES = {
    "OvernightAsia": (0, 7 * 3600),
    "EuropeanAM": (7 * 3600, 13 * 3600 + 30 * 60),
    "USsession": (13 * 3600 + 30 * 60, 20 * 3600),
    "AfterHours": (20 * 3600, 24 * 3600),
}

WINDOWABLE_SUFFIXES = (".csv", ".csv.gz", ".jsonl", ".jsonl.gz")


def uri_join(base: str, *parts: str) -> str:
    out = base.rstrip("/")
    for p in parts:
        if p:
            out += "/" + str(p).strip("/")
    return out


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def canonical_json_bytes(obj: Any) -> bytes:
    return (json.dumps(obj, sort_keys=True, separators=(",", ":"),
                       ensure_ascii=False) + "\n").encode("utf-8")


# ---------------------------------------------------------------------------
# Storage abstraction
# ---------------------------------------------------------------------------

class StoreError(RuntimeError):
    pass


class GsutilStore:
    """Read-only GCS access through gsutil. The builder never writes to GCS."""

    def _run(self, cmd: Sequence[str], timeout: int = 300) -> subprocess.CompletedProcess:
        try:
            return subprocess.run(list(cmd), capture_output=True, timeout=timeout)
        except FileNotFoundError as exc:
            raise StoreError("gsutil is not installed or not on PATH") from exc
        except subprocess.TimeoutExpired as exc:
            raise StoreError(f"command timed out: {' '.join(cmd)}") from exc

    def preflight(self) -> None:
        p = self._run(["gsutil", "version", "-l"], timeout=30)
        if p.returncode != 0:
            raise StoreError(p.stderr.decode("utf-8", "replace")[:500])

    def list(self, pattern: str) -> list[str]:
        p = self._run(["gsutil", "ls", pattern], timeout=300)
        if p.returncode != 0:
            return []
        return [x.strip() for x in p.stdout.decode("utf-8", "replace").splitlines()
                if x.strip().startswith("gs://")]

    def list_entries(self, prefix: str) -> list[tuple[str, int | None]]:
        pattern = prefix.rstrip("/") + "/*"
        p = self._run(["gsutil", "ls", "-l", pattern], timeout=300)
        if p.returncode != 0:
            return []
        out: list[tuple[str, int | None]] = []
        for line in p.stdout.decode("utf-8", "replace").splitlines():
            s = line.strip()
            if not s or s.startswith("TOTAL:"):
                continue
            m = re.match(r"^(\d+)\s+\S+\s+(gs://\S+)$", s)
            if m:
                out.append((m.group(2), int(m.group(1))))
            elif s.startswith("gs://"):
                out.append((s, None))
        return out

    def exists(self, uri: str) -> bool:
        p = self._run(["gsutil", "-q", "stat", uri], timeout=60)
        return p.returncode == 0

    def size(self, uri: str) -> int | None:
        p = self._run(["gsutil", "du", "-s", uri], timeout=300)
        if p.returncode != 0:
            return None
        try:
            return int(p.stdout.decode().split()[0])
        except (ValueError, IndexError):
            return None

    def read_bytes(self, uri: str, timeout: int = 900) -> bytes:
        p = self._run(["gsutil", "cat", uri], timeout=timeout)
        if p.returncode != 0:
            raise StoreError(f"could not read {uri}: " +
                             p.stderr.decode("utf-8", "replace")[:500])
        return bytes(p.stdout)

    def download(self, uri: str, dest: Path, timeout: int = 1800) -> None:
        dest.parent.mkdir(parents=True, exist_ok=True)
        p = self._run(["gsutil", "-q", "cp", uri, str(dest)], timeout=timeout)
        if p.returncode != 0 or not dest.exists():
            raise StoreError(f"could not download {uri}: " +
                             p.stderr.decode("utf-8", "replace")[:500])

    def iter_text(self, uri: str) -> Iterator[str]:
        """Stream text from GCS. Breaking early terminates the gsutil process."""
        try:
            p = subprocess.Popen(["gsutil", "cat", uri], stdout=subprocess.PIPE,
                                 stderr=subprocess.PIPE)
        except FileNotFoundError as exc:
            raise StoreError("gsutil is not installed or not on PATH") from exc
        assert p.stdout is not None
        raw: Any = p.stdout
        gz: gzip.GzipFile | None = None
        if uri.endswith(".gz"):
            gz = gzip.GzipFile(fileobj=p.stdout, mode="rb")
            raw = gz
        txt = io.TextIOWrapper(raw, encoding="utf-8", errors="replace", newline="")
        try:
            for line in txt:
                yield line
        finally:
            with contextlib.suppress(Exception):
                txt.detach()
            with contextlib.suppress(Exception):
                if gz is not None:
                    gz.close()
            with contextlib.suppress(Exception):
                p.stdout.close()
            if p.poll() is None:
                with contextlib.suppress(Exception):
                    p.terminate()
                with contextlib.suppress(Exception):
                    p.wait(timeout=2)
                if p.poll() is None:
                    with contextlib.suppress(Exception):
                        p.kill()


class FakeStore:
    """In-memory object store used by --self-test."""

    def __init__(self, objects: dict[str, bytes]):
        self.objects = dict(objects)

    def preflight(self) -> None:
        return None

    def _keys(self) -> list[str]:
        return sorted(self.objects)

    def list(self, pattern: str) -> list[str]:
        keys = self._keys()
        if any(ch in pattern for ch in "*?["):
            return [k for k in keys if fnmatch.fnmatch(k, pattern)]
        if pattern in self.objects:
            return [pattern]
        prefix = pattern.rstrip("/") + "/"
        children: set[str] = set()
        for k in keys:
            if not k.startswith(prefix):
                continue
            rest = k[len(prefix):]
            if "/" in rest:
                children.add(prefix + rest.split("/", 1)[0] + "/")
            else:
                children.add(k)
        return sorted(children)

    def list_entries(self, prefix: str) -> list[tuple[str, int | None]]:
        out = []
        for uri in self.list(prefix):
            if uri in self.objects:
                out.append((uri, len(self.objects[uri])))
        return out

    def exists(self, uri: str) -> bool:
        return uri in self.objects

    def size(self, uri: str) -> int | None:
        if uri in self.objects:
            return len(self.objects[uri])
        prefix = uri.rstrip("/") + "/"
        vals = [len(v) for k, v in self.objects.items() if k.startswith(prefix)]
        return sum(vals) if vals else None

    def read_bytes(self, uri: str, timeout: int = 900) -> bytes:
        del timeout
        if uri not in self.objects:
            raise StoreError(f"missing fake object {uri}")
        return self.objects[uri]

    def download(self, uri: str, dest: Path, timeout: int = 1800) -> None:
        del timeout
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(self.read_bytes(uri))

    def iter_text(self, uri: str) -> Iterator[str]:
        b = self.read_bytes(uri)
        if uri.endswith(".gz"):
            b = gzip.decompress(b)
        yield from io.StringIO(b.decode("utf-8", "replace"))


# ---------------------------------------------------------------------------
# Parsing and sampling
# ---------------------------------------------------------------------------


def parse_time(value: Any) -> dt.datetime | None:
    if value in (None, "") or isinstance(value, bool):
        return None
    if isinstance(value, str):
        s = value.strip()
        if not s:
            return None
        try:
            return parse_time(float(s))
        except ValueError:
            pass
        try:
            d = dt.datetime.fromisoformat(s.replace("Z", "+00:00"))
            return d if d.tzinfo else d.replace(tzinfo=dt.timezone.utc)
        except ValueError:
            return None
    if isinstance(value, (int, float)):
        x = float(value)
        if not math.isfinite(x):
            return None
        ax = abs(x)
        if ax > 1e18:      # nanoseconds
            x /= 1e9
        elif ax > 1e15:    # microseconds
            x /= 1e6
        elif ax > 1e11:    # milliseconds
            x /= 1e3
        try:
            return dt.datetime.fromtimestamp(x, dt.timezone.utc)
        except (OverflowError, OSError, ValueError):
            return None
    return None


def iso_z(d: dt.datetime) -> str:
    return d.astimezone(dt.timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")


def infer_dtype(v: Any) -> str:
    if v in (None, ""):
        return "null/blank"
    if isinstance(v, bool):
        return "bool"
    if isinstance(v, (dict, list)):
        return "json"
    s = str(v).strip()
    try:
        x = float(s)
        if not math.isfinite(x):
            return "nonfinite-number"
        return "int" if x.is_integer() and all(c not in s.lower() for c in (".", "e")) else "float"
    except (ValueError, TypeError, OverflowError):
        pass
    if parse_time(s) is not None and ("-" in s or "T" in s or "Z" in s):
        return "timestamp-iso"
    if s[:1] in "[{":
        try:
            json.loads(s)
            return "json"
        except Exception:
            pass
    return "string"


def flatten_types(obj: Any, prefix: str = "", depth: int = 3,
                  out: dict[str, set[str]] | None = None) -> dict[str, set[str]]:
    out = out if out is not None else {}
    if depth > 0 and isinstance(obj, dict):
        for k, v in obj.items():
            p = f"{prefix}.{k}" if prefix else str(k)
            flatten_types(v, p, depth - 1, out)
    elif depth > 0 and isinstance(obj, list):
        out.setdefault(prefix, set()).add("list")
        if obj:
            flatten_types(obj[0], prefix + "[]", depth - 1, out)
    else:
        out.setdefault(prefix or "$", set()).add(infer_dtype(obj))
    return out


def find_json_time(obj: Any, depth: int = 4) -> tuple[dt.datetime | None, str | None]:
    if not isinstance(obj, dict) or depth < 0:
        return None, None
    for k in JSON_TIMESTAMP_KEYS:
        if k in obj:
            t = parse_time(obj.get(k))
            if t is not None:
                return t, k
    for container in ("msg", "data", "raw", "payload", "event", "record"):
        v = obj.get(container)
        if isinstance(v, dict):
            t, k = find_json_time(v, depth - 1)
            if t is not None:
                return t, f"{container}.{k}"
    return None, None


def choose_csv_time_column(header: Sequence[str]) -> str | None:
    lower = {str(c).strip().lower(): c for c in header}
    for k in CSV_TIMESTAMP_KEYS:
        if k.lower() in lower:
            return str(lower[k.lower()])
    return None


def cadence_summary(times: Sequence[dt.datetime]) -> dict[str, Any]:
    if len(times) < 2:
        return {"sample_first_ts": iso_z(times[0]) if times else None,
                "sample_last_ts": iso_z(times[-1]) if times else None,
                "sample_median_gap_s": None}
    gaps = [(b - a).total_seconds() for a, b in zip(times, times[1:])
            if (b - a).total_seconds() >= 0]
    return {"sample_first_ts": iso_z(times[0]), "sample_last_ts": iso_z(times[-1]),
            "sample_median_gap_s": statistics.median(gaps) if gaps else None}


def describe_csv_lines(lines: Iterable[str], n: int = SAMPLE_ROWS) -> tuple[dict[str, Any], str]:
    rd = csv.reader(lines)
    header = next(rd, None)
    out: dict[str, Any] = {"format": "csv", "header": header or [], "dtypes": {},
                           "rows": [], "note": ""}
    if not header:
        out["note"] = "empty or unreadable"
        return out, ""
    for _ in range(n):
        row = next(rd, None)
        if row is None:
            break
        out["rows"].append(row)
    for i, col in enumerate(header):
        vals = [r[i] for r in out["rows"] if i < len(r)]
        types = {infer_dtype(v) for v in vals} - {"null/blank"}
        blanks = sum(v in (None, "") for v in vals)
        d = "/".join(sorted(types)) if types else "all blank in sample"
        if blanks and types:
            d += f" ({blanks}/{len(vals)} blank)"
        out["dtypes"][col] = d
    tc = choose_csv_time_column(header)
    times = []
    if tc:
        idx = list(header).index(tc)
        for row in out["rows"]:
            if idx < len(row):
                t = parse_time(row[idx])
                if t is not None:
                    times.append(t)
    out["timestamp_field"] = tc
    out.update(cadence_summary(times))
    sio = io.StringIO(newline="")
    wr = csv.writer(sio, lineterminator="\n")
    wr.writerow(header)
    wr.writerows(out["rows"])
    return out, sio.getvalue()


def describe_jsonl_lines(lines: Iterable[str], n: int = SAMPLE_ROWS) -> tuple[dict[str, Any], str]:
    out: dict[str, Any] = {"format": "jsonl", "keys": [], "field_types": {},
                           "rows": [], "note": ""}
    unions: dict[str, set[str]] = {}
    times: list[dt.datetime] = []
    time_fields: set[str] = set()
    for line in lines:
        if len(out["rows"]) >= n:
            break
        s = line.rstrip("\n")
        if not s:
            continue
        out["rows"].append(s)
        try:
            obj = json.loads(s)
        except Exception:
            out["note"] = "one or more sample lines are not parseable JSON"
            continue
        for k, vals in flatten_types(obj).items():
            unions.setdefault(k, set()).update(vals)
        t, key = find_json_time(obj)
        if t is not None:
            times.append(t)
        if key:
            time_fields.add(key)
    out["keys"] = sorted(k for k in unions if "." not in k and "[]" not in k)
    out["field_types"] = {k: "/".join(sorted(v)) for k, v in sorted(unions.items())}
    out["timestamp_fields_seen"] = sorted(time_fields)
    out.update(cadence_summary(times))
    text = "\n".join(out["rows"]) + ("\n" if out["rows"] else "")
    return out, text


def sample_uri(store: Any, uri: str, stream_id: str, sampled_from: str,
               schema_dir: Path, size: int | None = None) -> dict[str, Any]:
    lines = store.iter_text(uri)
    is_jsonl = ".jsonl" in uri
    desc, text = (describe_jsonl_lines(lines) if is_jsonl else describe_csv_lines(lines))
    desc.update(stream=stream_id, sampled_from=sampled_from, source_uri=uri,
                compressed_bytes=size)
    safe = re.sub(r"[^A-Za-z0-9_.-]+", "_", stream_id)
    ext = ".jsonl" if is_jsonl else ".csv"
    sample_path = schema_dir / "samples" / f"{safe}{ext}"
    sample_path.parent.mkdir(parents=True, exist_ok=True)
    sample_path.write_text(text, encoding="utf-8")
    desc["sample_file"] = str(sample_path.relative_to(schema_dir.parent))
    (schema_dir / f"{safe}.schema.json").write_bytes(canonical_json_bytes(desc))
    return desc


# ---------------------------------------------------------------------------
# Window extraction
# ---------------------------------------------------------------------------

@dataclass
class ExtractStats:
    source_uri: str
    output_file: str
    format: str
    status: str = "OK"
    timestamp_field: str | None = None
    timestamp_clock_role: str | None = None
    rows_seen: int = 0
    rows_written: int = 0
    parse_failures: int = 0
    monotonic_violations: int = 0
    first_written_ts: str | None = None
    last_written_ts: str | None = None

    def as_dict(self) -> dict[str, Any]:
        return self.__dict__.copy()


def _open_output_text(path: Path):
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.suffix == ".gz":
        return io.TextIOWrapper(gzip.GzipFile(filename=str(path), mode="wb", mtime=0),
                                encoding="utf-8", newline="")
    return path.open("w", encoding="utf-8", newline="")


def timestamp_clock_role(field: str | None) -> str | None:
    if not field:
        return None
    leaf = field.split(".")[-1]
    if leaf in SOURCE_CLOCK_FIELDS:
        return "source/exchange/event"
    if leaf in RECEIVE_CLOCK_FIELDS:
        return "receive/local"
    return "generic/unknown"


def extract_csv_lines(lines: Iterable[str], source_uri: str, dest: Path,
                      start: dt.datetime, end: dt.datetime) -> ExtractStats:
    st = ExtractStats(source_uri, str(dest), "csv")
    rd = csv.DictReader(lines)
    if not rd.fieldnames:
        st.status = "EMPTY_OR_UNREADABLE"
        return st
    tc = choose_csv_time_column(rd.fieldnames)
    st.timestamp_field = tc
    st.timestamp_clock_role = timestamp_clock_role(tc)
    if tc is None:
        st.status = "NO_TIMESTAMP_COLUMN"
        return st
    with _open_output_text(dest) as out_fh:
        wr = csv.DictWriter(out_fh, fieldnames=rd.fieldnames, lineterminator="\n")
        wr.writeheader()
        last_t: dt.datetime | None = None
        beyond = 0
        for row in rd:
            st.rows_seen += 1
            t = parse_time(row.get(tc))
            if t is None:
                st.parse_failures += 1
                continue
            if last_t is not None and t < last_t:
                st.monotonic_violations += 1
            last_t = t
            if t < start:
                continue
            if t > end:
                beyond += 1
                # Files are appended in receive order. Early exit is permitted
                # only when the selected cut clock is receive/local and no
                # disorder has been observed. Source-clock extracts scan fully.
                if (st.timestamp_clock_role == "receive/local" and
                        beyond >= 50 and st.monotonic_violations == 0):
                    break
                continue
            beyond = 0
            wr.writerow(row)
            st.rows_written += 1
            if st.first_written_ts is None:
                st.first_written_ts = iso_z(t)
            st.last_written_ts = iso_z(t)
    if st.rows_written == 0:
        st.status = "NO_ROWS_IN_WINDOW"
    return st


def extract_jsonl_lines(lines: Iterable[str], source_uri: str, dest: Path,
                        start: dt.datetime, end: dt.datetime) -> ExtractStats:
    st = ExtractStats(source_uri, str(dest), "jsonl")
    time_fields: set[str] = set()
    with _open_output_text(dest) as out_fh:
        last_t: dt.datetime | None = None
        beyond = 0
        selected_role: str | None = None
        for line in lines:
            st.rows_seen += 1
            try:
                obj = json.loads(line)
            except Exception:
                st.parse_failures += 1
                continue
            t, key = find_json_time(obj)
            if key:
                time_fields.add(key)
                role = timestamp_clock_role(key)
                if selected_role is None:
                    selected_role = role
                elif role != selected_role:
                    selected_role = "mixed"
            if t is None:
                st.parse_failures += 1
                continue
            if last_t is not None and t < last_t:
                st.monotonic_violations += 1
            last_t = t
            if t < start:
                continue
            if t > end:
                beyond += 1
                if (selected_role == "receive/local" and beyond >= 50 and
                        st.monotonic_violations == 0):
                    break
                continue
            beyond = 0
            out_fh.write(line if line.endswith("\n") else line + "\n")
            st.rows_written += 1
            if st.first_written_ts is None:
                st.first_written_ts = iso_z(t)
            st.last_written_ts = iso_z(t)
    st.timestamp_field = ";".join(sorted(time_fields)) or None
    roles = {timestamp_clock_role(k) for k in time_fields if timestamp_clock_role(k)}
    st.timestamp_clock_role = ";".join(sorted(roles)) or None
    if st.rows_written == 0:
        st.status = "NO_ROWS_IN_WINDOW"
    return st


def extract_uri_window(store: Any, uri: str, dest: Path,
                       start: dt.datetime, end: dt.datetime) -> ExtractStats:
    if ".jsonl" in uri:
        return extract_jsonl_lines(store.iter_text(uri), uri, dest, start, end)
    if ".csv" in uri:
        return extract_csv_lines(store.iter_text(uri), uri, dest, start, end)
    return ExtractStats(uri, str(dest), "other", status="UNSUPPORTED_FOR_WINDOW")


def extract_local_window(src: Path, dest: Path, start: dt.datetime,
                         end: dt.datetime, source_label: str) -> ExtractStats:
    def it() -> Iterator[str]:
        if src.name.endswith(".gz"):
            with gzip.open(src, "rt", encoding="utf-8", errors="replace", newline="") as fh:
                yield from fh
        else:
            with src.open("r", encoding="utf-8", errors="replace", newline="") as fh:
                yield from fh
    if ".jsonl" in src.name:
        return extract_jsonl_lines(it(), source_label, dest, start, end)
    if ".csv" in src.name:
        return extract_csv_lines(it(), source_label, dest, start, end)
    return ExtractStats(source_label, str(dest), "other", status="UNSUPPORTED_FOR_WINDOW")


# ---------------------------------------------------------------------------
# Metadata and reporting
# ---------------------------------------------------------------------------


def read_csv_any(path: Path) -> Iterator[dict[str, str]]:
    opener = gzip.open if path.name.endswith(".gz") else open
    with opener(path, "rt", encoding="utf-8", errors="replace", newline="") as fh:
        yield from csv.DictReader(fh)


def build_metadata_sample(roots: Sequence[Path], out_path: Path) -> int:
    """Build metadata from synchronized and exception roots.

    HYPE lives under ``exception/`` rather than ``window/``; scanning both is
    required so the exception sample carries its own close/strike/settlement
    metadata instead of only raw ticks.
    """
    records: dict[tuple[str, str], dict[str, Any]] = {}
    for root in roots:
        if not root.exists():
            continue
        for coin_dir in sorted(p for p in root.iterdir()
                               if p.is_dir() and p.name in ALL_COINS):
            coin = coin_dir.name
            snap = next(iter(coin_dir.glob("kalshi_snapshots.csv*")), None)
            life = next(iter(coin_dir.glob("kalshi_lifecycle.csv*")), None)
            if snap:
                for r in read_csv_any(snap):
                    ticker = r.get("market_ticker", "")
                    if not ticker:
                        continue
                    x = records.setdefault((coin, ticker),
                                           {"coin": coin, "market_ticker": ticker})
                    for k in ("close_time", "floor_strike", "seconds_to_close"):
                        if k in r:
                            val = r.get(k, "")
                            if k not in x or (x.get(k, "") == "" and val not in (None, "")):
                                x[k] = val
                    if "floor_strike" in r and r.get("floor_strike", "") == "":
                        x.setdefault("floor_strike", "")
            if life:
                for r in read_csv_any(life):
                    ticker = r.get("market_ticker", "")
                    if not ticker:
                        continue
                    x = records.setdefault((coin, ticker),
                                           {"coin": coin, "market_ticker": ticker})
                    for k in ("event_subtype", "status", "open_ts", "close_ts",
                              "settlement_value"):
                        if k in r and r.get(k, "") not in (None, ""):
                            x[k] = r.get(k, "")
    fields = ["coin", "market_ticker", "close_time", "floor_strike",
              "seconds_to_close", "event_subtype", "status", "open_ts",
              "close_ts", "settlement_value"]
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with out_path.open("w", encoding="utf-8", newline="") as fh:
        wr = csv.DictWriter(fh, fieldnames=fields, extrasaction="ignore")
        wr.writeheader()
        for rec in sorted(records.values(),
                          key=lambda x: (x.get("coin", ""), x.get("market_ticker", ""))):
            wr.writerow(rec)
    return len(records)


def render_schema(desc: dict[str, Any]) -> str:
    lines = [f"## `{desc['stream']}`",
             f"sampled from `{desc.get('sampled_from')}` | "
             f"compressed bytes: {desc.get('compressed_bytes') or 'unknown'}"]
    if desc.get("note"):
        lines.append(f"**note:** {desc['note']}")
    if desc["format"] == "csv":
        lines.append("\n| column | inferred type in sample |\n|---|---|")
        lines.extend(f"| `{k}` | {v} |" for k, v in desc.get("dtypes", {}).items())
        lines.append(f"\nActual contiguous sample: `{desc.get('sample_file')}`")
    else:
        lines.append("\n| JSON path | inferred type in sample |\n|---|---|")
        lines.extend(f"| `{k}` | {v} |" for k, v in desc.get("field_types", {}).items())
        lines.append(f"\nActual contiguous sample: `{desc.get('sample_file')}`")
    if desc.get("sample_median_gap_s") is not None:
        lines.append(f"\nSample median consecutive gap: **{desc['sample_median_gap_s']:.6g} s**")
    return "\n".join(lines)


@dataclass
class BuildReport:
    warnings: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)
    extractions: list[dict[str, Any]] = field(default_factory=list)
    inventory_rows: int = 0
    schema_count: int = 0
    metadata_rows: int = 0
    v9_included: bool = False

    def warn(self, msg: str) -> None:
        self.warnings.append(msg)
        print("WARN:", msg, file=sys.stderr)

    def error(self, msg: str) -> None:
        self.errors.append(msg)
        print("ERROR:", msg, file=sys.stderr)


# ---------------------------------------------------------------------------
# v9 support
# ---------------------------------------------------------------------------

V9_WINDOW_MEMBERS = (
    "kalshi_raw_orderbooks.jsonl.gz", "kalshi_snapshots.csv.gz",
    "kalshi_trades.csv.gz", "coinbase_ticks.csv.gz", "lag_calibration.csv.gz",
    "events.jsonl", "heartbeat.jsonl", "errors.jsonl",
)


def discover_v9_zip(store: Any, bucket: str, date: str, session: str) -> str | None:
    patterns = [
        f"{bucket.rstrip('/')}/{date}_*/*{session}*.zip",
        f"{bucket.rstrip('/')}/v9*/*{date}*{session}*.zip",
    ]
    for pat in patterns:
        hits = store.list(pat)
        if hits:
            return sorted(hits)[0]
    return None


def include_v9(store: Any, uri: str, tmp: Path, out: Path,
               schema_descs: list[dict[str, Any]], start: dt.datetime,
               end: dt.datetime, report: BuildReport, inventory: list[dict[str, Any]]) -> None:
    zpath = tmp / "v9_session.zip"
    store.download(uri, zpath)
    inventory.append({"family": "v9 session zip", "source_uri": uri,
                      "compressed_bytes": zpath.stat().st_size})
    with zipfile.ZipFile(zpath) as zf:
        members = [m for m in zf.namelist() if not m.endswith("/")]
        seen_names: set[str] = set()
        for member in members:
            base = Path(member).name
            if not base or base in seen_names:
                continue
            seen_names.add(base)
            data = zf.read(member)
            local = tmp / "v9" / base
            local.parent.mkdir(parents=True, exist_ok=True)
            local.write_bytes(data)
            if base.endswith(WINDOWABLE_SUFFIXES):
                try:
                    if ".jsonl" in base:
                        def lines() -> Iterator[str]:
                            opener = gzip.open if base.endswith(".gz") else open
                            with opener(local, "rt", encoding="utf-8", errors="replace") as fh:
                                for i, line in enumerate(fh):
                                    if i >= SAMPLE_ROWS:
                                        break
                                    yield line
                        desc, text = describe_jsonl_lines(lines())
                    else:
                        def lines2() -> Iterator[str]:
                            opener = gzip.open if base.endswith(".gz") else open
                            with opener(local, "rt", encoding="utf-8", errors="replace", newline="") as fh:
                                for i, line in enumerate(fh):
                                    if i > SAMPLE_ROWS:
                                        break
                                    yield line
                        desc, text = describe_csv_lines(lines2())
                    stream_id = "v9__" + base
                    desc.update(stream=stream_id, sampled_from="v9", source_uri=uri + "#" + member,
                                compressed_bytes=len(data))
                    safe = re.sub(r"[^A-Za-z0-9_.-]+", "_", stream_id)
                    ext = ".jsonl" if ".jsonl" in base else ".csv"
                    sp = out / "schemas" / "samples" / f"{safe}{ext}"
                    sp.parent.mkdir(parents=True, exist_ok=True)
                    sp.write_text(text, encoding="utf-8")
                    desc["sample_file"] = str(sp.relative_to(out))
                    (out / "schemas" / f"{safe}.schema.json").write_bytes(canonical_json_bytes(desc))
                    schema_descs.append(desc)
                except Exception as exc:
                    report.warn(f"v9 schema sample failed for {base}: {exc}")
            if base in V9_WINDOW_MEMBERS:
                dest = out / "window" / "v9" / base
                st = extract_local_window(local, dest, start, end, uri + "#" + member)
                report.extractions.append(st.as_dict())
            elif base in ("manifest.json", "v9_run_config.json"):
                dest = out / "window" / "v9" / base
                dest.parent.mkdir(parents=True, exist_ok=True)
                dest.write_bytes(data)
    report.v9_included = True


# ---------------------------------------------------------------------------
# Build
# ---------------------------------------------------------------------------


def parse_market_open(date: str, value: str) -> dt.datetime:
    if "T" in value or value.endswith("Z") or "+" in value:
        t = parse_time(value)
    else:
        t = parse_time(f"{date}T{value}:00Z" if len(value) <= 5 else f"{date}T{value}Z")
    if t is None:
        raise ValueError("--market-open must be HH:MM or an ISO-8601 timestamp")
    return t.astimezone(dt.timezone.utc)


def hour_starts(start: dt.datetime, end: dt.datetime) -> list[dt.datetime]:
    h = start.replace(minute=0, second=0, microsecond=0)
    out = []
    while h <= end:
        out.append(h)
        h += dt.timedelta(hours=1)
    return out


def parse_session_date(uri: str) -> str | None:
    m = re.search(r"(20\d{2}-\d{2}-\d{2})", uri)
    return m.group(1) if m else None


def build(args: argparse.Namespace, store: Any) -> int:
    out = Path(os.path.expanduser(args.out)).resolve()
    if out.exists():
        if args.force:
            shutil.rmtree(out)
        elif any(out.iterdir()):
            print(f"refusing non-empty output directory without --force: {out}", file=sys.stderr)
            return 2
    for p in (out / "schemas" / "samples", out / "window", out / "exception",
              out / "metadata"):
        p.mkdir(parents=True, exist_ok=True)
    tmp = out / ".tmp"
    tmp.mkdir(exist_ok=True)

    report = BuildReport()
    inventory: list[dict[str, Any]] = []
    schemas: list[dict[str, Any]] = []
    availability: list[dict[str, Any]] = []
    coin_present: dict[str, set[str]] = {c: set() for c in ALL_COINS}

    market_open = parse_market_open(args.date, args.market_open)
    start = market_open - dt.timedelta(seconds=args.pre_seconds)
    end = market_open + dt.timedelta(seconds=args.market_seconds + args.post_seconds)
    sync_coins = [x.strip().upper() for x in args.sync_coins.split(",") if x.strip()]
    exception_coin = args.exception_coin.upper()
    unknown = [c for c in sync_coins + [exception_coin] if c not in ALL_COINS]
    if unknown:
        print(f"unknown coins: {unknown}", file=sys.stderr)
        return 2

    store.preflight()
    kcp_root = uri_join(args.bucket, args.kcp_prefix)
    sessions = [u for u in store.list(kcp_root + "/") if parse_session_date(u)]
    dated = [u for u in sessions if args.date in u]
    if not dated:
        report.error(f"no KCP sessions found for {args.date}")
        return _finish(out, args, report, inventory, availability, schemas, start, end)
    win_sess = next((u for u in dated if args.session in u), None)
    if win_sess is None:
        report.error(f"no session containing {args.session!r} on {args.date}; found {[Path(x.rstrip('/')).name for x in dated]}")
        return _finish(out, args, report, inventory, availability, schemas, start, end)
    print("selected KCP session:", win_sess)
    dates = sorted(d for d in (parse_session_date(u) for u in sessions) if d)
    inventory.append({"family": "KCP archive", "scope": "global",
                      "coverage_start": dates[0] if dates else "",
                      "coverage_end": dates[-1] if dates else "",
                      "session_count": len(sessions), "source_uri": kcp_root})

    # Root session metadata.
    for uri, size in store.list_entries(win_sess):
        inventory.append({"family": "KCP session root", "coin": "ALL",
                          "session": Path(win_sess.rstrip("/")).name,
                          "stream": Path(uri).name, "compressed_bytes": size,
                          "source_uri": uri})
        if Path(uri).name.endswith("manifest.json"):
            try:
                dest = out / "metadata" / "kcp_session_manifest.json"
                dest.write_bytes(store.read_bytes(uri))
            except Exception as exc:
                report.warn(f"could not copy KCP session manifest: {exc}")

    # Inventory and schema samples for all six coins / all distinct KCP stream types.
    seen_streams: set[str] = set()
    coin_entries: dict[str, list[tuple[str, int | None]]] = {}
    print("[1/6] inventory + KCP schemas")
    for coin in ALL_COINS:
        prefix = uri_join(win_sess, coin)
        entries = store.list_entries(prefix)
        coin_entries[coin] = entries
        present = {Path(uri).name for uri, _ in entries}
        for uri, size in entries:
            name = Path(uri).name
            coin_present[coin].add(name)
            inventory.append({"family": "KCP dense", "coin": coin,
                              "session": Path(win_sess.rstrip("/")).name,
                              "stream": name, "compressed_bytes": size,
                              "source_uri": uri,
                              "note": "no Coinbase market" if coin == "HYPE" and name.startswith("coinbase") else ""})
            if name in seen_streams or not name.endswith(WINDOWABLE_SUFFIXES):
                continue
            seen_streams.add(name)
            try:
                desc = sample_uri(store, uri, "kcp__" + name, coin,
                                  out / "schemas", size=size)
                schemas.append(desc)
                print(f"  schema {name} from {coin}")
            except Exception as exc:
                report.warn(f"schema sample failed for {uri}: {exc}")
        if coin == "HYPE" and any(x.startswith("coinbase") for x in present):
            report.warn("HYPE unexpectedly has Coinbase stream files; preserve and inspect them")

    # Explicit all-coin availability matrix, including absences such as HYPE/Coinbase.
    for coin in ALL_COINS:
        for stream_name in sorted(seen_streams):
            availability.append({"coin": coin, "stream": stream_name,
                                 "present": int(stream_name in coin_present[coin]),
                                 "selected_session": Path(win_sess.rstrip("/")).name})

    # Synchronized KCP window for two coins + HYPE exception.
    print("[2/6] bounded synchronized KCP window", iso_z(start), "to", iso_z(end))
    for coin in list(dict.fromkeys(sync_coins + [exception_coin])):
        target_root = (out / "window" / coin) if coin in sync_coins else (out / "exception" / coin)
        for uri, _size in coin_entries.get(coin, []):
            name = Path(uri).name
            if not name.endswith(WINDOWABLE_SUFFIXES):
                continue
            dest = target_root / name
            try:
                st = extract_uri_window(store, uri, dest, start, end)
                report.extractions.append(st.as_dict())
                if st.status == "NO_TIMESTAMP_COLUMN":
                    report.warn(f"no timestamp column for synchronized extraction: {uri}")
                print(f"  {coin:5s} {name:38s} {st.rows_written:8d} rows  {st.status}")
            except Exception as exc:
                report.warn(f"window extraction failed for {uri}: {exc}")

    # CF REST values and CF live WS over the exact same time range.
    print("[3/6] CF REST + live channels")
    cf_root = uri_join(args.bucket, args.cf_prefix)
    # Global CF inventory for all six coins; samples remain deliberately small.
    for coin in ALL_COINS:
        indices = [x.rstrip("/").split("/")[-1] for x in store.list(uri_join(cf_root, coin) + "/")]
        for idx in indices:
            date_dirs = [x.rstrip("/").split("/")[-1] for x in
                         store.list(uri_join(cf_root, coin, idx) + "/")]
            date_dirs = sorted(d for d in date_dirs if re.fullmatch(r"20\d{2}-\d{2}-\d{2}", d))
            inventory.append({"family": "CF REST archive", "coin": coin, "index": idx,
                              "coverage_start": date_dirs[0] if date_dirs else "",
                              "coverage_end": date_dirs[-1] if date_dirs else "",
                              "cadence_note": "approximately 5 Hz; HYPE approximately 1 Hz",
                              "source_uri": uri_join(cf_root, coin, idx)})
    for channel in ("cfbenchmarks_value", "cfbenchmarks_value_5hz", "control"):
        date_dirs = [x.rstrip("/").split("/")[-1] for x in
                     store.list(uri_join(cf_root, "_live_ws_v1", channel) + "/")]
        date_dirs = sorted(d for d in date_dirs if re.fullmatch(r"20\d{2}-\d{2}-\d{2}", d))
        inventory.append({"family": "CF live WS archive", "channel": channel,
                          "coverage_start": date_dirs[0] if date_dirs else "",
                          "coverage_end": date_dirs[-1] if date_dirs else "",
                          "source_uri": uri_join(cf_root, "_live_ws_v1", channel)})

    for coin in list(dict.fromkeys(sync_coins + [exception_coin])):
        indices = [x.rstrip("/").split("/")[-1] for x in store.list(uri_join(cf_root, coin) + "/")]
        if not indices:
            report.error(f"no CF REST index directory found for {coin}")
            continue
        for idx in indices:
            uris = [uri_join(cf_root, coin, idx, h.date().isoformat(), f"{h.hour:02d}", "values.csv.gz")
                    for h in hour_starts(start, end)]
            existing = [u for u in uris if store.exists(u)]
            if not existing:
                continue
            dest = out / "window" / "cf_rest" / f"{coin}_{idx}_{args.date}.csv.gz"
            stats = _extract_multiple_csv(store, existing, dest, start, end)
            report.extractions.append(stats.as_dict())
            inventory.append({"family": "CF REST", "coin": coin, "index": idx,
                              "stream": "values.csv.gz", "source_objects": len(existing),
                              "window_rows": stats.rows_written,
                              "source_uri": ";".join(existing)})
            print(f"  CF REST {coin:5s} {idx:18s} {stats.rows_written:7d} rows")
            # Schema from the first actual CF values file.
            sid = "cf_rest__values.csv.gz"
            if sid not in seen_streams:
                try:
                    schemas.append(sample_uri(store, existing[0], sid, coin,
                                              out / "schemas", size=store.size(existing[0])))
                    seen_streams.add(sid)
                except Exception as exc:
                    report.warn(f"CF REST schema sample failed: {exc}")

    for channel in ("cfbenchmarks_value", "cfbenchmarks_value_5hz", "control"):
        uris = [uri_join(cf_root, "_live_ws_v1", channel, h.date().isoformat(),
                         f"{h.hour:02d}", "messages.jsonl.gz") for h in hour_starts(start, end)]
        existing = [u for u in uris if store.exists(u)]
        if not existing:
            msg = f"CF live channel missing for selected window: {channel}"
            (report.error if channel == "cfbenchmarks_value" else report.warn)(msg)
            continue
        dest = out / "window" / "cf_ws" / f"{channel}_{args.date}.jsonl.gz"
        stats = _extract_multiple_jsonl(store, existing, dest, start, end)
        report.extractions.append(stats.as_dict())
        inventory.append({"family": "CF live WS", "channel": channel,
                          "source_objects": len(existing), "window_rows": stats.rows_written,
                          "source_uri": ";".join(existing)})
        print(f"  CF WS   {channel:26s} {stats.rows_written:7d} rows")
        sid = "cf_ws__" + channel + ".jsonl.gz"
        if sid not in seen_streams:
            try:
                schemas.append(sample_uri(store, existing[0], sid, "ALL",
                                          out / "schemas", size=store.size(existing[0])))
                seen_streams.add(sid)
            except Exception as exc:
                report.warn(f"CF WS schema sample failed for {channel}: {exc}")

    # HYPE before/after index transition: small row samples, not full hours.
    print("[4/6] HYPE index-transition samples")
    for idx, day in (("U_HYPEUSD_RTI", "2026-06-10"), ("HYPEUSD_RTI", "2026-06-12")):
        found = None
        for hh in range(24):
            uri = uri_join(cf_root, "HYPE", idx, day, f"{hh:02d}", "values.csv.gz")
            if store.exists(uri):
                found = uri
                break
        if found:
            desc, text = describe_csv_lines(store.iter_text(found), n=SAMPLE_ROWS)
            dest = out / "exception" / f"hype_transition_{idx}_{day}.csv"
            dest.write_text(text, encoding="utf-8")
            inventory.append({"family": "CF HYPE transition sample", "coin": "HYPE",
                              "index": idx, "stream": dest.name, "source_uri": found,
                              "sample_rows": len(desc.get("rows", []))})
        else:
            report.warn(f"HYPE transition sample not found: {idx} {day}")

    # Optional v9 session. Its full-ladder format is structurally distinct from KCP.
    print("[5/6] v9 discovery")
    if not args.no_v9:
        v9_uri = args.v9_uri or discover_v9_zip(store, args.bucket, args.date, args.session)
        if v9_uri:
            try:
                include_v9(store, v9_uri, tmp, out, schemas, start, end, report, inventory)
                print("  included", v9_uri)
            except Exception as exc:
                report.warn(f"v9 inclusion failed: {exc}")
        else:
            report.warn("no matching v9 session ZIP discovered; package remains usable with KCP L2")

    # Metadata assembled from the exact synchronized extracts, blanks preserved.
    report.metadata_rows = build_metadata_sample(
        [out / "window", out / "exception"],
        out / "metadata" / "metadata_sample.csv",
    )

    # Final docs and validation.
    print("[6/6] reports, validation, ZIP")
    report.inventory_rows = len(inventory)
    report.schema_count = len(schemas)
    _write_csv(out / "manifest.csv", inventory)
    _write_csv(out / "stream_availability.csv", availability)
    _write_csv(out / "window_extraction_report.csv", report.extractions)
    (out / "schemas_and_dtypes.md").write_text(
        "# Schemas and dtypes\n\n" +
        "Each section points to an actual contiguous sample file. Dtypes are inferred "
        "from the sample and are not a substitute for source documentation.\n\n" +
        "\n\n".join(render_schema(x) for x in schemas), encoding="utf-8")
    _validate_required(out, sync_coins, exception_coin, report)
    (out / "README.md").write_text(_readme(args, start, end, sync_coins, exception_coin, report),
                                   encoding="utf-8")
    (out / "BUILD_REPORT.json").write_bytes(canonical_json_bytes(report.__dict__))
    shutil.rmtree(tmp, ignore_errors=True)
    return _finish(out, args, report, inventory, availability, schemas, start, end)


def _extract_multiple_csv(store: Any, uris: Sequence[str], dest: Path,
                          start: dt.datetime, end: dt.datetime) -> ExtractStats:
    # CF hourly CSVs share a schema; concatenate their lines while suppressing repeated headers.
    all_lines: list[str] = []
    header: str | None = None
    for uri in uris:
        for i, line in enumerate(store.iter_text(uri)):
            if i == 0:
                if header is None:
                    header = line
                    all_lines.append(line)
                continue
            all_lines.append(line)
    return extract_csv_lines(iter(all_lines), ";".join(uris), dest, start, end)


def _extract_multiple_jsonl(store: Any, uris: Sequence[str], dest: Path,
                            start: dt.datetime, end: dt.datetime) -> ExtractStats:
    def lines() -> Iterator[str]:
        for uri in uris:
            yield from store.iter_text(uri)
    return extract_jsonl_lines(lines(), ";".join(uris), dest, start, end)


def _write_csv(path: Path, rows: Sequence[dict[str, Any]]) -> None:
    keys: list[str] = []
    for row in rows:
        for k in row:
            if k not in keys:
                keys.append(k)
    if not keys:
        keys = ["empty"]
    with path.open("w", encoding="utf-8", newline="") as fh:
        wr = csv.DictWriter(fh, fieldnames=keys, extrasaction="ignore")
        wr.writeheader()
        wr.writerows(rows)


def _validate_required(out: Path, sync_coins: Sequence[str], exception_coin: str,
                       report: BuildReport) -> None:
    if not (out / "schemas_and_dtypes.md").exists():
        report.error("schemas_and_dtypes.md missing")
    for coin in sync_coins:
        d = out / "window" / coin
        if not d.exists() or not any(d.iterdir()):
            report.error(f"no synchronized KCP window files for {coin}")
        if not any(d.glob("kalshi_snapshots.csv*")):
            report.warn(f"kalshi_snapshots absent from synchronized {coin} window")
    ed = out / "exception" / exception_coin
    if not ed.exists() or not any(ed.iterdir()):
        report.error(f"no exception sample for {exception_coin}")
    cfws = out / "window" / "cf_ws"
    if not any(cfws.glob("cfbenchmarks_value_*.jsonl.gz")):
        report.error("1 Hz CF WebSocket sample with avg_60s_data is missing")
    cfrest = out / "window" / "cf_rest"
    for coin in sync_coins:
        if not any(cfrest.glob(f"{coin}_*.csv.gz")):
            report.error(f"CF REST window missing for {coin}")
    if report.metadata_rows == 0:
        report.warn("metadata_sample.csv contains no market rows")


def _readme(args: argparse.Namespace, start: dt.datetime, end: dt.datetime,
            sync_coins: Sequence[str], exception_coin: str, report: BuildReport) -> str:
    v9 = "included" if report.v9_included else "not included/discovered"
    return f"""# Kalshi research archive — compact schema pack v2.1

Built {iso_z(dt.datetime.now(dt.timezone.utc))}.

## Exact synchronized window

- Market open used for the sample: **{iso_z(parse_market_open(args.date, args.market_open))}**
- Extracted interval: **{iso_z(start)} through {iso_z(end)}**
- Synchronized coins: **{', '.join(sync_coins)}**
- Exception coin: **{exception_coin}** (no Coinbase market)
- v9 full-ladder session: **{v9}**

The original archive is roughly 1 TB. This package contains bounded extracts,
not complete multi-hour session files. Window boundaries use receive/local
timestamps when available, because those are the causal availability clocks;
they fall back to source/exchange/event timestamps only when necessary. Every
original clock remains in the extracted records for lead-lag alignment, and
`window_extraction_report.csv` names the cut clock used for each stream.

## Contents

- `manifest.csv`: inventory, sizes, coverage, and source identities.
- `stream_availability.csv`: selected-session stream presence by coin.
- `schemas_and_dtypes.md` and `schemas/`: contiguous real samples for each distinct stream type.
- `window/`: synchronized KCP, CF REST, CF live WebSocket, and optional v9 extracts.
- `exception/{exception_coin}/`: the same-period exception-coin data.
- `exception/hype_transition_*`: small pre/post HYPE index-transition samples.
- `metadata/metadata_sample.csv`: market metadata for synchronized coins **and the exception coin**, exactly as found; blanks remain blank.
- `window_extraction_report.csv`: source, timestamp field, rows seen/written, and parsing diagnostics.
- `BUILD_REPORT.json`: warnings and errors from the build.

## Archive organization

KCP data is partitioned by UTC date, weekday, session, and coin:

```
KCP_data/YYYY-MM-DD_Dow_Session_HHMM-HHMMUTC/<COIN>/<streams>
```

Sessions are OvernightAsia, EuropeanAM, USsession, and AfterHours. Weekends are
collected. Older v9 session archives overlap by roughly five minutes at session
boundaries and require deduplication when concatenated. v9 auto-discovery uses
only bounded prefix patterns; if it does not find the session, pass the exact
`--v9-uri` rather than recursively listing the whole bucket.

## CF data

- Historical CF REST values are present separately by coin/index/hour.
- `cfbenchmarks_value` is the approximately 1 Hz channel and carries the rolling
  `avg_60s_data`, final-window fields when applicable, and latency decomposition.
- `cfbenchmarks_value_5hz` is the higher-rate channel for the five main indices;
  its rolling-average fields are not populated.
- HYPE uses a distinct cadence and changed index identity in June 2026; small
  samples from both index eras are included when available.

The modeling target is settlement against the **final-minute CF average**, not a
simple spot-price touch. The continuous `avg_60s_data` is a trailing average and
coincides with the settlement window only at the relevant close.

## Order books and candidate features

KCP contains event-driven Kalshi snapshots/deltas for all six coins. v9, when
included, contributes periodic full ladders for BTC/ETH/SOL/HYPE. DOGE and XRP
ladder payloads exist in KCP `raw_json`; careful snapshot/delta handling is
required. Raw ladders can support slope, curvature, imbalance, microprice,
depth, and cost-to-fill features. Those are candidates to define and validate,
not pre-certified findings.

## Metadata warning

`floor_strike` is blank on some source rows and this package preserves the
blank. Nothing here infers or repairs the strike. The receiver should identify
what authoritative market/series metadata is additionally required before
constructing labels.

## Request to the receiving model

After inspecting the package, please:

1. Confirm the exact field mappings and timestamp/availability clocks.
2. Tell us the **smallest additional** fields, metadata, synchronized windows,
   coins, or source files you need before writing and testing the first pipeline.
3. Identify anything in the package that is insufficient or ambiguous,
   especially the strike/price-to-beat and settlement-rule fields.
4. Recommend which inputs should remain raw time-series channels and which
   derived features should be computed.

Do not assume that prior project feature experiments were correct. Use the raw
samples to define and test the initial implementation.
"""


def _finish(out: Path, args: argparse.Namespace, report: BuildReport,
            inventory: Sequence[dict[str, Any]], availability: Sequence[dict[str, Any]],
            schemas: Sequence[dict[str, Any]], start: dt.datetime,
            end: dt.datetime) -> int:
    del inventory, availability, schemas, start, end
    if out.exists():
        total_before = sum(p.stat().st_size for p in out.rglob("*") if p.is_file())
        if total_before > args.warn_mb * 1e6:
            report.warn(f"package exceeds warning threshold: {total_before/1e6:.1f} MB > {args.warn_mb} MB")

        # The report must be final before hashes are computed.
        (out / "BUILD_REPORT.json").write_bytes(canonical_json_bytes(report.__dict__))
        sums = []
        for p in sorted(x for x in out.rglob("*") if x.is_file() and x.name != "SHA256SUMS.txt"):
            sums.append(f"{sha256_file(p)}  {p.relative_to(out)}")
        (out / "SHA256SUMS.txt").write_text("\n".join(sums) + ("\n" if sums else ""),
                                             encoding="utf-8")
        total = sum(p.stat().st_size for p in out.rglob("*") if p.is_file())
        print(f"package directory: {out} ({total / 1e6:.1f} MB)")
        if not report.errors and not args.no_zip:
            zpath = out.with_suffix(".zip")
            if zpath.exists():
                zpath.unlink()
            with zipfile.ZipFile(zpath, "w", compression=zipfile.ZIP_DEFLATED,
                                 compresslevel=6) as zf:
                for p in sorted(x for x in out.rglob("*") if x.is_file()):
                    zf.write(p, p.relative_to(out))
            print(f"zip: {zpath} ({zpath.stat().st_size/1e6:.1f} MB)")
            print("zip sha256:", sha256_file(zpath))
    if report.errors:
        print(f"BUILD INCOMPLETE: {len(report.errors)} error(s), {len(report.warnings)} warning(s)")
        return 1
    print(f"BUILD VERIFIED: {len(report.warnings)} warning(s), no blocking errors")
    return 0


# ---------------------------------------------------------------------------
# Self-test
# ---------------------------------------------------------------------------


def _gz(text: str) -> bytes:
    return gzip.compress(text.encode("utf-8"), mtime=0)


def _csv_text(header: Sequence[str], rows: Sequence[Sequence[Any]]) -> str:
    s = io.StringIO(newline="")
    w = csv.writer(s, lineterminator="\n")
    w.writerow(header)
    w.writerows(rows)
    return s.getvalue()


def _make_fake_store() -> FakeStore:
    b = "gs://test-bucket"
    sess = uri_join(b, "KCP_data", "2026-09-06_Sun_USsession_1330-2000UTC")
    objs: dict[str, bytes] = {}
    times = ["2026-09-06T13:40:00Z", "2026-09-06T13:44:00Z",
             "2026-09-06T13:45:00Z", "2026-09-06T13:52:00Z",
             "2026-09-06T14:00:00Z", "2026-09-06T14:04:00Z"]
    for coin in ALL_COINS:
        snapshots = _csv_text(
            ["recv_ts_utc", "market_ticker", "coin", "yes_bid", "yes_ask",
             "seconds_to_close", "close_time", "floor_strike", "raw_json"],
            [[t, f"KX{coin}15M-TEST", coin, "0.49", "0.51", "300",
              "2026-09-06T14:00:00Z", "" if coin == "SOL" else "100",
              json.dumps({"type": "orderbook_snapshot", "msg": {"yes_dollars_fp": [["0.49", "10"]]}})]
             for t in times])
        objs[uri_join(sess, coin, "kalshi_snapshots.csv.gz")] = _gz(snapshots)
        trades = _csv_text(["recv_ts_utc", "market_ticker", "coin", "price", "size", "side"],
                           [[t, f"KX{coin}15M-TEST", coin, "0.50", "2", "yes"] for t in times])
        objs[uri_join(sess, coin, "kalshi_trades.csv.gz")] = _gz(trades)
        life = _csv_text(["recv_ts_utc", "market_ticker", "coin", "event_subtype", "status",
                          "open_ts", "close_ts", "settlement_value", "raw_json"],
                         [[times[-2], f"KX{coin}15M-TEST", coin, "market_lifecycle_v2", "settled",
                           "1788702300", "1788703200", "1", "{}"]])
        objs[uri_join(sess, coin, "kalshi_lifecycle.csv.gz")] = _gz(life)
        pm = _csv_text(["recv_ts_utc", "source_ts", "coin", "best_bid", "best_ask", "raw_json"],
                       [[t, t, coin, "0.49", "0.51", "{}"] for t in times])
        objs[uri_join(sess, coin, "polymarket_l1_events.csv.gz")] = _gz(pm)
        rtds = _csv_text(["recv_ts_utc", "source_ts", "symbol", "coin", "value", "raw_json"],
                         [[t, t, coin.lower()+"/usd", coin, "100", "{}"] for t in times])
        objs[uri_join(sess, coin, "rtds_chainlink_prices.csv.gz")] = _gz(rtds)
        if coin != "HYPE":
            cb = _csv_text(["recv_ts_utc", "exchange_ts", "product_id", "coin", "price", "size", "side"],
                           [[t, t, coin+"-USD", coin, "100", "1", "buy"] for t in times])
            objs[uri_join(sess, coin, "coinbase_ticks.csv.gz")] = _gz(cb)
    objs[uri_join(sess, "manifest.json")] = canonical_json_bytes({"status": "COMPLETE"})

    # CF REST.
    idx = {"BTC": "BRTI", "ETH": "ETHUSD_RTI", "SOL": "SOLUSD_RTI",
           "XRP": "XRPUSD_RTI", "DOGE": "DOGEUSD_RTI", "HYPE": "HYPEUSD_RTI"}
    for coin, index in idx.items():
        for hh in (13, 14):
            rows = []
            for minute in range(60):
                t = dt.datetime(2026, 9, 6, hh, minute, tzinfo=dt.timezone.utc)
                rows.append([int(t.timestamp()*1000), iso_z(t), "100.0", "100.0", index, coin])
            text = _csv_text(["timestamp_ms", "timestamp_utc", "value_raw", "value_float64",
                              "index_ticker", "coin"], rows)
            objs[uri_join(b, "CF_RTI_V3_1", coin, index, "2026-09-06", f"{hh:02d}", "values.csv.gz")] = _gz(text)
    for index, day in (("U_HYPEUSD_RTI", "2026-06-10"), ("HYPEUSD_RTI", "2026-06-12")):
        t = dt.datetime.fromisoformat(day + "T12:00:00+00:00")
        text = _csv_text(["timestamp_ms", "timestamp_utc", "value_raw", "value_float64",
                          "index_ticker", "coin"],
                         [[int((t+dt.timedelta(seconds=i)).timestamp()*1000), iso_z(t+dt.timedelta(seconds=i)),
                           "20", "20", index, "HYPE"] for i in range(30)])
        objs[uri_join(b, "CF_RTI_V3_1", "HYPE", index, day, "12", "values.csv.gz")] = _gz(text)

    # CF WS channels.
    for channel in ("cfbenchmarks_value", "cfbenchmarks_value_5hz", "control"):
        for hh in (13, 14):
            lines = []
            for minute in range(60):
                t = dt.datetime(2026, 9, 6, hh, minute, tzinfo=dt.timezone.utc)
                rec = {"channel": channel, "source_ts_utc": iso_z(t), "index_id": "BRTI",
                       "value_raw": "100", "avg_60s_value_raw": "99.9" if channel == "cfbenchmarks_value" else None}
                lines.append(json.dumps(rec, separators=(",", ":")))
            objs[uri_join(b, "CF_RTI_V3_1", "_live_ws_v1", channel, "2026-09-06",
                          f"{hh:02d}", "messages.jsonl.gz")] = _gz("\n".join(lines)+"\n")

    # v9 ZIP with nested gzip members.
    zbuf = io.BytesIO()
    with zipfile.ZipFile(zbuf, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        raw_lines = []
        for t in times:
            raw_lines.append(json.dumps({"recv_ts_utc": t, "market_ticker": "KXBTC15M-TEST",
                                         "raw": {"orderbook_fp": {"yes_dollars": [["0.49", "10"]]}}}))
        zf.writestr("session/kalshi_raw_orderbooks.jsonl.gz", _gz("\n".join(raw_lines)+"\n"))
        zf.writestr("session/manifest.json", "{}")
        zf.writestr("session/v9_run_config.json", "{}")
    objs[uri_join(b, "2026-09-06_Sun", "2026-09-06_Sun_USsession_1330-2000UTC.zip")] = zbuf.getvalue()
    return FakeStore(objs)


def self_test() -> int:
    failures: list[str] = []

    def check(name: str, cond: bool) -> None:
        print(f"  {name:68s} {'PASS' if cond else 'FAIL'}")
        if not cond:
            failures.append(name)

    check("parse ISO timestamp", parse_time("2026-09-06T13:45:00Z") is not None)
    check("parse epoch milliseconds", parse_time(1788702300000) is not None)
    check("NaN is not a timestamp", parse_time(float("nan")) is None)

    store = _make_fake_store()
    with tempfile.TemporaryDirectory() as td:
        out = Path(td) / "pack"
        args = argparse.Namespace(
            out=str(out), date="2026-09-06", session="USsession", market_open="13:45",
            pre_seconds=60, market_seconds=900, post_seconds=120,
            sync_coins="BTC,SOL", exception_coin="HYPE", warn_mb=50,
            force=False, no_zip=False, no_v9=False, v9_uri=None,
            bucket="gs://test-bucket", kcp_prefix="KCP_data", cf_prefix="CF_RTI_V3_1",
        )
        rc = build(args, store)
        check("end-to-end fake build succeeds", rc == 0)
        check("ZIP created", out.with_suffix(".zip").exists())
        avail_rows = list(csv.DictReader((out/"stream_availability.csv").open()))
        check("all six coins in availability manifest",
              set(r["coin"] for r in avail_rows) == set(ALL_COINS))
        check("HYPE Coinbase absence is explicit",
              any(r["coin"] == "HYPE" and r["stream"] == "coinbase_ticks.csv.gz" and r["present"] == "0"
                  for r in avail_rows))
        check("1 Hz CF WS sample included", any((out/"window"/"cf_ws").glob("cfbenchmarks_value_*.jsonl.gz")))
        check("HYPE exception sample included", (out/"exception"/"HYPE"/"kalshi_snapshots.csv.gz").exists())
        check("v9 full-ladder sample included", (out/"window"/"v9"/"kalshi_raw_orderbooks.jsonl.gz").exists())
        metadata_rows = list(csv.DictReader((out/"metadata"/"metadata_sample.csv").open()))
        check("blank strike preserved in metadata",
              any(r.get("coin") == "SOL" and r.get("floor_strike") == ""
                  for r in metadata_rows))
        check("exception coin metadata included",
              any(r.get("coin") == "HYPE" for r in metadata_rows))
        # Ensure outside-window rows were not copied.
        rows = list(read_csv_any(out/"window"/"BTC"/"kalshi_snapshots.csv.gz"))
        times = [parse_time(r["recv_ts_utc"]) for r in rows]
        start = parse_time("2026-09-06T13:44:00Z")
        end = parse_time("2026-09-06T14:02:00Z")
        check("KCP output is a bounded window, not the whole session",
              bool(times) and all(start <= t <= end for t in times if t is not None) and len(rows) < 6)
        check("README asks what additional data is needed",
              "smallest additional" in (out/"README.md").read_text())
        check("SHA256SUMS created", (out/"SHA256SUMS.txt").exists())
        sums_ok = True
        for line in (out/"SHA256SUMS.txt").read_text().splitlines():
            h, rel = line.split("  ", 1)
            sums_ok &= sha256_file(out/rel) == h
        check("all published SHA256 values verify", sums_ok)
        manifest_rows = list(csv.DictReader((out/"manifest.csv").open()))
        check("CF inventory covers all six coins",
              set(r.get("coin") for r in manifest_rows if r.get("family") == "CF REST archive") == set(ALL_COINS))

        # Non-empty output must fail without --force.
        rc2 = build(args, store)
        check("non-empty output is refused without --force", rc2 == 2)

    # Receive/local availability clocks are preferred when both clocks exist.
    d = describe_csv_lines(iter([
        "recv_ts_utc,exchange_ts,value\n",
        "2026-09-06T13:45:10Z,2026-09-06T13:45:09Z,1\n",
    ]))[0]
    check("receive clock preferred for causal window cut",
          d["timestamp_field"] == "recv_ts_utc")

    # Source-clock files scan completely, so a late in-window row after many
    # beyond-window rows cannot be lost.
    with tempfile.TemporaryDirectory() as td3:
        dest = Path(td3) / "late.csv"
        lines = ["exchange_ts,value\n", "2026-09-06T13:45:00Z,1\n"]
        lines += [f"2026-09-06T14:10:{i%60:02d}Z,2\n" for i in range(80)]
        lines += ["2026-09-06T13:46:00Z,3\n"]
        st_late = extract_csv_lines(
            iter(lines), "late-disorder", dest,
            parse_time("2026-09-06T13:44:00Z"),
            parse_time("2026-09-06T14:02:00Z"),
        )
        late_rows = list(read_csv_any(dest))
        check("source-clock late row survives disordered tail",
              st_late.rows_written == 2 and any(r["value"] == "3" for r in late_rows))

    # Missing the critical 1 Hz CF channel must produce a blocking error and no ZIP.
    broken_objects = dict(store.objects)
    for k in list(broken_objects):
        if "/cfbenchmarks_value/" in k:
            del broken_objects[k]
    broken = FakeStore(broken_objects)
    with tempfile.TemporaryDirectory() as td2:
        out2 = Path(td2) / "pack"
        args2 = argparse.Namespace(
            out=str(out2), date="2026-09-06", session="USsession", market_open="13:45",
            pre_seconds=60, market_seconds=900, post_seconds=120,
            sync_coins="BTC,SOL", exception_coin="HYPE", warn_mb=50,
            force=False, no_zip=False, no_v9=True, v9_uri=None,
            bucket="gs://test-bucket", kcp_prefix="KCP_data", cf_prefix="CF_RTI_V3_1",
        )
        rc3 = build(args2, broken)
        check("missing 1 Hz CF channel fails closed", rc3 == 1)
        check("incomplete build is not zipped", not out2.with_suffix(".zip").exists())

    print("ALL PASS" if not failures else "FAILURES: " + ", ".join(failures))
    return 0 if not failures else 1


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------


def probe(args: argparse.Namespace, store: Any) -> int:
    store.preflight()
    kcp_root = uri_join(args.bucket, args.kcp_prefix)
    sessions = [u for u in store.list(kcp_root + "/") if args.date in u]
    print(f"KCP sessions on {args.date}: {len(sessions)}")
    for u in sessions:
        print(" ", u)
    for coin in ALL_COINS:
        entries = store.list_entries(uri_join(sessions[0], coin)) if sessions else []
        print(f"{coin:5s}: {len(entries):2d} files, {sum(s or 0 for _, s in entries)/1e6:8.1f} MB")
        for uri, size in entries:
            print(f"   {Path(uri).name:40s} {(size or 0)/1e6:8.1f} MB")
    v9 = discover_v9_zip(store, args.bucket, args.date, args.session)
    print("v9:", v9 or "not discovered")
    return 0


def main(argv: Sequence[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--out", default="~/grok_schema_pack_v2")
    ap.add_argument("--date", default="2026-09-06")
    ap.add_argument("--session", default="USsession")
    ap.add_argument("--market-open", default="13:45",
                    help="HH:MM UTC or ISO timestamp; default selects 13:45-14:00 market")
    ap.add_argument("--pre-seconds", type=int, default=60)
    ap.add_argument("--market-seconds", type=int, default=900)
    ap.add_argument("--post-seconds", type=int, default=120)
    ap.add_argument("--sync-coins", default="BTC,SOL")
    ap.add_argument("--exception-coin", default="HYPE")
    ap.add_argument("--warn-mb", type=int, default=100)
    ap.add_argument("--bucket", default=DEFAULT_BUCKET)
    ap.add_argument("--kcp-prefix", default="KCP_data")
    ap.add_argument("--cf-prefix", default="CF_RTI_V3_1")
    ap.add_argument("--v9-uri", default=None, help="optional exact v9 session ZIP URI")
    ap.add_argument("--no-v9", action="store_true")
    ap.add_argument("--no-zip", action="store_true")
    ap.add_argument("--force", action="store_true")
    ap.add_argument("--probe", action="store_true")
    ap.add_argument("--self-test", action="store_true")
    ap.add_argument("--allow-no-ws", action="store_true")
    args = ap.parse_args(argv)

    if args.self_test:
        return self_test()
    try:
        d = dt.date.fromisoformat(args.date)
    except ValueError:
        ap.error("--date must be YYYY-MM-DD")
    if d < WS_DATA_BEGINS and not args.allow_no_ws:
        ap.error(f"--date precedes CF WebSocket collection ({WS_DATA_BEGINS}); "
                 "choose a later date or pass --allow-no-ws deliberately")
    if args.pre_seconds < 0 or args.market_seconds <= 0 or args.post_seconds < 0:
        ap.error("window durations must be nonnegative and market-seconds > 0")
    store = GsutilStore()
    if args.probe:
        return probe(args, store)
    return build(args, store)


if __name__ == "__main__":
    raise SystemExit(main())
