# CF Reversal Counterfactual v2 — audit and v2.1 corrections

## Ruling

Do **not** run the submitted `cf_reversal_counterfactual_v2.py` unchanged.
Its embedded tests pass, but the production path contains several defects that
can change the policy answer or prevent the real run from starting.

## Answer-changing findings

1. **Wrong gate column.** The CF reachability output is
   `near_impossible_exact`; the submitted script reads `near_impossible`.
   On the real v1.1 row table this can make the skip/reversal trigger false for
   every row.

2. **Overlapping depth files are not reconciled.** The all-coin reconstruction
   and the DOGE/XRP reconstruction can contain the same opportunity. The
   submitted loader appends both tuples and sorts them. An exact-time blank row
   plus a populated row can raise `TypeError` while sorting (`None` versus
   `float`); if it does not, nearest-row selection can choose the wrong copy.

3. **One-contract mode ignores displayed capacity.** `q=1` is returned even
   when touch size is missing or zero. That fabricates executable trades.

4. **The current-side gate is not recomputed by quantity.** The submitted code
   reuses the one-contract `near_impossible` flag for q=1, half-touch, and
   full-touch, despite claiming the gate moves with the fee ceiling.

5. **The comparison universe is too broad.** `status == OK` includes rows that
   are not economically eligible. The original CF result was calculated on
   `reference_gateable == 1` and `economic_status == OK`.

6. **Reversal depends unnecessarily on the current side.** If the current side
   lacks capacity, the submitted function returns before checking whether the
   opposite side is executable.

7. **No hard duplicate or holdout guard.** Duplicate opportunity identities are
   not refused, and sealed rows are silently excluded rather than causing the
   development run to fail.

8. **The output drops most CF features.** That prevents the promised later
   WRAcc/PRIM/EBM work and omits several requested policy diagnostics.

9. **Capacity-contention reporting is wrong for reversal.** It groups by the
   original side, not the side ultimately traded by each policy. Its aggregate
   count also counts duplicated groups rather than duplicated opportunities.

10. **No baseline reconciliation.** A bad join can change the q=1 baseline
    without making the run fail.

## v2.1 corrections

- Reads `near_impossible_exact` and audits it against a recomputed q=1 gate.
- Merges overlapping depth rows field-by-field; complementary blanks are filled,
  incompatible nonblank values become `DEPTH_CONFLICT`.
- Requires touch capacity for q=1, half-touch, and full-touch.
- Recomputes current-side break-even and near-impossible status at every size.
- Evaluates each policy independently.
- Restricts policy evaluation to the exact economically eligible CF universe.
- Preserves the full reachability input row and adds all policy/action columns.
- Refuses duplicate opportunities, sealed holdout rows, and post-cutoff rows.
- Retains malformed-time rows with an explicit output status.
- Computes policy-final-side contention after actions are selected.
- Adds overall and grouped machine-readable summaries, drawdown, losing streak,
  contracts, PnL per trade/contract, time-half stability, and reversal spread/
  capacity quantiles.
- Hard-reconciles q=1 A and B exact-fee PnL to the already published CF
  reachability row table. A mismatch makes the production run exit nonzero.

## Verification performed here

- Python compilation: PASS
- Embedded self-test: ALL PASS
- Independent adversarial suite: **57 passed, 0 failed**
- Exact whole-order fee cases: **24,975**
- Synthetic end-to-end run: PASS
- Rows in = rows out: PASS
- Clean overlap merge and conflict refusal: PASS

The real Probe2 CSVs are not mounted in this environment. The final operational
gate is the production run on Probe2, especially the q=1 baseline
reconciliation printed at the end.
