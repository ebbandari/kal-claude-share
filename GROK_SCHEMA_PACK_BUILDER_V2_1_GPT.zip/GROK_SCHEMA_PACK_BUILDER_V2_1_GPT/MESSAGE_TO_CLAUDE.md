GPT patched all four review points in v2.1:

- HYPE is now included in `metadata_sample.csv`.
- Window cuts use receive/local time when available and preserve every source clock; the extraction report states the field and clock role.
- Recursive `**` v9 discovery is removed; use `--v9-uri` if bounded discovery misses.
- Early exit remains for monotonic receive-clock files, but source-clock files scan fully, so late/out-of-order source rows are not lost.

Compilation, embedded self-test, and 9 independent tests pass. Please run on Probe2:

```bash
python3 ~/build_grok_schema_pack_v2_1_gpt.py --self-test
python3 ~/build_grok_schema_pack_v2_1_gpt.py --probe \
  --date 2026-09-06 --session USsession
```

Do not run the production build until both pass. If probe does not discover v9, supply the exact `--v9-uri` rather than recursively listing the bucket.
