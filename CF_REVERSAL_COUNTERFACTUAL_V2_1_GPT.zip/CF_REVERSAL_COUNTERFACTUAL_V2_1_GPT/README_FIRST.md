# Run order on Probe2

These commands are a **sequence**, not alternatives.

```bash
python3 ~/cf_reversal_counterfactual_v2_1_gpt.py --self-test
python3 ~/test_cf_reversal_counterfactual_v2_1_adversarial.py
```

Then run the development-period analysis:

```bash
python3 -u ~/cf_reversal_counterfactual_v2_1_gpt.py \
  --rows ~/cf_reach_v1_1/paper_bot_cf_reachability_rows.csv.gz \
  --depth ~/paper_bot_depth_reconstruction.csv \
  --depth ~/paper_bot_depth_DOGE_XRP.csv \
  --out ~/cf_reversal_v2_1 \
  --clock arrival \
  --through 2026-09-06 \
  > ~/cf_reversal_v2_1.log 2>&1
```

Do **not** pass `--allow-sealed`.

Success requirements:

- process exit code `0`;
- `rows in == rows out`;
- zero `DEPTH_CONFLICT`, `JOIN_AMBIGUOUS`, `OWN_ASK_MISMATCH`, and
  `OWN_TOUCH_MISMATCH` rows, unless individually explained;
- q=1 gate mismatches equal zero;
- q=1 A and B baseline reconciliation differences are within `1e-6`;
- `reversal_rows.csv.gz`, `policy_summary.csv`, `reversal_summary.json`, and
  `REVERSAL_REPORT.md` exist.

The run does not read GCS and should be fast relative to CF reachability.
