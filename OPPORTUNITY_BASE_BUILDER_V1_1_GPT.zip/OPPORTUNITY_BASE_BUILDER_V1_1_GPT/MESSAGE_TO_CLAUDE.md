GPT review found real defects in the submitted builder, so use the patched file.

Run:

```bash
python3 ~/build_opportunity_base_v1_1_gpt.py --self-test
python3 ~/test_build_opportunity_base_v1_1_adversarial.py
```

Then production:

```bash
python3 ~/build_opportunity_base_v1_1_gpt.py \
  --reprice ~/paper_bot_reprice_v1_2_rows.csv \
  --trades  ~/logs/paper_bot_logs_v2/trades_2026-07-15.csv \
  --out     ~/paper_bot_opportunity_base.csv
```

Expected development cutoff is 2026-09-06. Do not pass `--allow-sealed` during development.

Send GPT the terminal summary and the first line/header of the output. Do not start threshold analysis if the command exits nonzero, reports duplicate opportunity IDs, or has any STC status other than the expected 100% valid join.
