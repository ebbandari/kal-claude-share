#!/usr/bin/env python3
"""
cf_reversal_counterfactual_v2_1_gpt.py

Exact, size-aware CF-conditioned reversal counterfactual.

Four policies are evaluated from the same row-level CF reachability evidence and
actual YES/NO displayed asks at the selected book clock:

    A  ORIGINAL_CONTRARIAN
    B  CF_SKIP_ONLY
    C  CF_REVERSE_ALL          diagnostic stress test, not a live policy
    D  CF_REVERSE_CONSERVATIVE prospective: reverse only when the conservative
                                opposite-side probability clears its own toll

Three fixed quantity rules are evaluated independently on the side actually
traded by each policy:

    one   q = 1, but only when at least one contract is displayed at touch
    half  q = min(25, floor(0.5 * displayed touch size))
    full  q = min(25, floor(displayed touch size))

Important corrections over the submitted v2:
  * overlapping depth files are merged field-by-field; blank DOGE/XRP rows can
    no longer shadow complete rows, and incompatible duplicates fail closed;
  * q=1 requires displayed capacity, just like larger sizes;
  * the current-side near-impossible gate is recomputed at every quantity using
    that quantity's exact whole-order fee;
  * each policy is evaluated independently, so a usable opposite side is not
    discarded merely because the current side lacks capacity;
  * every source row survives with an explicit status; sealed/after-through data
    cause a hard refusal rather than being silently excluded;
  * the output retains the full reachability feature row for later WRAcc/PRIM/
    EBM work and emits machine-readable policy summaries.

USAGE
    python3 cf_reversal_counterfactual_v2_1_gpt.py --self-test
    python3 cf_reversal_counterfactual_v2_1_gpt.py \
      --rows ~/cf_reach_v1_1/paper_bot_cf_reachability_rows.csv.gz \
      --depth ~/paper_bot_depth_reconstruction.csv \
      --depth ~/paper_bot_depth_DOGE_XRP.csv \
      --out ~/cf_reversal_v2_1
"""
from __future__ import annotations

import argparse
import bisect
import collections
import csv
import datetime as dt
import gzip
import json
import math
import os
import sys
from pathlib import Path

DEVELOPMENT_THROUGH = dt.date(2026, 9, 6)
SEALED_FROM = dt.date(2026, 9, 7)
SEALED_TO = dt.date(2026, 9, 13)
JOIN_TOL_S = 0.001
SIZE_CAP = 25
SIZE_MODES = ("one", "half", "full")
POLICIES = (
    "A_ORIGINAL_CONTRARIAN",
    "B_CF_SKIP_ONLY",
    "C_CF_REVERSE_ALL",
    "D_CF_REVERSE_CONSERVATIVE",
)
TRADE_ACTIONS = {"TAKE", "REVERSE"}


# =============================================================================
# S1. PRIMITIVES
# =============================================================================
def num(v):
    if v in (None, ""):
        return None
    try:
        x = float(v)
    except (TypeError, ValueError):
        return None
    return x if math.isfinite(x) else None


def parse_ts(v):
    if v in (None, ""):
        return None
    try:
        x = float(v)
        if not math.isfinite(x):
            return None
        if x > 1e18:
            x /= 1e9
        elif x > 1e15:
            x /= 1e6
        elif x > 1e11:
            x /= 1e3
        # datetime conversion below is also a range check.
        dt.datetime.fromtimestamp(x, dt.timezone.utc)
        return x
    except (TypeError, ValueError, OverflowError, OSError):
        pass
    try:
        d = dt.datetime.fromisoformat(str(v).strip().replace("Z", "+00:00"))
        if d.tzinfo is None:
            d = d.replace(tzinfo=dt.timezone.utc)
        return d.timestamp()
    except Exception:  # noqa: BLE001
        return None


def utc_date(ts):
    return dt.datetime.fromtimestamp(ts, dt.timezone.utc).date()


def flag01(v):
    x = num(v)
    if x is not None and x in (0.0, 1.0):
        return int(x)
    s = str(v or "").strip().lower()
    if s in {"true", "yes", "y"}:
        return 1
    if s in {"false", "no", "n"}:
        return 0
    return None


def valid_price(x):
    return x is not None and 0.0 < x < 1.0


def valid_probability(x):
    return x is not None and 0.0 <= x <= 1.0


def exact_order_fee(price, q):
    if not valid_price(price) or q is None or q <= 0:
        raise ValueError("invalid fee inputs")
    return math.ceil(0.07 * q * price * (1.0 - price) * 100.0 - 1e-9) / 100.0


def scalable_fee(price, q):
    if not valid_price(price) or q is None or q <= 0:
        raise ValueError("invalid fee inputs")
    return 0.07 * q * price * (1.0 - price)


def break_even(price, q):
    return price + exact_order_fee(price, q) / q


def pnl_exact(win, price, q):
    return (win - price) * q - exact_order_fee(price, q)


def pnl_scalable(win, price, q):
    return (win - price) * q - scalable_fee(price, q)


def opposite(side):
    return {"YES": "NO", "NO": "YES"}.get(side)


def open_any(path):
    p = str(path)
    if p.endswith(".gz"):
        return gzip.open(p, "rt", newline="", encoding="utf-8", errors="replace")
    return open(p, newline="", encoding="utf-8", errors="replace")


def quantity_for_touch(touch, mode):
    """Integer contracts. Every mode requires displayed touch capacity >= 1."""
    if touch is None or not math.isfinite(touch) or touch < 1:
        return None
    if mode == "one":
        return 1
    if mode == "half":
        q = math.floor(0.5 * touch)
    elif mode == "full":
        q = math.floor(touch)
    else:
        raise ValueError(f"unknown size mode {mode}")
    return min(SIZE_CAP, int(q)) if q >= 1 else None


def quantiles(values, probs=(0.1, 0.5, 0.9)):
    a = sorted(x for x in values if x is not None and math.isfinite(x))
    if not a:
        return {f"p{int(p*100):02d}": None for p in probs}
    out = {}
    for p in probs:
        if len(a) == 1:
            v = a[0]
        else:
            pos = p * (len(a) - 1)
            lo, hi = int(math.floor(pos)), int(math.ceil(pos))
            v = a[lo] if lo == hi else a[lo] + (a[hi] - a[lo]) * (pos - lo)
        out[f"p{int(p*100):02d}"] = v
    return out


def stc_band(v):
    x = num(v)
    if x is None:
        return "MISSING"
    edges = (120, 240, 360, 480, 600, 720, 870)
    lo = 0
    for hi in edges:
        if x <= hi:
            return f"{lo:03d}-{hi:03d}"
        lo = hi
    return ">870"


def price_band(v):
    x = num(v)
    if not valid_price(x):
        return "MISSING"
    lo = math.floor(x * 10) / 10
    hi = min(1.0, lo + 0.1)
    return f"{lo:.1f}-{hi:.1f}"


# =============================================================================
# S2. DEPTH LOAD AND JOIN
# =============================================================================
DEPTH_NUMERIC_FIELDS = ("yes_ask", "no_ask", "yes_size", "no_size", "book_age_s")


def _unique_numeric(vals, tol):
    uniq = []
    for x in vals:
        if x is None:
            continue
        if not any(abs(x - y) <= tol for y in uniq):
            uniq.append(x)
    return uniq


def _merge_depth_group(rows, stats):
    """Merge exact-key overlaps. Blank+value is complementary; value conflicts fail."""
    merged = {"t": rows[0]["t"], "sources": sorted({r["source"] for r in rows})}
    conflicts = []
    for field in DEPTH_NUMERIC_FIELDS:
        tol = 1e-9 if "ask" in field else 1e-6
        vals = _unique_numeric([r.get(field) for r in rows], tol)
        if len(vals) > 1:
            conflicts.append(field)
            merged[field] = None
        else:
            merged[field] = vals[0] if vals else None
    merged["conflict_fields"] = conflicts
    if len(rows) > 1:
        stats["depth_overlap_groups"] += 1
        stats["depth_overlap_rows_merged"] += len(rows) - 1
    if conflicts:
        stats["depth_conflict_groups"] += 1
    return merged


def load_depth(paths, clock, stats, log):
    """Return (ticker, original side) -> sorted merged depth records."""
    grouped = collections.defaultdict(list)
    missing = []
    for path in paths:
        p = os.path.expanduser(path)
        if not os.path.isfile(p):
            missing.append(p)
            continue
        stats["depth_files_read"] += 1
        with open_any(p) as fh:
            for r in csv.DictReader(fh):
                stats["depth_rows"] += 1
                t = parse_ts(r.get("t_entry") or r.get("t"))
                ticker = (r.get("ticker") or "").strip()
                side = (r.get("opp") or r.get("purchased_side") or "").upper()
                if t is None:
                    stats["depth_rows_no_time"] += 1
                    continue
                if not ticker or side not in {"YES", "NO"}:
                    stats["depth_rows_bad_identity"] += 1
                    continue
                rec = {
                    "t": t,
                    "yes_ask": num(r.get(f"{clock}_yes_ask")),
                    "no_ask": num(r.get(f"{clock}_no_ask")),
                    "yes_size": num(r.get(f"{clock}_yes_ask_size")),
                    "no_size": num(r.get(f"{clock}_no_ask_size")),
                    "book_age_s": num(r.get(f"{clock}_book_age_s")),
                    "source": p,
                }
                grouped[(ticker, side, round(t, 6))].append(rec)
    if missing:
        raise FileNotFoundError("required depth file(s) missing: " + ", ".join(missing))
    if not stats["depth_files_read"]:
        raise RuntimeError("no depth files read")

    idx = collections.defaultdict(list)
    for (ticker, side, _), rows in grouped.items():
        idx[(ticker, side)].append(_merge_depth_group(rows, stats))
    for key in idx:
        idx[key].sort(key=lambda r: r["t"])
    log(f"  depth overlap groups     {stats['depth_overlap_groups']:,}")
    log(f"  depth conflicts          {stats['depth_conflict_groups']:,}")
    return idx


def lookup_depth(idx, ticker, side, t):
    cands = idx.get((ticker, side))
    if not cands:
        return None, "NO_DEPTH_ROW"
    times = [r["t"] for r in cands]
    pos = bisect.bisect_left(times, t)
    near = []
    for j in range(max(0, pos - 2), min(len(cands), pos + 3)):
        if abs(cands[j]["t"] - t) <= JOIN_TOL_S:
            near.append(cands[j])
    if not near:
        j = min(range(len(cands)), key=lambda k: abs(cands[k]["t"] - t))
        return cands[j], "JOIN_TIME_MISMATCH"
    if len(near) > 1:
        return None, "JOIN_AMBIGUOUS"
    rec = near[0]
    if rec["conflict_fields"]:
        return rec, "DEPTH_CONFLICT"
    return rec, "OK"


# =============================================================================
# S3. POLICY EVALUATION
# =============================================================================
def _trade_result(side, win, price, q, action, status="OK"):
    if side not in {"YES", "NO"} or win not in (0, 1) or not valid_price(price) or not q:
        raise ValueError("invalid trade result")
    return {
        "exact": pnl_exact(win, price, q),
        "scalable": pnl_scalable(win, price, q),
        "q": int(q),
        "action": action,
        "final_side": side,
        "price": price,
        "realized_win": int(win),
        "status": status,
    }


def _skip_result(status="SKIP"):
    return {
        "exact": 0.0,
        "scalable": 0.0,
        "q": 0,
        "action": "SKIP",
        "final_side": "",
        "price": None,
        "realized_win": None,
        "status": status,
    }


def _extract_probability_interval(r):
    lo = num(r.get("p_win_ci_lo_conservative"))
    hi = num(r.get("p_win_ci_hi_conservative"))
    if not (valid_probability(lo) and valid_probability(hi) and lo <= hi):
        return None, None, "INVALID_OR_MISSING_PROBABILITY_INTERVAL"
    return lo, hi, "OK"


def evaluate_row(r, dep, mode, stats, use_row_current=True):
    """Evaluate all four policies independently for one opportunity and size mode.

    For the primary arrival-clock run, the reachability row already carries the
    vetted current-side `reconstructed_ask` and `capacity_at_touch`. They are
    used only as a fallback when the merged depth row is blank, and any
    disagreement when both are present fails closed.
    """
    side = (r.get("side") or r.get("opp") or "").upper()
    opp_side = opposite(side)
    if opp_side is None:
        return None, "UNKNOWN_SIDE"
    win_f = num(r.get("win"))
    if win_f not in (0.0, 1.0):
        return None, "INVALID_WIN"
    win = int(win_f)

    yes_ask, no_ask = dep.get("yes_ask"), dep.get("no_ask")
    yes_size, no_size = dep.get("yes_size"), dep.get("no_size")
    own_ask = yes_ask if side == "YES" else no_ask
    own_touch = yes_size if side == "YES" else no_size
    opp_ask = no_ask if side == "YES" else yes_ask
    opp_touch = no_size if side == "YES" else yes_size

    if use_row_current:
        row_ask = num(r.get("reconstructed_ask"))
        row_touch = num(r.get("capacity_at_touch"))
        if valid_price(own_ask) and valid_price(row_ask) and abs(own_ask - row_ask) > 1e-9:
            return None, "OWN_ASK_MISMATCH"
        if own_touch is not None and row_touch is not None and abs(own_touch - row_touch) > 1e-6:
            return None, "OWN_TOUCH_MISMATCH"
        if not valid_price(own_ask) and valid_price(row_ask):
            own_ask = row_ask
            stats["own_ask_fallback_from_reachability"] += 1
        if own_touch is None and row_touch is not None:
            own_touch = row_touch
            stats["own_touch_fallback_from_reachability"] += 1
    own_q = quantity_for_touch(own_touch, mode)
    opp_q = quantity_for_touch(opp_touch, mode)
    own_exec = valid_price(own_ask) and own_q is not None
    opp_exec = valid_price(opp_ask) and opp_q is not None

    p_lo, p_hi, p_status = _extract_probability_interval(r)
    own_be = break_even(own_ask, own_q) if own_exec else None
    opp_be = break_even(opp_ask, opp_q) if opp_exec else None
    current_near = None if p_hi is None or own_be is None else int(p_hi < own_be)
    opp_lo = None if p_hi is None else 1.0 - p_hi
    opp_hi = None if p_lo is None else 1.0 - p_lo
    opp_edge = None if opp_lo is None or opp_be is None else opp_lo - opp_be
    input_near = flag01(r.get("near_impossible_exact"))
    if input_near is None:  # backwards-compatible audit only
        input_near = flag01(r.get("near_impossible"))

    own_result = (_trade_result(side, win, own_ask, own_q, "TAKE")
                  if own_exec else _skip_result("OWN_SIDE_UNEXECUTABLE"))
    opp_result = (_trade_result(opp_side, 1 - win, opp_ask, opp_q, "REVERSE")
                  if opp_exec else _skip_result("OPPOSITE_SIDE_UNEXECUTABLE"))

    out = {"A_ORIGINAL_CONTRARIAN": own_result}

    if current_near is None:
        # Gate-dependent policies fail closed. A remains an execution baseline.
        gate_skip = _skip_result(p_status if p_hi is None else "CURRENT_GATE_UNAVAILABLE")
        out["B_CF_SKIP_ONLY"] = gate_skip
        out["C_CF_REVERSE_ALL"] = gate_skip.copy()
        out["D_CF_REVERSE_CONSERVATIVE"] = gate_skip.copy()
        stats[f"gate_unavailable_{mode}"] += 1
    elif current_near:
        out["B_CF_SKIP_ONLY"] = _skip_result("CF_NEAR_IMPOSSIBLE")
        out["C_CF_REVERSE_ALL"] = opp_result
        if opp_exec and opp_lo is not None and opp_lo > opp_be:
            out["D_CF_REVERSE_CONSERVATIVE"] = opp_result.copy()
            out["D_CF_REVERSE_CONSERVATIVE"]["status"] = "OPPOSITE_LOWER_BOUND_CLEARS_BE"
            stats[f"D_reversed_{mode}"] += 1
        else:
            why = ("OPPOSITE_SIDE_UNEXECUTABLE" if not opp_exec
                   else "OPPOSITE_LOWER_BOUND_DOES_NOT_CLEAR_BE")
            out["D_CF_REVERSE_CONSERVATIVE"] = _skip_result(why)
            stats[f"D_declined_{mode}"] += 1
    else:
        out["B_CF_SKIP_ONLY"] = own_result.copy()
        out["C_CF_REVERSE_ALL"] = own_result.copy()
        out["D_CF_REVERSE_CONSERVATIVE"] = own_result.copy()

    meta = {
        "own_ask": own_ask,
        "own_touch": own_touch,
        "own_q": own_q,
        "own_break_even": own_be,
        "opposite_ask": opp_ask,
        "opposite_touch": opp_touch,
        "opposite_q": opp_q,
        "opposite_break_even": opp_be,
        "p_current_lo": p_lo,
        "p_current_hi": p_hi,
        "p_opposite_lo": opp_lo,
        "p_opposite_hi": opp_hi,
        "opposite_conservative_edge": opp_edge,
        "current_near_impossible_recomputed": current_near,
        "near_impossible_input_q1": input_near,
        "q1_gate_matches_input": (None if mode != "one" or current_near is None or input_near is None
                                  else int(current_near == input_near)),
        "spread": (yes_ask + no_ask - 1.0
                   if valid_price(yes_ask) and valid_price(no_ask) else None),
        "book_age_s": dep.get("book_age_s"),
        "depth_sources": "|".join(dep.get("sources", [])),
    }
    out["_meta"] = meta
    return out, "OK"


# =============================================================================
# S4. ACCUMULATION AND SUMMARIES
# =============================================================================
class Accum:
    def __init__(self):
        self.rows = 0
        self.traded = 0
        self.skipped = 0
        self.exact = 0.0
        self.scalable = 0.0
        self.contracts = 0
        self.wins = 0
        self.losses = 0
        self.markets = set()
        self.bursts = set()
        self.days = set()
        self.curve = []  # (t, exact, traded, realized_win)

    def add(self, t, result, market, burst, day):
        self.rows += 1
        self.exact += result["exact"]
        self.scalable += result["scalable"]
        traded = result["action"] in TRADE_ACTIONS
        if traded:
            self.traded += 1
            self.contracts += int(result["q"])
            self.wins += int(result["realized_win"] == 1)
            self.losses += int(result["realized_win"] == 0)
            self.markets.add(market)
            if burst:
                self.bursts.add(burst)
            self.days.add(day)
        else:
            self.skipped += 1
        self.curve.append((t, result["exact"], traded, result["realized_win"]))

    def drawdown(self):
        eq = peak = worst = 0.0
        for _, pnl, _, _ in sorted(self.curve):
            eq += pnl
            peak = max(peak, eq)
            worst = min(worst, eq - peak)
        return worst

    def max_losing_streak(self):
        cur = worst = 0
        for _, pnl, traded, _ in sorted(self.curve):
            if not traded:
                continue
            if pnl < 0:
                cur += 1
                worst = max(worst, cur)
            else:
                cur = 0
        return worst

    def time_halves(self, midpoint):
        a = sum(p for t, p, _, _ in self.curve if t < midpoint)
        b = sum(p for t, p, _, _ in self.curve if t >= midpoint)
        return a, b

    def as_dict(self, midpoint):
        h1, h2 = self.time_halves(midpoint)
        return {
            "rows": self.rows,
            "traded": self.traded,
            "skipped": self.skipped,
            "contracts": self.contracts,
            "wins": self.wins,
            "losses": self.losses,
            "win_rate": self.wins / self.traded if self.traded else None,
            "exact_pnl": self.exact,
            "scalable_pnl": self.scalable,
            "exact_per_trade": self.exact / self.traded if self.traded else None,
            "exact_per_contract": self.exact / self.contracts if self.contracts else None,
            "max_drawdown": self.drawdown(),
            "max_losing_streak": self.max_losing_streak(),
            "distinct_markets": len(self.markets),
            "distinct_bursts": len(self.bursts),
            "distinct_days": len(self.days),
            "first_time_half_pnl": h1,
            "second_time_half_pnl": h2,
        }


def _group_values(row, result, meta):
    session = row.get("session") or row.get("decision_session") or "MISSING"
    dow = row.get("dow") or row.get("decision_dow_utc") or "MISSING"
    return (
        ("ALL", "ALL"),
        ("coin", row.get("coin") or row.get("sib") or "MISSING"),
        ("original_side", row.get("side") or row.get("opp") or "MISSING"),
        ("final_side", result.get("final_side") or "SKIP"),
        ("session", session),
        ("weekday", dow),
        ("stc_band", stc_band(row.get("stc"))),
        ("entry_price_band", price_band(result.get("price"))),
    )


def write_csv(path, rows):
    rows = list(rows)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    keys = []
    for row in rows:
        for key in row:
            if key not in keys:
                keys.append(key)
    opener = gzip.open if str(path).endswith(".gz") else open
    kwargs = {"newline": "", "encoding": "utf-8"}
    with opener(path, "wt" if str(path).endswith(".gz") else "w", **kwargs) as fh:
        w = csv.DictWriter(fh, fieldnames=keys, extrasaction="ignore")
        w.writeheader()
        w.writerows(rows)


# =============================================================================
# S5. DRIVER
# =============================================================================
def load_source_rows(path, through, allow_sealed):
    rows = []
    bad_time = []
    sealed = []
    after = []
    seen = {}
    duplicates = []
    with open_any(path) as fh:
        for line_no, row in enumerate(csv.DictReader(fh), start=2):
            t = parse_ts(row.get("t_entry"))
            if t is None:
                bad_time.append((line_no, row))
                continue
            d = utc_date(t)
            if SEALED_FROM <= d <= SEALED_TO and not allow_sealed:
                sealed.append((line_no, row))
            if d > through:
                after.append((line_no, row))
            side = (row.get("side") or row.get("opp") or "").upper()
            key = (row.get("ticker", ""), side, round(t, 6))
            if key in seen:
                duplicates.append((seen[key], line_no, key))
            else:
                seen[key] = line_no
            rows.append((t, line_no, row))
    if sealed:
        raise RuntimeError(f"sealed holdout rows present ({len(sealed)}); refusing")
    if after:
        raise RuntimeError(f"rows after development cutoff {through} present ({len(after)}); refusing")
    if duplicates:
        raise RuntimeError(f"duplicate opportunity identities present ({len(duplicates)}); refusing")
    return rows, bad_time


def run(args, log):
    through = dt.date.fromisoformat(args.through)
    stats = collections.Counter()
    depth = load_depth(args.depth, args.clock, stats, log)
    log(f"  depth files read         {stats['depth_files_read']}")
    log(f"  depth rows read          {stats['depth_rows']:,}")
    log(f"  merged depth identities  {sum(len(v) for v in depth.values()):,}")

    src, bad_time = load_source_rows(os.path.expanduser(args.rows), through, args.allow_sealed)
    stats["rows_in"] = len(src) + len(bad_time)
    src.sort(key=lambda x: (x[0], x[1]))
    valid_times = [t for t, _, _ in src]
    midpoint = ((min(valid_times) + max(valid_times)) / 2.0) if valid_times else 0.0
    log(f"  rows in                  {stats['rows_in']:,}")
    log(f"  rows with invalid time   {len(bad_time):,}")

    # Original-side sharing is descriptive; policy-final-side contention is
    # calculated after every action has been selected.
    original_share = collections.Counter(
        (r.get("ticker", ""), (r.get("side") or r.get("opp") or "").upper())
        for _, _, r in src
    )

    detail = []
    action_refs = []
    group_acc = collections.defaultdict(Accum)
    reverse_spreads = collections.defaultdict(list)
    reverse_capacities = collections.defaultdict(list)
    reverse_counts = collections.Counter()
    expected_q1_a_exact = 0.0
    expected_q1_b_exact = 0.0
    expected_q1_rows = 0
    every = max(1, len(src) // 100)

    # Invalid-time rows survive explicitly.
    for line_no, row in bad_time:
        rec = dict(row)
        rec.update(source_line=line_no, reach_status_original=row.get("status", ""),
                   reversal_status="NO_DECISION_TIME")
        detail.append(rec)
        stats["row_NO_DECISION_TIME"] += 1

    for i, (t, line_no, row) in enumerate(src, 1):
        rec = dict(row)  # retain all reachability features for later discovery
        side = (row.get("side") or row.get("opp") or "").upper()
        ticker = row.get("ticker", "")
        coin = row.get("coin") or row.get("sib") or "?"
        burst = row.get("burst_id", "")
        day = utc_date(t).isoformat()
        rec.update(
            source_line=line_no,
            reach_status_original=row.get("status", ""),
            original_side=side,
            n_same_market_original_side=original_share[(ticker, side)],
        )

        if row.get("status") != "OK":
            rec["reversal_status"] = "REACH_" + str(row.get("status") or "BLANK")
            stats["row_" + rec["reversal_status"]] += 1
            detail.append(rec)
            continue
        if row.get("economic_status") != "OK" or flag01(row.get("reference_gateable")) != 1:
            rec["reversal_status"] = "REACH_ECONOMIC_" + str(row.get("economic_status") or "NOT_OK")
            stats["row_" + rec["reversal_status"]] += 1
            detail.append(rec)
            continue

        input_pnl = num(row.get("pnl_ask_exact"))
        input_gate = flag01(row.get("near_impossible_exact"))
        if input_pnl is None:
            stats["economic_rows_missing_pnl_ask_exact"] += 1
        if input_gate is None:
            stats["economic_rows_missing_near_impossible_exact"] += 1
        if input_pnl is not None and input_gate is not None:
            expected_q1_a_exact += input_pnl
            if input_gate == 0:
                expected_q1_b_exact += input_pnl
            expected_q1_rows += 1

        dep, join_status = lookup_depth(depth, ticker, side, t)
        if join_status != "OK":
            rec["reversal_status"] = join_status
            stats["row_" + join_status] += 1
            detail.append(rec)
            continue

        any_evaluable = False
        for mode in SIZE_MODES:
            evaluated, reason = evaluate_row(
                row, dep, mode, stats, use_row_current=(args.clock == "arrival"))
            rec[f"{mode}_status"] = reason
            if evaluated is None:
                continue
            any_evaluable = True
            meta = evaluated["_meta"]
            for key, value in meta.items():
                rec[f"{mode}_{key}"] = "" if value is None else value
            if mode == "one" and meta["q1_gate_matches_input"] == 0:
                stats["q1_gate_mismatch_vs_reachability"] += 1

            for policy in POLICIES:
                result = evaluated[policy]
                prefix = f"{mode}_{policy}"
                for key in ("exact", "scalable", "q", "action", "final_side",
                            "price", "realized_win", "status"):
                    value = result[key]
                    rec[f"{prefix}_{key}"] = "" if value is None else value
                for group_type, group_value in _group_values(row, result, meta):
                    group_acc[(mode, policy, group_type, str(group_value))].add(
                        t, result, ticker, burst, day)
                if result["action"] in TRADE_ACTIONS:
                    action_refs.append((rec, mode, policy, ticker, result["final_side"]))
                if result["action"] == "REVERSE":
                    reverse_counts[(mode, policy)] += 1
                    if meta["spread"] is not None:
                        reverse_spreads[(mode, policy)].append(meta["spread"])
                    if meta["opposite_touch"] is not None:
                        reverse_capacities[(mode, policy)].append(meta["opposite_touch"])

        rec["reversal_status"] = "OK" if any_evaluable else "UNUSABLE_ALL_SIZES"
        stats["row_" + rec["reversal_status"]] += 1
        detail.append(rec)
        if i % every == 0 or i == len(src):
            log(f"  [{i}/{len(src)}] {100*i/len(src):5.1f}%")

    # Policy-specific contention: multiple trades targeting the same final side.
    final_counts = collections.Counter((mode, policy, ticker, final_side)
                                       for _, mode, policy, ticker, final_side in action_refs)
    for rec, mode, policy, ticker, final_side in action_refs:
        rec[f"{mode}_{policy}_n_same_market_final_side"] = final_counts[
            (mode, policy, ticker, final_side)]

    out = Path(os.path.expanduser(args.out))
    out.mkdir(parents=True, exist_ok=True)
    write_csv(out / "reversal_rows.csv.gz", detail)

    summary_rows = []
    for (mode, policy, group_type, group_value), acc in sorted(group_acc.items()):
        row = {"size_mode": mode, "policy": policy, "group_type": group_type,
               "group_value": group_value}
        row.update(acc.as_dict(midpoint))
        summary_rows.append(row)
    write_csv(out / "policy_summary.csv", summary_rows)

    overall = [r for r in summary_rows if r["group_type"] == "ALL"]
    overall_map = {(r["size_mode"], r["policy"]): r for r in overall}
    a_q1 = overall_map.get(("one", "A_ORIGINAL_CONTRARIAN"), {}).get("exact_pnl")
    b_q1 = overall_map.get(("one", "B_CF_SKIP_ONLY"), {}).get("exact_pnl")
    baseline_reconciliation = {
        "input_economic_rows_with_pnl": expected_q1_rows,
        "expected_A_q1_exact_from_reachability": expected_q1_a_exact,
        "computed_A_q1_exact": a_q1,
        "A_q1_difference": (None if a_q1 is None else a_q1 - expected_q1_a_exact),
        "expected_B_q1_exact_from_reachability": expected_q1_b_exact,
        "computed_B_q1_exact": b_q1,
        "B_q1_difference": (None if b_q1 is None else b_q1 - expected_q1_b_exact),
    }
    diagnostics = {}
    for mode in SIZE_MODES:
        for policy in POLICIES:
            k = (mode, policy)
            diagnostics[f"{mode}|{policy}"] = {
                "reversal_spread": quantiles(reverse_spreads[k]),
                "reversal_touch_capacity": quantiles(reverse_capacities[k]),
                "reversal_count": reverse_counts[k],
            }
    summary_json = {
        "version": "2.1-gpt",
        "clock": args.clock,
        "through": args.through,
        "rows_in": stats["rows_in"],
        "rows_out": len(detail),
        "reconciles": len(detail) == stats["rows_in"],
        "stats": dict(stats),
        "overall": overall,
        "baseline_reconciliation": baseline_reconciliation,
        "diagnostics": diagnostics,
    }
    (out / "reversal_summary.json").write_text(
        json.dumps(summary_json, indent=2, sort_keys=True), encoding="utf-8")

    log()
    log("=" * 96)
    log("CF-CONDITIONED REVERSAL v2.1: four policies x three sizes")
    log("=" * 96)
    log(f"  clock                    {args.clock}")
    log(f"  development through      {args.through}")
    log(f"  rows in                  {stats['rows_in']:,}")
    log(f"  rows out                 {len(detail):,}")
    log(f"  reconciles               {'YES' if len(detail) == stats['rows_in'] else 'NO'}")
    log(f"  q=1 gate mismatches      {stats['q1_gate_mismatch_vs_reachability']:,}")
    for key in sorted(k for k in stats if k.startswith("row_")):
        log(f"    {key[4:]:38s} {stats[key]:8,}")

    log()
    log("  OVERALL RESULTS")
    log("  %-6s %-28s %8s %10s %12s %12s %11s %11s %10s" %
        ("size", "policy", "traded", "contracts", "exact", "scalable",
         "exact/trd", "exact/ctr", "drawdown"))
    for row in overall:
        log("  %-6s %-28s %8d %10d %+12.2f %+12.2f %+11.5f %+11.5f %+10.2f" % (
            row["size_mode"], row["policy"], row["traded"], row["contracts"],
            row["exact_pnl"], row["scalable_pnl"], row["exact_per_trade"] or 0.0,
            row["exact_per_contract"] or 0.0, row["max_drawdown"]))

    log()
    log("  Q=1 BASELINE RECONCILIATION AGAINST CF REACHABILITY ROWS")
    log(f"    A expected {expected_q1_a_exact:+.6f}  computed {a_q1 if a_q1 is not None else float('nan'):+.6f}  "
        f"difference {baseline_reconciliation['A_q1_difference'] if baseline_reconciliation['A_q1_difference'] is not None else float('nan'):+.9f}")
    log(f"    B expected {expected_q1_b_exact:+.6f}  computed {b_q1 if b_q1 is not None else float('nan'):+.6f}  "
        f"difference {baseline_reconciliation['B_q1_difference'] if baseline_reconciliation['B_q1_difference'] is not None else float('nan'):+.9f}")

    log()
    log("  Notes:")
    log("  * C is a full-reversal diagnostic stress test, not a performance ceiling.")
    log("  * Half-touch is the primary sizing sensitivity; full-touch is optimistic.")
    log("  * Actual policy-final-side contention is stored per row.")
    log(f"  wrote {out}/reversal_rows.csv.gz")
    log(f"        {out}/policy_summary.csv")
    log(f"        {out}/reversal_summary.json")
    recon_ok = len(detail) == stats["rows_in"]
    if stats["economic_rows_missing_pnl_ask_exact"] or stats["economic_rows_missing_near_impossible_exact"]:
        recon_ok = False
    if expected_q1_rows:
        recon_ok = recon_ok and a_q1 is not None and b_q1 is not None
        recon_ok = recon_ok and abs(a_q1 - expected_q1_a_exact) <= 1e-6
        recon_ok = recon_ok and abs(b_q1 - expected_q1_b_exact) <= 1e-6
    return 0 if recon_ok else 1


# =============================================================================
# S6. EMBEDDED TESTS
# =============================================================================
def self_test():
    failures = []

    def check(name, condition):
        print(f"  {name:72s} {'PASS' if condition else 'FAIL'}")
        if not condition:
            failures.append(name)

    # Fees and sizing.
    check("q=1 exact fee ceilings to two cents at 50c", exact_order_fee(0.5, 1) == 0.02)
    check("one-contract mode requires displayed capacity", quantity_for_touch(None, "one") is None)
    check("one-contract mode accepts one displayed contract", quantity_for_touch(1, "one") == 1)
    check("half touch floors", quantity_for_touch(9, "half") == 4)
    check("half touch does not invent a contract from touch=1", quantity_for_touch(1, "half") is None)
    check("full touch caps at 25", quantity_for_touch(1000, "full") == 25)

    # Policy logic and quantity-specific gate.
    dep = {"t": 0.0, "yes_ask": 0.49, "no_ask": 0.52,
           "yes_size": 100.0, "no_size": 100.0, "book_age_s": 0.1,
           "sources": ["x"], "conflict_fields": []}
    row = {"side": "YES", "win": "1", "near_impossible": "1",
           "p_win_ci_lo_conservative": "0.45",
           "p_win_ci_hi_conservative": "0.508"}
    one, _ = evaluate_row(row, dep, "one", collections.Counter())
    full, _ = evaluate_row(row, dep, "full", collections.Counter())
    check("current gate is near-impossible at q=1",
          one["_meta"]["current_near_impossible_recomputed"] == 1)
    check("current gate is recomputed and clears at q=25",
          full["_meta"]["current_near_impossible_recomputed"] == 0)
    check("skip-only changes from SKIP to TAKE as fee ceiling amortises",
          one["B_CF_SKIP_ONLY"]["action"] == "SKIP" and
          full["B_CF_SKIP_ONLY"]["action"] == "TAKE")

    # Reversal can be evaluated independently of current-side capacity.
    dep2 = dict(dep, yes_ask=None, yes_size=None, no_ask=0.52, no_size=10.0)
    row2 = {"side": "YES", "win": "0", "near_impossible_exact": "1",
            "reconstructed_ask": "0.20", "capacity_at_touch": "10",
            "p_win_ci_lo_conservative": "0.05",
            "p_win_ci_hi_conservative": "0.10"}
    ev2, _ = evaluate_row(row2, dep2, "full", collections.Counter())
    check("reverse-all can use opposite side when current side is unavailable",
          ev2["C_CF_REVERSE_ALL"]["action"] == "REVERSE")
    check("arrival row fallback recovers the vetted current-side quote",
          ev2["A_ORIGINAL_CONTRARIAN"]["action"] == "TAKE")

    # Complement and equality rule.
    dep3 = dict(dep, yes_ask=0.20, no_ask=0.79)
    row3 = {"side": "YES", "win": "0", "near_impossible_exact": "1.0",
            "p_win_ci_lo_conservative": "0.10",
            "p_win_ci_hi_conservative": "0.19"}
    ev3, _ = evaluate_row(row3, dep3, "one", collections.Counter())
    check("numeric 1.0 near-impossible input is parsed for audit",
          ev3["_meta"]["near_impossible_input_q1"] == 1)
    check("equality at opposite break-even does not reverse",
          ev3["D_CF_REVERSE_CONSERVATIVE"]["action"] == "SKIP")
    check("opposite interval is complemented exactly",
          abs(ev3["_meta"]["p_opposite_lo"] - 0.81) < 1e-12 and
          abs(ev3["_meta"]["p_opposite_hi"] - 0.90) < 1e-12)

    # Invalid probability fails closed for gate policies.
    bad = dict(row3, p_win_ci_hi_conservative="1.2")
    ev4, _ = evaluate_row(bad, dep3, "one", collections.Counter())
    check("invalid probability interval fails gate-dependent policies closed",
          all(ev4[p]["action"] == "SKIP" for p in POLICIES[1:]))

    # Reversal identity.
    ay, an, w = 0.15, 0.86, 0
    lhs = pnl_exact(1 - w, an, 1)
    rhs = -pnl_exact(w, ay, 1) - (ay + an - 1) - exact_order_fee(ay, 1) - exact_order_fee(an, 1)
    check("reversal identity includes spread and both fees", abs(lhs - rhs) < 1e-12)

    # Accumulator.
    acc = Accum()
    acc.add(1.0, _trade_result("YES", 1, 0.4, 1, "TAKE"), "m1", "b1", "d1")
    acc.add(2.0, _trade_result("YES", 0, 0.4, 1, "TAKE"), "m2", "b2", "d2")
    acc.add(3.0, _skip_result(), "m3", "b3", "d3")
    check("skip is a row but not a trade", acc.rows == 3 and acc.traded == 2)
    check("win rate uses executed trades", acc.wins == 1 and acc.losses == 1)
    check("losing streak ignores skips", acc.max_losing_streak() == 1)

    print("\n" + ("ALL PASS" if not failures else "FAILURES: " + ", ".join(failures)))
    return 0 if not failures else 1


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--rows", default="~/cf_reach_v1_1/paper_bot_cf_reachability_rows.csv.gz")
    ap.add_argument("--depth", action="append", default=None)
    ap.add_argument("--out", default="~/cf_reversal_v2_1")
    ap.add_argument("--clock", default="arrival", choices=("arrival", "decision"))
    ap.add_argument("--through", default=str(DEVELOPMENT_THROUGH))
    ap.add_argument("--allow-sealed", action="store_true",
                    help="permit the sealed range when --through is deliberately extended")
    ap.add_argument("--self-test", action="store_true")
    args = ap.parse_args()
    if args.self_test:
        return self_test()
    if not args.depth:
        args.depth = ["~/paper_bot_depth_reconstruction.csv",
                      "~/paper_bot_depth_DOGE_XRP.csv"]
    lines = []

    def log(text=""):
        print(text, flush=True)
        lines.append(text)

    rc = 1
    try:
        rc = run(args, log)
        return rc
    finally:
        out = Path(os.path.expanduser(args.out))
        out.mkdir(parents=True, exist_ok=True)
        (out / "REVERSAL_REPORT.md").write_text("\n".join(lines) + "\n", encoding="utf-8")


if __name__ == "__main__":
    raise SystemExit(main())
