#!/usr/bin/env python3
"""Focused adversarial tests for build_strike_table_v1_1_gpt.py.

No network or credentials required.
"""
from __future__ import annotations

import argparse
import collections
import csv
import datetime as dt
import gzip
import importlib.util
import json
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
TARGET = HERE / "build_strike_table_v1_1_gpt.py"
spec = importlib.util.spec_from_file_location("bst", TARGET)
bst = importlib.util.module_from_spec(spec)
assert spec.loader is not None
spec.loader.exec_module(bst)

FAILS: list[str] = []


def ck(name: str, cond: bool, detail: str = "") -> None:
    print(f"  {name:62s} {'PASS' if cond else 'FAIL'} {detail}")
    if not cond:
        FAILS.append(name)


def event(ticker: str, ts: float, strike: float, raw_id: str,
          comparator: str = "greater_or_equal", cap: bool = False) -> dict:
    return {
        "market_ticker": ticker,
        "series": ticker.split("-")[0],
        "recv_ts": ts,
        "recv_ts_utc": "",
        "strike_type": comparator,
        "floor_strike": "" if cap else repr(strike),
        "cap_strike": repr(strike) if cap else "",
        "effective_strike": repr(strike),
        "strike_field": "cap_strike" if cap else "floor_strike",
        "round_digits": "2",
        "event_type": "metadata_updated",
        "found_in_coin_dir": "BTC",
        "source_session": "fixture",
        "raw_sha256": raw_id,
    }


def opp(t: float | None, ticker: str = "KXBTC15M-A") -> dict:
    return {"t": t, "date": "2026-08-01", "ticker": ticker, "coin": "BTC",
            "side": "YES", "cost": "0.5", "win": "1", "preload_status": ""}


# 1. A conflict that arrives later cannot leak backward into an earlier decision.
st = collections.Counter()
events = bst.dedupe_and_flag([
    event("KXBTC15M-A", 100, 10, "a"),
    event("KXBTC15M-A", 200, 11, "b"),
    event("KXBTC15M-A", 200, 12, "c"),
], st)
r = bst.coverage([opp(150)], events, collections.Counter())[0]
ck("future conflict does not poison earlier decision", r["status"] == "OK", r["status"])
r2 = bst.coverage([opp(250)], events, collections.Counter())[0]
ck("conflict already observed by decision fails closed", r2["status"] == "STRIKE_CONFLICT", r2["status"])

# 2. Less-than markets must use cap_strike if comparator support is declared.
cap = event("KXBTC15M-CAP", 100, 50, "cap", "less_or_equal", cap=True)
cap = bst.dedupe_and_flag([cap], collections.Counter())
r = bst.coverage([opp(150, "KXBTC15M-CAP")], cap, collections.Counter())[0]
ck("less comparator uses cap_strike", r["status"] == "OK" and r["strike_asof"] == "50", str(r))

# 3. Latest prior update wins; a later future update is excluded.
updates = bst.dedupe_and_flag([
    event("KXBTC15M-UPD", 100, 10, "u1"),
    event("KXBTC15M-UPD", 120, 11, "u2"),
    event("KXBTC15M-UPD", 200, 12, "u3"),
], collections.Counter())
r = bst.coverage([opp(150, "KXBTC15M-UPD")], updates, collections.Counter())[0]
ck("latest prior update selected, future update excluded",
   r["status"] == "OK" and float(r["strike_asof"]) == 11.0 and float(r["strike_any"]) == 12.0, str(r))

# 4. Invalid decision time is retained and counted, not silently dropped.
with tempfile.TemporaryDirectory() as td:
    p = Path(td) / "settled.csv"
    with p.open("w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=["t_entry", "ticker", "sib", "opp", "cost", "win"])
        w.writeheader()
        w.writerow({"t_entry": "bad", "ticker": "X", "sib": "BTC", "opp": "YES", "cost": "0.5", "win": "1"})
        w.writerow({"t_entry": "1780000000", "ticker": "Y", "sib": "BTC", "opp": "YES", "cost": "0.5", "win": "1"})
    report = collections.Counter()
    rows = bst.load_opportunities(p, report)
    ck("invalid decision time retained and counted",
       len(rows) == 2 and report["invalid_decision_time"] == 1,
       f"rows={len(rows)} report={dict(report)}")
    cov = bst.coverage(rows, [], collections.Counter())
    ck("invalid decision time receives explicit status",
       any(x["status"] == "INVALID_DECISION_TIME" for x in cov))

# 5. Requested-date filtering is explicit.
with tempfile.TemporaryDirectory() as td:
    p = Path(td) / "settled.csv"
    with p.open("w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=["t_entry", "ticker", "sib", "opp", "cost", "win"])
        w.writeheader()
        for d in ("2026-07-14T12:00:00+00:00", "2026-07-15T12:00:00+00:00"):
            w.writerow({"t_entry": dt.datetime.fromisoformat(d).timestamp(), "ticker": d, "sib": "BTC", "opp": "YES", "cost": "0.5", "win": "1"})
    report = collections.Counter()
    rows = bst.load_opportunities(p, report, dt.date(2026, 7, 15), dt.date(2026, 9, 6))
    ck("outside-range opportunity excluded and counted",
       len(rows) == 1 and report["outside_requested_range_excluded"] == 1,
       f"rows={len(rows)} report={dict(report)}")

# 6. Archive listing cannot silently become an empty successful build.
class EmptyStore:
    def ls(self, _uri): return []
    def lines(self, _uri): return iter(())

with tempfile.TemporaryDirectory() as td:
    a = argparse.Namespace(date_from="2026-07-15", date_to="2026-09-06",
                           out=td, settled=None, probe=False, allow_sealed=False)
    ck("empty archive listing fails closed", bst.run(a, EmptyStore()) != 0)

# 7. One-day lookback recovers a strike emitted immediately before d0.
with tempfile.TemporaryDirectory() as td:
    root = Path(td)
    day0 = root / "KCP_data" / "2026-07-14_Tue_AfterHours_2000-0000UTC" / "BTC"
    day0.mkdir(parents=True)
    raw = {"type": "market_lifecycle_v2", "msg": {"event_type": "metadata_updated",
           "market_ticker": "KXBTC15M-BOUNDARY", "strike_type": "greater_or_equal",
           "floor_strike": 100.0}}
    with gzip.open(day0 / "kalshi_lifecycle.csv.gz", "wt", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=["recv_ts_utc", "market_ticker", "raw_json"])
        w.writeheader(); w.writerow({"recv_ts_utc": "2026-07-14T23:59:59Z",
                                     "market_ticker": "KXBTC15M-BOUNDARY",
                                     "raw_json": json.dumps(raw)})
    for c in bst.COINS[1:]:
        (day0.parent / c).mkdir(parents=True)
    settled = root / "settled.csv"
    with settled.open("w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=["t_entry", "ticker", "sib", "opp", "cost", "win"])
        w.writeheader(); w.writerow({"t_entry": dt.datetime(2026,7,15,0,0,1,tzinfo=dt.timezone.utc).timestamp(),
            "ticker":"KXBTC15M-BOUNDARY","sib":"BTC","opp":"YES","cost":"0.5","win":"1"})
    out = root / "out"
    a = argparse.Namespace(date_from="2026-07-15", date_to="2026-07-15", out=str(out),
                           settled=str(settled), probe=False, allow_sealed=False)
    rc = bst.run(a, bst.FakeStore(root))
    rows = list(csv.DictReader((out / "opportunity_strike_coverage.csv").open())) if rc == 0 else []
    ck("one-day lookback recovers first-day boundary strike",
       rc == 0 and len(rows) == 1 and rows[0]["status"] == "OK",
       f"rc={rc} rows={rows}")

print("\n" + ("ALL ADVERSARIAL TESTS PASS" if not FAILS else "FAILURES: " + ", ".join(FAILS)))
raise SystemExit(1 if FAILS else 0)
