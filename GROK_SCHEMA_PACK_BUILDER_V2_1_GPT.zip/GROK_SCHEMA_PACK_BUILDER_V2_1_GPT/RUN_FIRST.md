# Run order on Probe2

```bash
python3 ~/build_grok_schema_pack_v2_1_gpt.py --self-test
```

Then:

```bash
python3 ~/build_grok_schema_pack_v2_1_gpt.py --probe \
  --date 2026-09-06 \
  --session USsession
```

If both are clean, build:

```bash
python3 ~/build_grok_schema_pack_v2_1_gpt.py \
  --out ~/grok_schema_pack_v2_1 \
  --date 2026-09-06 \
  --session USsession \
  --market-open 13:45 \
  --sync-coins BTC,SOL \
  --exception-coin HYPE \
  --force
```

If probe reports `v9: not discovered`, rerun the build with:

```bash
--v9-uri 'gs://...exact-session.zip'
```

Success ends with `BUILD VERIFIED:` and creates `~/grok_schema_pack_v2_1.zip`.
