#!/usr/bin/env python3
"""Adversarial tests for cf_reversal_counterfactual_v2_1_gpt.py."""
from __future__ import annotations

import argparse
import collections
import csv
import datetime as dt
import gzip
import importlib.util
import json
import math
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
TARGET = HERE / "cf_reversal_counterfactual_v2_1_gpt.py"
spec = importlib.util.spec_from_file_location("rev", TARGET)
rev = importlib.util.module_from_spec(spec)
assert spec.loader is not None
spec.loader.exec_module(rev)

fails = []
passes = 0


def check(name, cond):
    global passes
    ok = bool(cond)
    print(f"  {name:78s} {'PASS' if ok else 'FAIL'}")
    if ok:
        passes += 1
    else:
        fails.append(name)


def raises(exc, fn):
    try:
        fn()
    except exc:
        return True
    except Exception:
        return False
    return False


def write_csv(path, rows):
    rows = list(rows)
    path.parent.mkdir(parents=True, exist_ok=True)
    opener = gzip.open if str(path).endswith(".gz") else open
    mode = "wt" if str(path).endswith(".gz") else "w"
    with opener(path, mode, newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)


def depth_row(t, ticker, side, ya="", na="", ys="", ns="", age="0.1"):
    return {
        "t_entry": str(t), "ticker": ticker, "opp": side,
        "arrival_yes_ask": str(ya), "arrival_no_ask": str(na),
        "arrival_yes_ask_size": str(ys), "arrival_no_ask_size": str(ns),
        "arrival_book_age_s": str(age),
        "decision_yes_ask": str(ya), "decision_no_ask": str(na),
        "decision_yes_ask_size": str(ys), "decision_no_ask_size": str(ns),
        "decision_book_age_s": str(age),
    }


def reach_row(t, ticker, side, win, status="OK", near="1", p_lo="0.05", p_hi="0.10",
              ask="0.20", cap="10", coin="BTC", burst="b1"):
    d = dt.datetime.fromtimestamp(t, dt.timezone.utc)
    ask_f = float(ask) if ask not in (None, "") else None
    pnl = "" if ask_f is None else str(rev.pnl_exact(int(win), ask_f, 1))
    return {
        "t_entry": str(t), "ticker": ticker, "side": side, "coin": coin,
        "win": str(win), "status": status, "near_impossible_exact": near,
        "p_win_ci_lo_conservative": p_lo, "p_win_ci_hi_conservative": p_hi,
        "reconstructed_ask": ask, "capacity_at_touch": cap,
        "economic_status": "OK" if status == "OK" else "NOT_EVALUATED",
        "reference_gateable": "1" if status == "OK" else "0",
        "pnl_ask_exact": pnl,
        "stc": "300", "session": "USsession", "decision_dow_utc": d.strftime("%A"),
        "burst_id": burst, "vel_60s_bps_per_s": "0.123", "feed_stale": "0",
    }


# ---------------------------------------------------------------- primitives
check("flag01 accepts 1, 1.0, true and yes",
      all(rev.flag01(v) == 1 for v in (1, 1.0, "1", "1.0", "true", "yes")))
check("flag01 accepts 0, 0.0, false and no",
      all(rev.flag01(v) == 0 for v in (0, 0.0, "0", "0.0", "false", "no")))
check("flag01 refuses ambiguous text", rev.flag01("maybe") is None)
check("parse_ts handles seconds", rev.parse_ts("1780000000") == 1780000000.0)
check("parse_ts handles milliseconds", rev.parse_ts("1780000000000") == 1780000000.0)
check("parse_ts rejects NaN", rev.parse_ts("nan") is None)
check("valid_price excludes endpoints", not rev.valid_price(0.0) and not rev.valid_price(1.0))
check("valid_price accepts sub-cent fixed point", rev.valid_price(0.001) and rev.valid_price(0.999))

# Exhaustive whole-order fee comparison on q=1..25, prices 0.001..0.999.
fee_ok = True
for mills in range(1, 1000):
    p = mills / 1000.0
    for q in range(1, 26):
        expected = math.ceil((0.07 * q * p * (1 - p)) * 100 - 1e-9) / 100
        if rev.exact_order_fee(p, q) != expected:
            fee_ok = False
            break
    if not fee_ok:
        break
check("exact fee matches whole-order ceiling for 24,975 cases", fee_ok)
check("q=1 requires at least one displayed contract",
      rev.quantity_for_touch(None, "one") is None and rev.quantity_for_touch(0, "one") is None)
check("q=1 accepts exactly one displayed contract", rev.quantity_for_touch(1, "one") == 1)
check("half-touch floors odd touch", rev.quantity_for_touch(9, "half") == 4)
check("half-touch refuses touch=1", rev.quantity_for_touch(1, "half") is None)
check("full and half touch respect cap 25",
      rev.quantity_for_touch(1000, "full") == 25 and rev.quantity_for_touch(1000, "half") == 25)

# ---------------------------------------------------------------- depth merge/join
with tempfile.TemporaryDirectory() as td:
    root = Path(td)
    blank = root / "blank.csv"
    full = root / "full.csv"
    write_csv(blank, [depth_row(100, "T", "YES")])
    write_csv(full, [depth_row(100, "T", "YES", .20, .82, 5, 6)])
    stats = collections.Counter()
    idx = rev.load_depth([str(blank), str(full)], "arrival", stats, lambda *_: None)
    rec, status = rev.lookup_depth(idx, "T", "YES", 100.0)
    check("overlap blank+complete merges to the complete DOGE/XRP-style row",
          status == "OK" and rec["yes_ask"] == .20 and rec["no_ask"] == .82)
    check("overlap merge records provenance from both files", len(rec["sources"]) == 2)
    check("overlap merge is counted", stats["depth_overlap_groups"] == 1)

with tempfile.TemporaryDirectory() as td:
    root = Path(td)
    a, b = root / "a.csv", root / "b.csv"
    write_csv(a, [depth_row(100, "T", "YES", .20, .82, 5, 6)])
    write_csv(b, [depth_row(100, "T", "YES", .30, .82, 5, 6)])
    stats = collections.Counter()
    idx = rev.load_depth([str(a), str(b)], "arrival", stats, lambda *_: None)
    rec, status = rev.lookup_depth(idx, "T", "YES", 100.0)
    check("incompatible duplicate asks fail closed", status == "DEPTH_CONFLICT")
    check("conflicting field is named", "yes_ask" in rec["conflict_fields"])

with tempfile.TemporaryDirectory() as td:
    root = Path(td)
    a = root / "a.csv"
    write_csv(a, [depth_row(100.0000, "T", "YES", .20, .82, 5, 6),
                  depth_row(100.0008, "T", "YES", .20, .82, 5, 6)])
    idx = rev.load_depth([str(a)], "arrival", collections.Counter(), lambda *_: None)
    check("two different depth instants within join tolerance are ambiguous",
          rev.lookup_depth(idx, "T", "YES", 100.0004)[1] == "JOIN_AMBIGUOUS")
    check("depth time mismatch is explicit",
          rev.lookup_depth(idx, "T", "YES", 105.0)[1] == "JOIN_TIME_MISMATCH")

with tempfile.TemporaryDirectory() as td:
    check("a missing required depth file aborts",
          raises(FileNotFoundError, lambda: rev.load_depth([str(Path(td)/"missing.csv")],
                                                            "arrival", collections.Counter(), print)))

# ---------------------------------------------------------------- policy logic
base_dep = {"t": 0.0, "yes_ask": .20, "no_ask": .82,
            "yes_size": 10.0, "no_size": 12.0, "book_age_s": .1,
            "sources": ["x"], "conflict_fields": []}
base = {"side": "YES", "win": "0", "near_impossible_exact": "1",
        "p_win_ci_lo_conservative": ".05", "p_win_ci_hi_conservative": ".10",
        "reconstructed_ask": ".20", "capacity_at_touch": "10"}
ev, why = rev.evaluate_row(base, base_dep, "one", collections.Counter())
check("normal row evaluates", why == "OK" and ev is not None)
check("original YES uses actual YES ask", ev["A_ORIGINAL_CONTRARIAN"]["price"] == .20)
check("reverse uses actual NO ask, not 1-YES ask", ev["C_CF_REVERSE_ALL"]["price"] == .82)
check("reverse outcome is complement of original outcome",
      ev["C_CF_REVERSE_ALL"]["realized_win"] == 1)
check("skip-only skips recomputed near-impossible trade",
      ev["B_CF_SKIP_ONLY"]["action"] == "SKIP")
check("conservative reversal passes when opposite lower bound clears toll",
      ev["D_CF_REVERSE_CONSERVATIVE"]["action"] == "REVERSE")

# NO mapping symmetry.
no_row = dict(base, side="NO", win="0", reconstructed_ask=".82", capacity_at_touch="12",
              p_win_ci_lo_conservative=".05", p_win_ci_hi_conservative=".10")
ev_no, _ = rev.evaluate_row(no_row, base_dep, "one", collections.Counter())
check("original NO uses actual NO ask", ev_no["A_ORIGINAL_CONTRARIAN"]["price"] == .82)
check("reverse from NO uses actual YES ask", ev_no["C_CF_REVERSE_ALL"]["price"] == .20)

# Quantity-specific current gate.
flip_dep = dict(base_dep, yes_ask=.49, no_ask=.52, yes_size=100, no_size=100)
flip = dict(base, win="1", reconstructed_ask=".49", capacity_at_touch="100",
            p_win_ci_lo_conservative=".45", p_win_ci_hi_conservative=".508")
one, _ = rev.evaluate_row(flip, flip_dep, "one", collections.Counter())
full, _ = rev.evaluate_row(flip, flip_dep, "full", collections.Counter())
check("current gate is recomputed at each quantity",
      one["_meta"]["current_near_impossible_recomputed"] == 1 and
      full["_meta"]["current_near_impossible_recomputed"] == 0)
check("skip-only can change from skip at q=1 to take at q=25",
      one["B_CF_SKIP_ONLY"]["action"] == "SKIP" and full["B_CF_SKIP_ONLY"]["action"] == "TAKE")

# One-contract capacity on both sides.
zero_own = dict(base_dep, yes_size=0)
ev_zero, why_zero = rev.evaluate_row(base, zero_own, "one", collections.Counter(),
                                     use_row_current=False)
check("q=1 original trade fails closed when current touch size is zero",
      ev_zero["A_ORIGINAL_CONTRARIAN"]["action"] == "SKIP")
zero_opp = dict(base_dep, no_size=0)
ev_zero2, _ = rev.evaluate_row(base, zero_opp, "one", collections.Counter())
check("q=1 reversal fails closed when opposite touch size is zero",
      ev_zero2["C_CF_REVERSE_ALL"]["action"] == "SKIP")

# Arrival current-side fallback and conflicts.
fallback_dep = dict(base_dep, yes_ask=None, yes_size=None)
ev_fb, _ = rev.evaluate_row(base, fallback_dep, "one", collections.Counter(), use_row_current=True)
check("vetted current-side arrival fields can fill blanks", ev_fb["A_ORIGINAL_CONTRARIAN"]["action"] == "TAKE")
check("current ask disagreement fails closed",
      rev.evaluate_row(dict(base, reconstructed_ask=".21"), base_dep, "one",
                       collections.Counter(), use_row_current=True)[1] == "OWN_ASK_MISMATCH")
check("current touch disagreement fails closed",
      rev.evaluate_row(dict(base, capacity_at_touch="11"), base_dep, "one",
                       collections.Counter(), use_row_current=True)[1] == "OWN_TOUCH_MISMATCH")

# Interval handling.
invalid_p = dict(base, p_win_ci_hi_conservative="1.2")
ev_bad, _ = rev.evaluate_row(invalid_p, base_dep, "one", collections.Counter())
check("invalid probability interval makes all gate-dependent policies skip",
      all(ev_bad[p]["action"] == "SKIP" for p in rev.POLICIES[1:]))
equality = dict(base, p_win_ci_lo_conservative=".10", p_win_ci_hi_conservative=".16")
# NO ask .82 at q=1 => BE .84, opposite lower bound exactly .84.
ev_eq, _ = rev.evaluate_row(equality, base_dep, "one", collections.Counter())
check("equality at opposite break-even does not reverse",
      ev_eq["D_CF_REVERSE_CONSERVATIVE"]["action"] == "SKIP")
check("unknown side is refused", rev.evaluate_row(dict(base, side="MAYBE"), base_dep, "one", collections.Counter())[1] == "UNKNOWN_SIDE")
check("nonbinary result is refused", rev.evaluate_row(dict(base, win=".5"), base_dep, "one", collections.Counter())[1] == "INVALID_WIN")

# ---------------------------------------------------------------- source guards
T = lambda s: dt.datetime.fromisoformat(s).timestamp()
with tempfile.TemporaryDirectory() as td:
    root = Path(td)
    p = root / "rows.csv"
    r = reach_row(T("2026-08-01T00:00:00+00:00"), "T", "YES", 1)
    write_csv(p, [r, dict(r)])
    check("duplicate opportunity identity aborts",
          raises(RuntimeError, lambda: rev.load_source_rows(str(p), rev.DEVELOPMENT_THROUGH, False)))

with tempfile.TemporaryDirectory() as td:
    p = Path(td) / "rows.csv"
    write_csv(p, [reach_row(T("2026-09-08T00:00:00+00:00"), "T", "YES", 1)])
    check("sealed holdout row aborts rather than disappearing",
          raises(RuntimeError, lambda: rev.load_source_rows(str(p), rev.DEVELOPMENT_THROUGH, False)))

with tempfile.TemporaryDirectory() as td:
    p = Path(td) / "rows.csv"
    write_csv(p, [reach_row(T("2026-09-14T00:00:00+00:00"), "T", "YES", 1)])
    check("post-development row aborts even outside sealed week",
          raises(RuntimeError, lambda: rev.load_source_rows(str(p), rev.DEVELOPMENT_THROUGH, False)))

with tempfile.TemporaryDirectory() as td:
    p = Path(td) / "rows.csv"
    r = reach_row(T("2026-08-01T00:00:00+00:00"), "T", "YES", 1)
    r["t_entry"] = "bad"
    write_csv(p, [r])
    rows, bad = rev.load_source_rows(str(p), rev.DEVELOPMENT_THROUGH, False)
    check("malformed decision time is retained for explicit output status", len(rows) == 0 and len(bad) == 1)

# ---------------------------------------------------------------- synthetic end-to-end
with tempfile.TemporaryDirectory() as td:
    root = Path(td)
    rows_path = root / "reach.csv.gz"
    d1 = root / "depth_all.csv"
    d2 = root / "depth_dogexrp.csv"
    out = root / "out"
    t1 = T("2026-08-01T14:00:00+00:00")
    t2 = T("2026-08-01T14:01:00+00:00")
    t3 = T("2026-08-01T14:02:00+00:00")
    rr1 = reach_row(t1, "KXBTC15M-A", "YES", 0, near="1", p_lo=".05", p_hi=".10",
                    ask=".20", cap="10", coin="BTC", burst="b1")
    rr2 = reach_row(t2, "KXBTC15M-A", "NO", 1, near="0", p_lo=".85", p_hi=".90",
                    ask=".82", cap="12", coin="BTC", burst="b2")
    rr3 = reach_row(t3, "KXSOL15M-B", "YES", 1, status="MISSING_STRIKE",
                    coin="SOL", burst="b3")
    rr4 = reach_row(t3 + 1, "KXETH15M-C", "YES", 1, coin="ETH", burst="b4")
    rr4["t_entry"] = "bad"
    write_csv(rows_path, [rr1, rr2, rr3, rr4])

    # First file mimics all-coin reconstruction: BTC complete, plus a blank
    # overlapping row. Second file fills that same identity.
    write_csv(d1, [
        depth_row(t1, "KXBTC15M-A", "YES"),
        depth_row(t2, "KXBTC15M-A", "NO", .20, .82, 10, 12),
    ])
    write_csv(d2, [depth_row(t1, "KXBTC15M-A", "YES", .20, .82, 10, 12)])
    args = argparse.Namespace(rows=str(rows_path), depth=[str(d1), str(d2)], out=str(out),
                              clock="arrival", through="2026-09-06", allow_sealed=False)
    lines = []
    rc = rev.run(args, lambda s="": lines.append(s))
    check("synthetic production run exits successfully", rc == 0)
    with gzip.open(out / "reversal_rows.csv.gz", "rt", newline="") as fh:
        got = list(csv.DictReader(fh))
    check("end-to-end rows in equal rows out, including bad-time and missing-strike rows", len(got) == 4)
    by_ticker = collections.defaultdict(list)
    for r in got:
        by_ticker[r.get("ticker")].append(r)
    r1 = by_ticker["KXBTC15M-A"][0]
    check("full reachability feature row is preserved", r1["vel_60s_bps_per_s"] == "0.123")
    check("exact near-impossible column, not nonexistent generic column, drives audit",
          r1["near_impossible_exact"] == "1")
    check("overlapping blank depth did not shadow populated row", r1["one_own_ask"] == "0.2")
    check("conditional reversal uses opposite NO side", r1["one_D_CF_REVERSE_CONSERVATIVE_final_side"] == "NO")
    check("missing-strike source row survives", by_ticker["KXSOL15M-B"][0]["reversal_status"] == "REACH_MISSING_STRIKE")
    check("bad-time source row survives", by_ticker["KXETH15M-C"][0]["reversal_status"] == "NO_DECISION_TIME")
    check("policy summary CSV exists", (out / "policy_summary.csv").is_file())
    check("machine-readable JSON summary exists", (out / "reversal_summary.json").is_file())
    summary = json.loads((out / "reversal_summary.json").read_text())
    check("summary reconciliation is true", summary["reconciles"] is True and summary["rows_out"] == 4)
    check("actual final-side contention is recorded",
          int(float(r1["one_D_CF_REVERSE_CONSERVATIVE_n_same_market_final_side"])) >= 1)

print(f"\n{passes} passed, {len(fails)} failed")
if fails:
    print("FAILURES:")
    for x in fails:
        print(" -", x)
raise SystemExit(1 if fails else 0)
